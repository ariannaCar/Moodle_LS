<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This page handles deleting pretest overrides
 *
 * @package    mod_pretest
 * @copyright  2010 Matt Petro
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


require_once(__DIR__ . '/../../config.php');
require_once($CFG->dirroot.'/mod/pretest/lib.php');
require_once($CFG->dirroot.'/mod/pretest/locallib.php');
require_once($CFG->dirroot.'/mod/pretest/override_form.php');

$overrideid = required_param('id', PARAM_INT);
$confirm = optional_param('confirm', false, PARAM_BOOL);

if (! $override = $DB->get_record('pretest_overrides', array('id' => $overrideid))) {
    print_error('invalidoverrideid', 'pretest');
}
if (! $pretest = $DB->get_record('pretest', array('id' => $override->pretest))) {
    print_error('invalidcoursemodule');
}
if (! $cm = get_coursemodule_from_instance("pretest", $pretest->id, $pretest->course)) {
    print_error('invalidcoursemodule');
}
$course = $DB->get_record('course', array('id'=>$cm->course), '*', MUST_EXIST);

$context = context_module::instance($cm->id);

require_login($course, false, $cm);

// Check the user has the required capabilities to modify an override.
require_capability('mod/pretest:manageoverrides', $context);

if ($override->groupid) {
    if (!groups_group_visible($override->groupid, $course, $cm)) {
        print_error('invalidoverrideid', 'pretest');
    }
} else {
    if (!groups_user_groups_visible($course, $override->userid, $cm)) {
        print_error('invalidoverrideid', 'pretest');
    }
}

$url = new moodle_url('/mod/pretest/overridedelete.php', array('id'=>$override->id));
$confirmurl = new moodle_url($url, array('id'=>$override->id, 'confirm'=>1));
$cancelurl = new moodle_url('/mod/pretest/overrides.php', array('cmid'=>$cm->id));

if (!empty($override->userid)) {
    $cancelurl->param('mode', 'user');
}

// If confirm is set (PARAM_BOOL) then we have confirmation of intention to delete.
if ($confirm) {
    require_sesskey();

    // Set the course module id before calling pretest_delete_override().
    $pretest->cmid = $cm->id;
    pretest_delete_override($pretest, $override->id);

    redirect($cancelurl);
}

// Prepare the page to show the confirmation form.
$stroverride = get_string('override', 'pretest');
$title = get_string('deletecheck', null, $stroverride);

$PAGE->set_url($url);
$PAGE->set_pagelayout('admin');
$PAGE->navbar->add($title);
$PAGE->set_title($title);
$PAGE->set_heading($course->fullname);

echo $OUTPUT->header();
echo $OUTPUT->heading(format_string($pretest->name, true, array('context' => $context)));

if ($override->groupid) {
    $group = $DB->get_record('groups', ['id' => $override->groupid], 'id, name');
    $confirmstr = get_string("overridedeletegroupsure", "pretest", $group->name);
} else {
    $user = $DB->get_record('user', ['id' => $override->userid]);

    $username = fullname($user);
    $namefields = [];

    // TODO Does not support custom user profile fields (MDL-70456).
    foreach (\core_user\fields::for_identity($context, false)->get_required_fields() as $field) {
        if (isset($user->$field) && $user->$field !== '') {
            $namefields[] = s($user->$field);
        }
    }
    if ($namefields) {
        $username .= ' (' . implode(', ', $namefields) . ')';
    }

    $confirmstr = get_string('overridedeleteusersure', 'pretest', $username);
}

echo $OUTPUT->confirm($confirmstr, $confirmurl, $cancelurl);

echo $OUTPUT->footer();
