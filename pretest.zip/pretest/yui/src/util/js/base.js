/**
 * The Moodle.mod_pretest.util classes provide pretest-related utility functions.
 *
 * @module moodle-mod_pretest-util
 * @main
 */

Y.namespace('Moodle.mod_pretest.util');

/**
 * A collection of general utility functions for use in pretest.
 *
 * @class Moodle.mod_pretest.util
 * @static
 */
