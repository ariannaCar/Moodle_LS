<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Restore instructions for the seb (Safe Exam Browser) pretest access subplugin.
 *
 * @package    pretestaccess_seb
 * @category   backup
 * @author     Andrew Madden <andrewmadden@catalyst-au.net>
 * @copyright  2020 Catalyst IT
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use pretestaccess_seb\pretest_settings;

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/pretest/backup/moodle2/restore_mod_pretest_access_subplugin.class.php');

/**
 * Restore instructions for the seb (Safe Exam Browser) pretest access subplugin.
 *
 * @copyright  2020 Catalyst IT
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class restore_pretestaccess_seb_subplugin extends restore_mod_pretest_access_subplugin {

    /**
     * Provides path structure required to restore data for seb pretest access plugin.
     *
     * @return array
     */
    protected function define_pretest_subplugin_structure() {
        $paths = [];

        // pretest settings.
        $path = $this->get_pathfor('/ptaccess_seb_ptsettings'); // Subplugin root path.
        $paths[] = new restore_path_element('ptaccess_seb_ptsettings', $path);

        // Template settings.
        $path = $this->get_pathfor('/ptaccess_seb_ptsettings/pretestaccess_seb_template');
        $paths[] = new restore_path_element('pretestaccess_seb_template', $path);

        return $paths;
    }

    /**
     * Process the restored data for the ptaccess_seb_ptsettings table.
     *
     * @param stdClass $data Data for ptaccess_seb_ptsettings retrieved from backup xml.
     */
    public function process_ptaccess_seb_ptsettings($data) {
        global $DB, $USER;

        // Process pretestsettings.
        $data = (object) $data;
        $data->pretestid = $this->get_new_parentid('pretest'); // Update pretestid with new reference.
        $data->cmid = $this->task->get_moduleid();

        unset($data->id);
        $data->timecreated = $data->timemodified = time();
        $data->usermodified = $USER->id;
        $DB->insert_record(pretestaccess_seb\pretest_settings::TABLE, $data);

        // Process attached files.
        $this->add_related_files('pretestaccess_seb', 'filemanager_sebconfigfile', null);
    }

    /**
     * Process the restored data for the pretestaccess_seb_template table.
     *
     * @param stdClass $data Data for pretestaccess_seb_template retrieved from backup xml.
     */
    public function process_pretestaccess_seb_template($data) {
        global $DB;

        $data = (object) $data;

        $pretestid = $this->get_new_parentid('pretest');

        $template = null;
        if ($this->task->is_samesite()) {
            $template = \pretestaccess_seb\template::get_record(['id' => $data->id]);
        } else {
            // In a different site, try to find existing template with the same name and content.
            $candidates = \pretestaccess_seb\template::get_records(['name' => $data->name]);
            foreach ($candidates as $candidate) {
                if ($candidate->get('content') == $data->content) {
                    $template = $candidate;
                    break;
                }
            }
        }

        if (empty($template)) {
            unset($data->id);
            $template = new \pretestaccess_seb\template(0, $data);
            $template->save();
        }

        // Update the restored pretest settings to use restored template.
        $DB->set_field(\pretestaccess_seb\pretest_settings::TABLE, 'templateid', $template->get('id'), ['pretestid' => $pretestid]);
    }

}

