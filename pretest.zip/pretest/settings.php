<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Administration settings definitions for the pretest module.
 *
 * @package   mod_pretest
 * @copyright 2010 Petr Skoda
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/pretest/lib.php');

// First get a list of pretest reports with there own settings pages. If there none,
// we use a simpler overall menu structure.
$reports = core_component::get_plugin_list_with_file('pretest', 'settings.php', false);
$reportsbyname = array();
foreach ($reports as $report => $reportdir) {
    $strreportname = get_string($report . 'report', 'pretest_'.$report);
    $reportsbyname[$strreportname] = $report;
}
core_collator::ksort($reportsbyname);

// First get a list of pretest reports with there own settings pages. If there none,
// we use a simpler overall menu structure.
$rules = core_component::get_plugin_list_with_file('pretestaccess', 'settings.php', false);
$rulesbyname = array();
foreach ($rules as $rule => $ruledir) {
    $strrulename = get_string('pluginname', 'pretestaccess_' . $rule);
    $rulesbyname[$strrulename] = $rule;
}
core_collator::ksort($rulesbyname);

// Create the pretest settings page.
if (empty($reportsbyname) && empty($rulesbyname)) {
    $pagetitle = get_string('modulename', 'pretest');
} else {
    $pagetitle = get_string('generalsettings', 'admin');
}
$pretestsettings = new admin_settingpage('modsettingpretest', $pagetitle, 'moodle/site:config');

if ($ADMIN->fulltree) {
    // Introductory explanation that all the settings are defaults for the add pretest form.
    $pretestsettings->add(new admin_setting_heading('pretestintro', '', get_string('configintro', 'pretest')));

    // Time limit.
    $setting = new admin_setting_configduration('pretest/timelimit',
            get_string('timelimit', 'pretest'), get_string('configtimelimitsec', 'pretest'),
            '0', 60);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $pretestsettings->add($setting);

    // What to do with overdue attempts.
    $pretestsettings->add(new mod_pretest_admin_setting_overduehandling('pretest/overduehandling',
            get_string('overduehandling', 'pretest'), get_string('overduehandling_desc', 'pretest'),
            array('value' => 'autosubmit', 'adv' => false), null));

    // Grace period time.
    $setting = new admin_setting_configduration('pretest/graceperiod',
            get_string('graceperiod', 'pretest'), get_string('graceperiod_desc', 'pretest'),
            '86400');
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $pretestsettings->add($setting);

    // Minimum grace period used behind the scenes.
    $pretestsettings->add(new admin_setting_configduration('pretest/graceperiodmin',
            get_string('graceperiodmin', 'pretest'), get_string('graceperiodmin_desc', 'pretest'),
            60, 1));

    // Number of attempts.
    $options = array(get_string('unlimited'));
    for ($i = 1; $i <= pretest_MAX_ATTEMPT_OPTION; $i++) {
        $options[$i] = $i;
    }
    $setting = new admin_setting_configselect('pretest/attempts',
            get_string('attemptsallowed', 'pretest'), get_string('configattemptsallowed', 'pretest'),
            0, $options);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $pretestsettings->add($setting);

    // Grading method.
    $pretestsettings->add(new mod_pretest_admin_setting_grademethod('pretest/grademethod',
            get_string('grademethod', 'pretest'), get_string('configgrademethod', 'pretest'),
            array('value' => pretest_GRADEHIGHEST, 'adv' => false), null));

    // Maximum grade.
    $pretestsettings->add(new admin_setting_configtext('pretest/maximumgrade',
            get_string('maximumgrade'), get_string('configmaximumgrade', 'pretest'), 10, PARAM_INT));

    // Questions per page.
    $perpage = array();
    $perpage[0] = get_string('never');
    $perpage[1] = get_string('aftereachquestion', 'pretest');
    for ($i = 2; $i <= pretest_MAX_QPP_OPTION; ++$i) {
        $perpage[$i] = get_string('afternquestions', 'pretest', $i);
    }
    $setting = new admin_setting_configselect('pretest/questionsperpage',
            get_string('newpageevery', 'pretest'), get_string('confignewpageevery', 'pretest'),
            1, $perpage);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $pretestsettings->add($setting);

    // Navigation method.
    $setting = new admin_setting_configselect('pretest/navmethod',
            get_string('navmethod', 'pretest'), get_string('confignavmethod', 'pretest'),
            pretest_NAVMETHOD_FREE, pretest_get_navigation_options());
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, true);
    $pretestsettings->add($setting);

    // Shuffle within questions.
    $setting = new admin_setting_configcheckbox('pretest/shuffleanswers',
            get_string('shufflewithin', 'pretest'), get_string('configshufflewithin', 'pretest'),
            1);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $pretestsettings->add($setting);

    // Preferred behaviour.
    $pretestsettings->add(new admin_setting_question_behaviour('pretest/preferredbehaviour',
            get_string('howquestionsbehave', 'question'), get_string('howquestionsbehave_desc', 'pretest'),
            'deferredfeedback'));

    // Can redo completed questions.
    $setting = new admin_setting_configselect('pretest/canredoquestions',
            get_string('canredoquestions', 'pretest'), get_string('canredoquestions_desc', 'pretest'),
            0,
            array(0 => get_string('no'), 1 => get_string('canredoquestionsyes', 'pretest')));
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, true);
    $pretestsettings->add($setting);

    // Each attempt builds on last.
    $setting = new admin_setting_configcheckbox('pretest/attemptonlast',
            get_string('eachattemptbuildsonthelast', 'pretest'),
            get_string('configeachattemptbuildsonthelast', 'pretest'),
            0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, true);
    $pretestsettings->add($setting);

    // Review options.
    $pretestsettings->add(new admin_setting_heading('reviewheading',
            get_string('reviewoptionsheading', 'pretest'), ''));
    foreach (mod_pretest_admin_review_setting::fields() as $field => $name) {
        $default = mod_pretest_admin_review_setting::all_on();
        $forceduring = null;
        if ($field == 'attempt') {
            $forceduring = true;
        } else if ($field == 'overallfeedback') {
            $default = $default ^ mod_pretest_admin_review_setting::DURING;
            $forceduring = false;
        }
        $pretestsettings->add(new mod_pretest_admin_review_setting('pretest/review' . $field,
                $name, '', $default, $forceduring));
    }

    // Show the user's picture.
    $pretestsettings->add(new mod_pretest_admin_setting_user_image('pretest/showuserpicture',
            get_string('showuserpicture', 'pretest'), get_string('configshowuserpicture', 'pretest'),
            array('value' => 0, 'adv' => false), null));

    // Decimal places for overall grades.
    $options = array();
    for ($i = 0; $i <= pretest_MAX_DECIMAL_OPTION; $i++) {
        $options[$i] = $i;
    }
    $setting = new admin_setting_configselect('pretest/decimalpoints',
            get_string('decimalplaces', 'pretest'), get_string('configdecimalplaces', 'pretest'),
            2, $options);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $pretestsettings->add($setting);

    // Decimal places for question grades.
    $options = array(-1 => get_string('sameasoverall', 'pretest'));
    for ($i = 0; $i <= pretest_MAX_Q_DECIMAL_OPTION; $i++) {
        $options[$i] = $i;
    }
    $setting = new admin_setting_configselect('pretest/questiondecimalpoints',
            get_string('decimalplacesquestion', 'pretest'),
            get_string('configdecimalplacesquestion', 'pretest'),
            -1, $options);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $pretestsettings->add($setting);

    // Show blocks during pretest attempts.
    $setting = new admin_setting_configcheckbox('pretest/showblocks',
            get_string('showblocks', 'pretest'), get_string('configshowblocks', 'pretest'),
            0);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, true);
    $pretestsettings->add($setting);

    // Password.
    $setting = new admin_setting_configpasswordunmask('pretest/pretestpassword',
            get_string('requirepassword', 'pretest'), get_string('configrequirepassword', 'pretest'),
            '');
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, false);
    $setting->set_required_flag_options(admin_setting_flag::ENABLED, false);
    $pretestsettings->add($setting);

    // IP restrictions.
    $setting = new admin_setting_configtext('pretest/subnet',
            get_string('requiresubnet', 'pretest'), get_string('configrequiresubnet', 'pretest'),
            '', PARAM_TEXT);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, true);
    $pretestsettings->add($setting);

    // Enforced delay between attempts.
    $setting = new admin_setting_configduration('pretest/delay1',
            get_string('delay1st2nd', 'pretest'), get_string('configdelay1st2nd', 'pretest'),
            0, 60);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, true);
    $pretestsettings->add($setting);
    $setting = new admin_setting_configduration('pretest/delay2',
            get_string('delaylater', 'pretest'), get_string('configdelaylater', 'pretest'),
            0, 60);
    $setting->set_advanced_flag_options(admin_setting_flag::ENABLED, true);
    $pretestsettings->add($setting);

    // Browser security.
    $pretestsettings->add(new mod_pretest_admin_setting_browsersecurity('pretest/browsersecurity',
            get_string('showinsecurepopup', 'pretest'), get_string('configpopup', 'pretest'),
            array('value' => '-', 'adv' => true), null));

    $pretestsettings->add(new admin_setting_configtext('pretest/initialnumfeedbacks',
            get_string('initialnumfeedbacks', 'pretest'), get_string('initialnumfeedbacks_desc', 'pretest'),
            2, PARAM_INT, 5));

    // Allow user to specify if setting outcomes is an advanced setting.
    if (!empty($CFG->enableoutcomes)) {
        $pretestsettings->add(new admin_setting_configcheckbox('pretest/outcomes_adv',
            get_string('outcomesadvanced', 'pretest'), get_string('configoutcomesadvanced', 'pretest'),
            '0'));
    }

    // Autosave frequency.
    $pretestsettings->add(new admin_setting_configduration('pretest/autosaveperiod',
            get_string('autosaveperiod', 'pretest'), get_string('autosaveperiod_desc', 'pretest'), 60, 1));
}

// Now, depending on whether any reports have their own settings page, add
// the pretest setting page to the appropriate place in the tree.
if (empty($reportsbyname) && empty($rulesbyname)) {
    $ADMIN->add('modsettings', $pretestsettings);
} else {
    $ADMIN->add('modsettings', new admin_category('modsettingspretestcat',
            get_string('modulename', 'pretest'), $module->is_enabled() === false));
    $ADMIN->add('modsettingspretestcat', $pretestsettings);

    // Add settings pages for the pretest report subplugins.
    foreach ($reportsbyname as $strreportname => $report) {
        $reportname = $report;

        $settings = new admin_settingpage('modsettingspretestcat'.$reportname,
                $strreportname, 'moodle/site:config', $module->is_enabled() === false);
        include($CFG->dirroot . "/mod/pretest/report/$reportname/settings.php");
        if (!empty($settings)) {
            $ADMIN->add('modsettingspretestcat', $settings);
        }
    }

    // Add settings pages for the pretest access rule subplugins.
    foreach ($rulesbyname as $strrulename => $rule) {
        $settings = new admin_settingpage('modsettingspretestcat' . $rule,
                $strrulename, 'moodle/site:config', $module->is_enabled() === false);
        include($CFG->dirroot . "/mod/pretest/accessrule/$rule/settings.php");
        if (!empty($settings)) {
            $ADMIN->add('modsettingspretestcat', $settings);
        }
    }
}

$settings = null; // We do not want standard settings link.
