<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * PHPUnit data generator tests
 *
 * @package    mod_pretest
 * @category   phpunit
 * @copyright  2012 Matt Petro
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();


/**
 * PHPUnit data generator testcase
 *
 * @package    mod_pretest
 * @category   phpunit
 * @copyright  2012 Matt Petro
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_pretest_generator_testcase extends advanced_testcase {
    public function test_generator() {
        global $DB, $SITE;

        $this->resetAfterTest(true);

        $this->assertEquals(0, $DB->count_records('pretest'));

        /** @var mod_pretest_generator $generator */
        $generator = $this->getDataGenerator()->get_plugin_generator('mod_pretest');
        $this->assertInstanceOf('mod_pretest_generator', $generator);
        $this->assertEquals('pretest', $generator->get_modulename());

        $generator->create_instance(array('course'=>$SITE->id));
        $generator->create_instance(array('course'=>$SITE->id));
        $createtime = time();
        $pretest = $generator->create_instance(array('course' => $SITE->id, 'timecreated' => 0));
        $this->assertEquals(3, $DB->count_records('pretest'));

        $cm = get_coursemodule_from_instance('pretest', $pretest->id);
        $this->assertEquals($pretest->id, $cm->instance);
        $this->assertEquals('pretest', $cm->modname);
        $this->assertEquals($SITE->id, $cm->course);

        $context = context_module::instance($cm->id);
        $this->assertEquals($pretest->cmid, $context->instanceid);

        $this->assertEqualsWithDelta($createtime,
                $DB->get_field('pretest', 'timecreated', ['id' => $cm->instance]), 2);
    }
}
