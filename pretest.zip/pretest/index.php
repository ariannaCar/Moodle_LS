<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This script lists all the instances of pretest in a particular course
 *
 * @package    mod_pretest
 * @copyright  1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


require_once("../../config.php");
require_once("locallib.php");

$id = required_param('id', PARAM_INT);
$PAGE->set_url('/mod/pretest/index.php', array('id'=>$id));
if (!$course = $DB->get_record('course', array('id' => $id))) {
    print_error('invalidcourseid');
}
$coursecontext = context_course::instance($id);
require_login($course);
$PAGE->set_pagelayout('incourse');

$params = array(
    'context' => $coursecontext
);
$event = \mod_pretest\event\course_module_instance_list_viewed::create($params);
$event->trigger();

// Print the header.
$strpretestzes = get_string("modulenameplural", "pretest");
$PAGE->navbar->add($strpretestzes);
$PAGE->set_title($strpretestzes);
$PAGE->set_heading($course->fullname);
echo $OUTPUT->header();
echo $OUTPUT->heading($strpretestzes, 2);

// Get all the appropriate data.
if (!$pretestzes = get_all_instances_in_course("pretest", $course)) {
    notice(get_string('thereareno', 'moodle', $strpretestzes), "../../course/view.php?id=$course->id");
    die;
}

// Check if we need the feedback header.
$showfeedback = false;
foreach ($pretestzes as $pretest) {
    if (pretest_has_feedback($pretest)) {
        $showfeedback=true;
    }
    if ($showfeedback) {
        break;
    }
}

// Configure table for displaying the list of instances.
$headings = array(get_string('name'));
$align = array('left');

array_push($headings, get_string('pretestcloses', 'pretest'));
array_push($align, 'left');

if (course_format_uses_sections($course->format)) {
    array_unshift($headings, get_string('sectionname', 'format_'.$course->format));
} else {
    array_unshift($headings, '');
}
array_unshift($align, 'center');

$showing = '';

if (has_capability('mod/pretest:viewreports', $coursecontext)) {
    array_push($headings, get_string('attempts', 'pretest'));
    array_push($align, 'left');
    $showing = 'stats';

} else if (has_any_capability(array('mod/pretest:reviewmyattempts', 'mod/pretest:attempt'),
        $coursecontext)) {
    array_push($headings, get_string('grade', 'pretest'));
    array_push($align, 'left');
    if ($showfeedback) {
        array_push($headings, get_string('feedback', 'pretest'));
        array_push($align, 'left');
    }
    $showing = 'grades';

    $grades = $DB->get_records_sql_menu('
            SELECT qg.pretest, qg.grade
            FROM {pretest_grades} qg
            JOIN {pretest} q ON q.id = qg.pretest
            WHERE q.course = ? AND qg.userid = ?',
            array($course->id, $USER->id));
}

$table = new html_table();
$table->head = $headings;
$table->align = $align;

// Populate the table with the list of instances.
$currentsection = '';
// Get all closing dates.
$timeclosedates = pretest_get_user_timeclose($course->id);
foreach ($pretestzes as $pretest) {
    $cm = get_coursemodule_from_instance('pretest', $pretest->id);
    $context = context_module::instance($cm->id);
    $data = array();

    // Section number if necessary.
    $strsection = '';
    if ($pretest->section != $currentsection) {
        if ($pretest->section) {
            $strsection = $pretest->section;
            $strsection = get_section_name($course, $pretest->section);
        }
        if ($currentsection !== "") {
            $table->data[] = 'hr';
        }
        $currentsection = $pretest->section;
    }
    $data[] = $strsection;

    // Link to the instance.
    $class = '';
    if (!$pretest->visible) {
        $class = ' class="dimmed"';
    }
    $data[] = "<a$class href=\"view.php?id=$pretest->coursemodule\">" .
            format_string($pretest->name, true) . '</a>';

    // Close date.
    if (($timeclosedates[$pretest->id]->usertimeclose != 0)) {
        $data[] = userdate($timeclosedates[$pretest->id]->usertimeclose);
    } else {
        $data[] = get_string('noclose', 'pretest');
    }

    if ($showing == 'stats') {
        // The $pretest objects returned by get_all_instances_in_course have the necessary $cm
        // fields set to make the following call work.
        $data[] = pretest_attempt_summary_link_to_reports($pretest, $cm, $context);

    } else if ($showing == 'grades') {
        // Grade and feedback.
        $attempts = pretest_get_user_attempts($pretest->id, $USER->id, 'all');
        list($someoptions, $alloptions) = pretest_get_combined_reviewoptions(
                $pretest, $attempts);

        $grade = '';
        $feedback = '';
        if ($pretest->grade && array_key_exists($pretest->id, $grades)) {
            if ($alloptions->marks >= question_display_options::MARK_AND_MAX) {
                $a = new stdClass();
                $a->grade = pretest_format_grade($pretest, $grades[$pretest->id]);
                $a->maxgrade = pretest_format_grade($pretest, $pretest->grade);
                $grade = get_string('outofshort', 'pretest', $a);
            }
            if ($alloptions->overallfeedback) {
                $feedback = pretest_feedback_for_grade($grades[$pretest->id], $pretest, $context);
            }
        }
        $data[] = $grade;
        if ($showfeedback) {
            $data[] = $feedback;
        }
    }

    $table->data[] = $data;
} // End of loop over pretest instances.

// Display the table.
echo html_writer::table($table);

// Finish the page.
echo $OUTPUT->footer();
