<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Library code used by pretest cron.
 *
 * @package   mod_pretest
 * @copyright 2012 the Open University
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/pretest/locallib.php');


/**
 * This class holds all the code for automatically updating all attempts that have
 * gone over their time limit.
 *
 * @copyright 2012 the Open University
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class mod_pretest_overdue_attempt_updater {

    /**
     * Do the processing required.
     * @param int $timenow the time to consider as 'now' during the processing.
     * @param int $processto only process attempt with timecheckstate longer ago than this.
     * @return array with two elements, the number of attempt considered, and how many different pretestzes that was.
     */
    public function update_overdue_attempts($timenow, $processto) {
        global $DB;

        $attemptstoprocess = $this->get_list_of_overdue_attempts($processto);

        $course = null;
        $pretest = null;
        $cm = null;

        $count = 0;
        $pretestcount = 0;
        foreach ($attemptstoprocess as $attempt) {
            try {

                // If we have moved on to a different pretest, fetch the new data.
                if (!$pretest || $attempt->pretest != $pretest->id) {
                    $pretest = $DB->get_record('pretest', array('id' => $attempt->pretest), '*', MUST_EXIST);
                    $cm = get_coursemodule_from_instance('pretest', $attempt->pretest);
                    $pretestcount += 1;
                }

                // If we have moved on to a different course, fetch the new data.
                if (!$course || $course->id != $pretest->course) {
                    $course = $DB->get_record('course', array('id' => $pretest->course), '*', MUST_EXIST);
                }

                // Make a specialised version of the pretest settings, with the relevant overrides.
                $pretestforuser = clone($pretest);
                $pretestforuser->timeclose = $attempt->usertimeclose;
                $pretestforuser->timelimit = $attempt->usertimelimit;

                // Trigger any transitions that are required.
                $attemptobj = new pretest_attempt($attempt, $pretestforuser, $cm, $course);
                $attemptobj->handle_if_time_expired($timenow, false);
                $count += 1;

            } catch (moodle_exception $e) {
                // If an error occurs while processing one attempt, don't let that kill cron.
                mtrace("Error while processing attempt {$attempt->id} at {$attempt->pretest} pretest:");
                mtrace($e->getMessage());
                mtrace($e->getTraceAsString());
                // Close down any currently open transactions, otherwise one error
                // will stop following DB changes from being committed.
                $DB->force_transaction_rollback();
            }
        }

        $attemptstoprocess->close();
        return array($count, $pretestcount);
    }

    /**
     * @return moodle_recordset of pretest_attempts that need to be processed because time has
     *     passed. The array is sorted by courseid then pretestid.
     */
    public function get_list_of_overdue_attempts($processto) {
        global $DB;


        // SQL to compute timeclose and timelimit for each attempt:
        $pretestausersql = pretest_get_attempt_usertime_sql(
                "ipretesta.state IN ('inprogress', 'overdue') AND ipretesta.timecheckstate <= :iprocessto");

        // This query should have all the pretest_attempts columns.
        return $DB->get_recordset_sql("
         SELECT pretesta.*,
                pretestauser.usertimeclose,
                pretestauser.usertimelimit

           FROM {pretest_attempts} pretesta
           JOIN {pretest} pretest ON pretest.id = pretesta.pretest
           JOIN ( $pretestausersql ) pretestauser ON pretestauser.id = pretesta.id

          WHERE pretesta.state IN ('inprogress', 'overdue')
            AND pretesta.timecheckstate <= :processto
       ORDER BY pretest.course, pretesta.pretest",

                array('processto' => $processto, 'iprocessto' => $processto));
    }
}
