<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * adaptive course format. Display the whole course as "adaptive" made of modules.
 *
 * @package format_adaptive
 * @copyright 2006 The Open University
 * @author N.D.Freear@open.ac.uk, and others.
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/filelib.php');
require_once($CFG->libdir.'/completionlib.php');

global $PAGE, $DB;

// Horrible backwards compatible parameter aliasing.
if ($adaptives = optional_param('adaptives', 0, PARAM_INT)) {
    $url = $PAGE->url;
    $url->param('section', $adaptives);
    debugging('Outdated adaptives param passed to course/view.php', DEBUG_DEVELOPER);
    redirect($url);
}
// End backwards-compatible aliasing.

$context = context_course::instance($course->id);
// Retrieve course format option fields and add them to the $course object.
$course = course_get_format($course)->get_course();

if (($marker >= 0) && has_capability('moodle/course:setcurrentsection', $context) && confirm_sesskey()) {
    $course->marker = $marker;
    course_set_marker($course->id, $marker);
}

// Make sure section 0 is created.
course_create_sections_if_missing($course, 0);

require_once($CFG->dirroot.'/mod/pretest/lib.php');
$pretest =  pretest_get_course_pretest($course->id, $course->fullname);
if (empty($pretest)) {
    echo $OUTPUT->notification('Could not find the course pretest.');
}

require_once($CFG->dirroot.'/course/format/adaptive/locallib.php');
require_once($CFG->dirroot.'/course/renderer.php');
require_once($CFG->libdir.'/ajax/ajaxlib.php');

$context = context_course::instance($COURSE->id);
            $roles = get_user_roles($context, $USER->id, true);
            $role = key($roles);
            $rolename = $roles[$role]->shortname;

if($rolename != 'student'){

	$section = 0;
    $thissection = $sections[$section];

    if ($thissection->summary or $thissection->sequence or $PAGE->user_is_editing($course->id)) {
        echo '<tr id="section-0" class="section main">';
        echo '<td class="left side">&nbsp;</td>';
        echo '<td class="content">';
        
        echo '<div class="summary">';
        //$summaryformatoptions->noclean = true;
        //echo format_text($thissection->summary, FORMAT_HTML, $summaryformatoptions);

        if ($PAGE->user_is_editing($course->id) && has_capability('moodle/course:update', get_context_instance(CONTEXT_COURSE, $course->id))) {
            echo '<a title="'.$streditsummary.'" '.
                 ' href="editsection.php?id='.$thissection->id.'"><img src="'.$CFG->pixpath.'/t/edit.gif" '.
                 ' alt="'.$streditsummary.'" /></a><br /><br />';
        }
        echo '</div>';
        $courserenderer = $PAGE->get_renderer('core', 'course');
        $courserenderer->course_section_cm_list($course, $thissection, null, $modnamesused);
        if ($PAGE->user_is_editing($course->id)) {
            $courserenderer->course_section_add_cm_control($course, $section, null, $modnames);
        }

        echo '</td>';
        echo '<td class="right side">&nbsp;</td>';
        echo '</tr>';
        echo '<tr class="section separator"><td colspan="3" class="spacer"></td></tr>';
    }


/// Now all the normal modules by adaptive
/// Everything below uses "section" terminology - each "section" is a adaptive.

    $timenow = time();
    $section = 1;
    $sectionmenu = array();
    while ($section <= $course->numsections) {

        if (!empty($sections[$section])) {
            $thissection = $sections[$section];

        } else {
            unset($thissection);
            $thissection->course = $course->id;   // Create a new section structure
            $thissection->section = $section;
            $thissection->summary = '';
            $thissection->visible = 1;
            if (!$thissection->id = insert_record('course_sections', $thissection)) {
                notify('Error inserting new adaptive!');
            }
        }

        $showsection = (has_capability('moodle/course:viewhiddensections', $context) or $thissection->visible or !$course->hiddensections);

        if (!empty($displaysection) and $displaysection != $section) {
            if ($showsection) {
                $strsummary = strip_tags(format_string($thissection->summary,true));
                if (strlen($strsummary) < 57) {
                    $strsummary = ' - '.$strsummary;
                } else {
                    $strsummary = ' - '.substr($strsummary, 0, 60).'...';
                }
                $sectionmenu['adaptive='.$section] = s($section.$strsummary);
            }
            $section++;
            continue;
        }

        if ($showsection) {

            $currentpers = ($course->marker == $section);

            $currenttext = '';
            if (!$thissection->visible) {
                $sectionstyle = ' hidden';
            } else if ($currentpers) {
                $sectionstyle = ' current';
                $currenttext = get_accesshide(get_string('currentpers','access'));
            } else {
                $sectionstyle = '';
            }

            echo '<tr id="section-'.$section.'" class="section main'.$sectionstyle.'">';
            echo '<td class="left side">'.$currenttext.$section.'</td>';

            echo '<td class="content">';
            if (!has_capability('moodle/course:viewhiddensections', $context) and !$thissection->visible) {   // Hidden for students
                echo get_string('notavailable');
            } else {
                echo '<div class="summary">';
                $summaryformatoptions->noclean = true;
                echo format_text($thissection->summary, FORMAT_HTML, $summaryformatoptions);

                if ($PAGE->user_is_editing($course->id) && has_capability('moodle/course:update', get_context_instance(CONTEXT_COURSE, $course->id))) {
                    echo ' <a title="'.$streditsummary.'" href="editsection.php?id='.$thissection->id.'">'.
                         '<img src="'.$CFG->pixpath.'/t/edit.gif" alt="'.$streditsummary.'" /></a><br /><br />';
                }
                echo '</div>';

                print_section($course, $thissection, $mods, $modnamesused);

                if ($PAGE->user_is_editing($course->id)) {
                    print_section_add_menus($course, $section, $modnames);
                }
            }
            echo '</td>';

            echo '<td class="right side">';
            if ($displaysection == $section) {      // Show the zoom boxes
                echo '<a href="view.php?id='.$course->id.'&amp;adaptive=0#section-'.$section.'" title="'.$strshowallperss.'">'.
                     '<img src="'.$CFG->pixpath.'/i/all.gif" alt="'.$strshowallperss.'" /></a><br />';
            } else {
                $strshowonlypers = get_string('showonlypers', '', $section);
                echo '<a href="view.php?id='.$course->id.'&amp;adaptive='.$section.'" title="'.$strshowonlypers.'">'.
                     '<img src="'.$CFG->pixpath.'/i/one.gif" alt="'.$strshowonlypers.'" /></a><br />';
            }

            if ($PAGE->user_is_editing($course->id) && has_capability('moodle/course:update', get_context_instance(CONTEXT_COURSE, $course->id))) {
                if ($course->marker == $section) {  // Show the "light globe" on/off
                    echo '<a href="view.php?id='.$course->id.'&amp;marker=0&amp;sesskey='.$USER->sesskey.'#section-'.$section.'" title="'.$strmarkedthispers.'">'.
                         '<img src="'.$CFG->pixpath.'/i/marked.gif" alt="'.$strmarkedthispers.'" /></a><br />';
                } else {
                    echo '<a href="view.php?id='.$course->id.'&amp;marker='.$section.'&amp;sesskey='.$USER->sesskey.'#section-'.$section.'" title="'.$strmarkthispers.'">'.
                         '<img src="'.$CFG->pixpath.'/i/marker.gif" alt="'.$strmarkthispers.'" /></a><br />';
                }

                if ($thissection->visible) {        // Show the hide/show eye
                    echo '<a href="view.php?id='.$course->id.'&amp;hide='.$section.'&amp;sesskey='.$USER->sesskey.'#section-'.$section.'" title="'.$strpershide.'">'.
                         '<img src="'.$CFG->pixpath.'/i/hide.gif" alt="'.$strpershide.'" /></a><br />';
                } else {
                    echo '<a href="view.php?id='.$course->id.'&amp;show='.$section.'&amp;sesskey='.$USER->sesskey.'#section-'.$section.'" title="'.$strpersshow.'">'.
                         '<img src="'.$CFG->pixpath.'/i/show.gif" alt="'.$strpersshow.'" /></a><br />';
                }

                if ($section > 1) {                       // Add a arrow to move section up
                    echo '<a href="view.php?id='.$course->id.'&amp;random='.rand(1,10000).'&amp;section='.$section.'&amp;move=-1&amp;sesskey='.$USER->sesskey.'#section-'.($section-1).'" title="'.$strmoveup.'">'.
                         '<img src="'.$CFG->pixpath.'/t/up.gif" alt="'.$strmoveup.'" /></a><br />';
                }

                if ($section < $course->numsections) {    // Add a arrow to move section down
                    echo '<a href="view.php?id='.$course->id.'&amp;random='.rand(1,10000).'&amp;section='.$section.'&amp;move=1&amp;sesskey='.$USER->sesskey.'#section-'.($section+1).'" title="'.$strmovedown.'">'.
                         '<img src="'.$CFG->pixpath.'/t/down.gif" alt="'.$strmovedown.'" /></a><br />';
                }

            }

            echo '</td></tr>';
            echo '<tr class="section separator"><td colspan="3" class="spacer"></td></tr>';
        }

        $section++;
		}
        set_Ki($course->id);
        set_adaptive_goal($course->id);
}
else{//else dell'if aggiunto da noi
    /* Controllare se nella tabella testLS_users è presente il record riferito allo studente:
     * SI: Non visualizza il questionario
     * NO: Visualizza il questionario,per cui il modulo relativo scriverà su testLS_users
     * */
    
/*     if($DB->get_field('plugin2','id', array('userid',$USER->id))!=false){
        $module=$DB->get_record('modules','name','testLS');//ritorna l'id della tabella modules relativo a quel modulo
        $cm=$DB->get_record('course_modules','module',$module,'course',$course->id);
        $mods[$cm->id]='';
    }/*------------------------------------------------
     /*
     * controllare se nel log di lsplan ci sono record per studente e corso
     *      NO:controllare se nel log di moodle è stata svolta un'attività quiz
     *          NO:mostra test iniziale(array con solo 0)
     *          SI:correzione del test inziale, chiamata lsplan(recuperando i LS memorizzati in testLS_users) e log nella tabella di lsplan, scrittura del corso personalizzato nella tabella adaptive_course_pers
     *              e riempimento dell'array
     *      SI:Dalla tabella log di moodle selezioniamo l'ultima azione dello studente relativa al nostro corso: E' quiz?
                SI: action<>'close attempt'?:
                *   SI:recupera il corso gia' personalizzato nel db
                    NO:Verifica se nel log di lsplan è stata fatta la chiamata per quel quiz(con il time di log):
                    *   SI:recupera il corso gia' personalizzato nel db
                    *   NO: chiamata lsplan e log nella tabella di lsplan, scrittura del corso personalizzato nella tabella adaptive_course_pers
     *                      e riempimento dell'array
     *          NO: Verificare se esiste test per quella risorsa:
     *              SI:recupera il corso gia' personalizzato nel db
                    NO: chiamata lsplan e log nella tabella di lsplan, scrittura del corso personalizzato nella tabella adaptive_course_pers
     *                      e riempimento dell'array
    
    
    */
    $sequence=array();
    $msg='';
    if($DB->get_record('adaptive_log_lsplan', array('userid'=>$USER->id,'course'=>$course->id))==false){//verifica se e' gia' stato chiamato lsplan
        //Se lsplan non e' mai stato chiamato, si deve verificare se e' stato svolto il test iniziale o se va mostrato
        $log=get_record_last_action($course->id,$USER->id);//restituisce il record relativo all'ultima azione dello studente nella navigazione di tutto moodle(es:login,ecc)
        if($log->module!='quiz')//lo studente ha fatto un quiz, cioe' il test iniziale
            $sequence=array();//per visualizzare solo la sezione 0
    //    else{//fatto test iniziale,quindi correzione del test iniziale
            $cm=$DB->get_record('course_modules',array('id'=>$log->cmid));//record della tabella course_modules
            $cs=correction_initial_test($cm->instance,$USER->id, $course->id);//parametri:id del quiz e userid, ritorna:cs nella forma ki_level,...
            $ls=$DB->get_record('plugin2', array('userid'=>$USER->id));
            //NOTA:l'explode va usato selezionando l'ultimo _ per permettere ki con _
            $goal=get_goal($course->id);//riciclare getKi di teacher, solo che questo deve ritornare una stringa di tutti i ki separati da ,:ki_level,...
            call_lsplan($USER->$id,$cs,$course->id,$ls,$goal);//configurazione corso iniziale tipo operazione 1
            $lsplan->userid=$USER->id;
            $lsplan->course=$course->id;
            $lsplan->cmid=$cm->id;
            $lsplan->section=0;//section=idLN:non essendo un LN(non abbiamo id LN) mettiamo 0
            $lsplan->ln_type='testiniziale';
            $lsplan->time=$log->time;
            insert_record("adaptive_log_lsplan",$lsplan);
            $file=read_output_lsplan();//legge il file di testo prodotto da lsplan:ritorna un array:0 c'e' il los, 1 il msg, rispettivamente 2° e 3° riga del file
            $los=$file[0];
            $msg=$file[1];
            $corsoPers->userid=$USER->id;
            $corsoPers->course=$course->id;
            $corsoPers->los=$los;
            insert_record("adaptive_course_pers",$corsoPers);
            $sequence=explode(",",$los);
            /*$sequence=array();
            for($i<0;$i<count($seq);$i++){
                $sequence[$i]=$seq[$i];
            }*/
    //    }
    }else{//gia' fatto e corretto il test iniziale
        $log=get_last_course_action($course->id,$USER->id);//restituisce il record relativo all'ultima azione dello studente SOLO nella navigazione del corso
        if($log->module=='quiz'){
            if($log->action!='close attempt'){//Non ha sottomesso il quiz, quindi corso invariato
                $los=get_record('adaptive_course_pers','userid',$USER->id,'course',$course->id);
                $sequence=explode(",",$los->los);
            }
            else{ //ha sottomesso il quiz, chiamata lsplan?
                //$chiamata=get_record("adaptive_log_lsplan",'userid',$USER->id,'course',$course->id,'time',$log->time);
                $chiamata=get_last_call($USER->id,$course->id,$log->cmid);//ritorna il tempo dell'ultima chiamata a lsplan relativa a quel cmid
                if($chiamata==$log->time){//E' stata fatta la chiamata a lsplan?
                    //chiamata gia' effettuata
                    $los=get_record('adaptive_course_pers','userid',$USER->id,'course',$course->id);
                    $sequence=explode(",",$los->los);
                }
                else{//effettuare la chiamata a lsplan
                    $cm=get_record('course_modules','id',$log->cmid);
                    $idQuiz=$cm->instance;
                    $sumgrades=get_field('quiz_attempts','sumgrades','quiz',$idQuiz);
                    //da vedere se sumgrades va normalizzato(e come)
                    $score=$sumgrades;
                    $course_section=get_record('course_sections','id',$cm->section);
                    $section=$course_section->section;
                    $lns=$course_section->sequence;
                    $lnArray=explode(",",$lns);
                    $ln=-1;
                    $i=0;
                    while($i<count($lnArray) && $ln==-1)
                        $ln=isLN($lnArray[$i]);//controlla se il cmid passato e' di un ln:si ritorna lo stesso cmid, no ritorna -1
                        $i++;
                    }
                    //$log=get_record('log','cmid',$ln);
                    //$timeStart=get_field('log','time','cmid',$ln,'userid',$USER->id,'action','view');//tempo di accesso alla risorsa
                    $timeStart=get_fieldset_select('log','time','cmid='.$ln.' AND userid='.$USER->id." AND action='view' AND time>".$chiamata->time);//la ricerca parte da time maggiori di quello dell'ultima chiamata quindi e' l'ultimo tentativo del LN
                    //action='view' anche per scorm perche' il primo record che trova e' relativo al primo sco
                    $timeFinish=get_fieldset_select('log','time','userid='.$USER->id.' AND time>'.$timeStart.' AND cmid<>'.$ln);//tempo di "uscita" dalla risorsa, ovvero azione successiva
                    $fruitionTime=$timeFinish-$timeStart;//e' in secondi
                    call_lsplan($USER->id,$section,$course->id,$score,$fruitionTime);
                    $lsplan->userid=$USER->id;
                    $lsplan->course=$course->id;
                    $lsplan->cmid=$cm->id;
                    $lsplan->section=$section;
                    $lsplan->ln_type='quiz';
                    $lsplan->time=$log->time;
                    insert_record("adaptive_log_lsplan",$lsplan);
                    $file=read_output_lsplan();//legge il file di testo prodotto da lsplan:ritorna un array:0 c'e' il los, 1 il msg, rispettivamente 2° e 3° riga del file
                    $los=$file[0];
                    $msg=$file[1];
                    $corsoPers=get_record("adaptive_course_pers",'userid',$USER->id,'course',$course->id);
                    $corsoPers->los=$los;
                    update_record("adaptive_course_pers",$corsoPers);
                    $sequence=explode(",",$los);
                }
            }
        else{//risorsa
                $cm=get_record('course_modules','id',$log->cmid);
                $course_section=get_record('course_sections','id',$cm->section);
                if(exist_test($course_section->section,$course_section->course)==true){//risorsa con test non effettuato, quindi visualizzazione del corso
                    $los=get_record('adaptive_course_pers','userid',$USER->id,'course',$course->id);
                    $sequence=explode(",",$los->los);
                }
                else{
                    $chiamata=get_last_call($USER->id,$course->id,$log->cmid);
                    if($chiamata==$log->time){//E' stata fatta la chiamata a lsplan?
                        //chiamata gia' effettuata
                        $los=get_record('adaptive_course_pers','userid',$USER->id,'course',$course->id);
                        $sequence=explode(",",$los->los);
                    }
                    else{
                        $section=$course_section->section;
                        $ln=$log->cmid;
                        //$log=get_record('log','cmid',$ln);
                        $timeStart=get_fieldset_select('log','time','cmid='.$ln.' AND userid='.$USER->id." AND action='view' AND time>".$chiamata->time);//la ricerca parte da time maggiori di quello dell'ultima chiamata quindi e' l'ultimo tentativo del LN
                        //action='view' anche per scorm perche' il primo record che trova e' relativo al primo sco
                        $timeFinish=get_fieldset_select('log','time','userid='.$USER->id.' AND time>'.$timeStart.' AND cmid<>'.$ln);//tempo di "uscita" dalla risorsa, ovvero azione successiva
                        $fruitionTime=$timeFinish-$timeStart;//e' in secondi
                        call_lsplan($USER->id,$section,$course->id,0,$fruitionTime);
                        $lsplan->userid=$USER->id;
                        $lsplan->course=$course->id;
                        $lsplan->cmid=$cm->id;
                        $lsplan->section=$section;
                        $lsplan->ln_type='resource';
                        $lsplan->time=$log->time;
                        insert_record("adaptive_log_lsplan",$lsplan);
                        $file=read_output_lsplan();//legge il file di testo prodotto da lsplan:ritorna un array:0 c'e' il los, 1 il msg, rispettivamente 2° e 3° riga del file
                        $los=$file[0];
                        $msg=$file[1];
                        $corsoPers=get_record("adaptive_course_pers",'userid',$USER->id,'course',$course->id);
                        $corsoPers->los=$los;
                        update_record("adaptive_course_pers",$corsoPers);
                        $sequence=explode(",",$los);        
                    }
                }
        }
    }   
    
       
    $section = 0;
    $thissection = $sections[$section];

    if ($thissection->summary or $thissection->sequence or $PAGE->user_is_editing($course->id)) {
        echo "<tr> $msg </tr>"; //stampa del messaggio di lsplan da valorizzare quando viene effetuata la chiamata a lsplan
        echo '<tr id="section-0" class="section main">';
        echo '<td class="left side">&nbsp;</td>';
        echo '<td class="content">';
        
        echo '<div class="summary">';
        //$summaryformatoptions->noclean = true;
        //echo format_text($thissection->summary, FORMAT_HTML, $summaryformatoptions);

        if ($PAGE->user_is_editing($course->id) && has_capability('moodle/course:update', get_context_instance(CONTEXT_COURSE, $course->id))) {
            echo '<a title="'.$streditsummary.'" '.
                 ' href="editsection.php?id='.$thissection->id.'"><img src="'.$CFG->pixpath.'/t/edit.gif" '.
                 ' alt="'.$streditsummary.'" /></a><br /><br />';
        }
        echo '</div>';
        //$mods[162]='';
        /*Oscurare il modulo relativo al test iniziale e LS NB:l'indice di mods è l'id di cm*/
        $courserenderer = $PAGE->get_renderer('core', 'course');
        $courserenderer->course_section_cm_list($course, $thissection, null, $modnamesused);
        if ($PAGE->user_is_editing($course->id)) {
            print_section_add_menus($course, $section, $modnames);
        }

        echo '</td>';
        echo '<td class="right side">&nbsp;</td>';
        echo '</tr>';
        echo '<tr class="section separator"><td colspan="3" class="spacer"></td></tr>';
    }


/// Now all the normal modules by adaptive
/// Everything below uses "section" terminology - each "section" is a adaptive.

    $timenow = time();
    $section = 1;
    $sectionmenu = array();
    //si usa un'array che rappresenta la sequenza delle sezioni, ossia il los fornito da ls-plan
    //qui vengono aggiunti manualmente per fare un esempio
    $sequence = array(3,4,1);//gli indici dell'array sono i valori di section della tabella course_sections
    //$count è un contatore per determinare l'iesimo concetto della sequenza che si sta stampando
    $count=0;
    //$section parte dal primo elemento riportato nella sequenza e non sempre da 1
    $section=$sequence[$count];
    if($sequence[0]!='-'){
    //la condizione della while è che $section deve essere minore della lunghezza dell'array,ossia il # di sezioni(concetti)da mostrare
        while ($count < count($sequence)) {

            if (!empty($sections[$section])) {
                $thissection = $sections[$section];

            } else {
                unset($thissection);
                $thissection->course = $course->id;   // Create a new section structure
                $thissection->section = $section;
                $thissection->summary = '';
                $thissection->visible = 1;
                if (!$thissection->id = insert_record('course_sections', $thissection)) {
                    notify('Error inserting new adaptive!');
                }
            }

            $showsection = (has_capability('moodle/course:viewhiddensections', $context) or $thissection->visible or !$course->hiddensections);

            if (!empty($displaysection) and $displaysection != $section) {
                if ($showsection) {
                    $strsummary = strip_tags(format_string($thissection->summary,true));
                    if (strlen($strsummary) < 57) {
                        $strsummary = ' - '.$strsummary;
                    } else {
                        $strsummary = ' - '.substr($strsummary, 0, 60).'...';
                    }
                    $sectionmenu['adaptive='.$section] = s($section.$strsummary);
                }
              //bisogna incrementare $count e prendere il corrispondente concetto(sezione) alla posizione indicata dal count
                        $count++;
                    $section=$sequence[$count];
                continue;
            }

            if ($showsection) {

                $currentpers = ($course->marker == $section);

                $currenttext = '';
                if (!$thissection->visible) {
                    $sectionstyle = ' hidden';
                } else if ($currentpers) {
                    $sectionstyle = ' current';
                    $currenttext = get_accesshide(get_string('currentpers','access'));
                } else {
                    $sectionstyle = '';
                }

                echo '<tr id="section-'.$section.'" class="section main'.$sectionstyle.'">';
                echo '<td class="left side">'.$currenttext.$section.'</td>';

                echo '<td class="content">';
                if (!has_capability('moodle/course:viewhiddensections', $context) and !$thissection->visible) {   // Hidden for students
                    echo get_string('notavailable');
                } else {
                    echo '<div class="summary">';
                    //$summaryformatoptions->noclean = true;
                    //echo format_text($thissection->summary, FORMAT_HTML, $summaryformatoptions);

                    if ($PAGE->user_is_editing($course->id) && has_capability('moodle/course:update', get_context_instance(CONTEXT_COURSE, $course->id))) {
                        echo ' <a title="'.$streditsummary.'" href="editsection.php?id='.$thissection->id.'">'.
                             '<img src="'.$CFG->pixpath.'/t/edit.gif" alt="'.$streditsummary.'" /></a><br /><br />';
                    }
                    echo '</div>';

                    $courserenderer = $PAGE->get_renderer('core', 'course');
                    $courserenderer->course_section_cm_list($course, $thissection, null, $modnamesused);

                    if ($PAGE->user_is_editing($course->id)) {
                        print_section_add_menus($course, $section, $modnames);
                    }
                }
                echo '</td>';

                echo '<td class="right side">';
                if ($displaysection == $section) {      // Show the zoom boxes
                    echo '<a href="view.php?id='.$course->id.'&amp;adaptive=0#section-'.$section.'" title="'.$strshowallperss.'">'.
                         '<img src="'.$CFG->pixpath.'/i/all.gif" alt="'.$strshowallperss.'" /></a><br />';
                } else {
                    $strshowonlypers = get_string('showonlypers', '', $section);
                    echo '<a href="view.php?id='.$course->id.'&amp;adaptive='.$section.'" title="'.$strshowonlypers.'">'.
                         '<img src="'.$CFG->pixpath.'/i/one.gif" alt="'.$strshowonlypers.'" /></a><br />';
                }

                if ($PAGE->user_is_editing($course->id) && has_capability('moodle/course:update', get_context_instance(CONTEXT_COURSE, $course->id))) {
                    if ($course->marker == $section) {  // Show the "light globe" on/off
                        echo '<a href="view.php?id='.$course->id.'&amp;marker=0&amp;sesskey='.$USER->sesskey.'#section-'.$section.'" title="'.$strmarkedthispers.'">'.
                             '<img src="'.$CFG->pixpath.'/i/marked.gif" alt="'.$strmarkedthispers.'" /></a><br />';
                    } else {
                        echo '<a href="view.php?id='.$course->id.'&amp;marker='.$section.'&amp;sesskey='.$USER->sesskey.'#section-'.$section.'" title="'.$strmarkthispers.'">'.
                             '<img src="'.$CFG->pixpath.'/i/marker.gif" alt="'.$strmarkthispers.'" /></a><br />';
                    }

                    if ($thissection->visible) {        // Show the hide/show eye
                        echo '<a href="view.php?id='.$course->id.'&amp;hide='.$section.'&amp;sesskey='.$USER->sesskey.'#section-'.$section.'" title="'.$strpershide.'">'.
                             '<img src="'.$CFG->pixpath.'/i/hide.gif" alt="'.$strpershide.'" /></a><br />';
                    } else {
                        echo '<a href="view.php?id='.$course->id.'&amp;show='.$section.'&amp;sesskey='.$USER->sesskey.'#section-'.$section.'" title="'.$strpersshow.'">'.
                             '<img src="'.$CFG->pixpath.'/i/show.gif" alt="'.$strpersshow.'" /></a><br />';
                    }

                    if ($section > 1) {                       // Add a arrow to move section up
                        echo '<a href="view.php?id='.$course->id.'&amp;random='.rand(1,10000).'&amp;section='.$section.'&amp;move=-1&amp;sesskey='.$USER->sesskey.'#section-'.($section-1).'" title="'.$strmoveup.'">'.
                             '<img src="'.$CFG->pixpath.'/t/up.gif" alt="'.$strmoveup.'" /></a><br />';
                    }

                    if ($section < $course->numsections) {    // Add a arrow to move section down
                        echo '<a href="view.php?id='.$course->id.'&amp;random='.rand(1,10000).'&amp;section='.$section.'&amp;move=1&amp;sesskey='.$USER->sesskey.'#section-'.($section+1).'" title="'.$strmovedown.'">'.
                             '<img src="'.$CFG->pixpath.'/t/down.gif" alt="'.$strmovedown.'" /></a><br />';
                    }

                }

                echo '</td></tr>';
                echo '<tr class="section separator"><td colspan="3" class="spacer"></td></tr>';
            }

           //bisogna incrementare $count e prendere il corrispondente concetto(sezione) alla posizione indicata dal count
                        $count++;
                    $section=$sequence[$count];
            }
        
    }
}


$renderer = $PAGE->get_renderer('format_adaptive');

if (!empty($displaysection)) {
    $renderer->print_single_section_page($course, null, null, null, null, $displaysection);
} else {
    $renderer->print_multiple_section_page($course, null, null, null, null);
}

// Include course format js module.
$PAGE->requires->js('/course/format/adaptive/format.js');
