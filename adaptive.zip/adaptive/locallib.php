﻿<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * This file contains general functions for the course format adaptive
 *
 * @since 2.0
 * @package moodlecore
 * @copyright 2009 Sam Hemelryk
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


/**
 * Used to display the course structure for a course where format=adaptive
 *
 * This is called automatically by {@link load_course()} if the current course
 * format = weeks.
 *
 * @param array $path An array of keys to the course node in the navigation
 * @param stdClass $modinfo The mod info object for the current course
 * @return bool Returns true
 */

function callback_adaptives_load_content(&$navigation, $keys, $course) {
    $navigation->add_course_section_generic($keys, $course, get_string('adaptive'), 'adaptive');
}

/**
 * Used to display the course structure for a course where format=adaptive
 *
 * This is called automatically by {@link load_course()} if the current course
 * format = weeks and the navigation was requested via AJAX
 *
 * @param array $path An array of keys to the course node in the navigation
 * @param stdClass $modinfo The mod info object for the current course
 * @return bool Returns true
 */
function callback_adaptives_load_limited_section(&$navigation, $keys, $course, $section) {
    $navigation->limited_load_section_generic($keys, $course, $section, get_string('adaptive'), 'adaptive');
}

/**
 * The string that is used to describe a section of the course
 * e.g. adaptive, Week...
 *
 * @return string
 */
function callback_adaptives_definition() {
    return get_string('adaptive');
}

/**
 * The GET argument variable that is used to identify the section being
 * viewed by the user (if there is one)
 *
 * @return string
 */
function callback_adaptive_request_key() {
    return 'adaptive';
}

//aggiunto da me


//tramite un join tra log e teacherassistent_attivita ritorna l'ultima
//azione svolta dall'utente con id $user nel corso con id $course
//NOTA:Questa funzione non considera qualsiasi elemento nella section 0
//dato che non è presente il teacherassistant che si occupa di compilare 
//la tabella teachersassistant_attivita_corso
function get_last_course_action($course,$user){
	global $CFG,$DB;
	$prefix=$CFG->prefix;
	$param = array('cmid',$course,$user,'0');
	$sql="SELECT * FROM {log} WHERE time=(SELECT max(time) from {log} inner join {teacherassistent_attivita} on id_cm=? where course= ? and userid= ? and cmid<> ?)";
	//print_r($sql);
	$record=$DB->get_record_sql($sql,$param);
	if($record->module=='quiz'){
		//$where="time<=$record->time AND action='close attempt' AND id>$record->id-4";//per alleggerire il ciclo
		$where="time<=$record->time AND id>$record->id-4";
		$records=$DB->get_records_select("log",$where);
		//print_object($record);
		$close=0;
		
		foreach($records as $r)
		
			if($r->action=='close attempt')
				$close=$r->id;
		//print_object($record[$max]);
		if($close>0)
			return $records[$close];
	}
	
	return $record;
}
//ritorna l'istante di tempo dell'ultima chiamata a lsplan dovuta
//al termine di una risorsa con cmid pari a $cmid, visitata da un utente
//con id $user del corso con id $course
function get_last_call($user,$course,$cmid){//ritorna il tempo dell'ultima chiamata a lsplan relativa a quel cmid
	global $CFG,$DB;
	$prefix=$CFG->prefix;
	$param = array($course,$user,$cmid);
	$sql="SELECT max(time) as time FROM {adaptive_log_lsplan} WHERE course=? and userid=? and cmid=?";
	//print_r("$sql \n");
	$record=$DB->get_record_sql($sql,$param);
	//print_object($record);
	return $record->time;
}
//controlla se il cmid $cmid passato e' di un ln:si ritorna lo stesso $cmid, altrimenti ritorna -1
function isLN($cmid){
	global $DB;
	$quiz=$DB->get_field("modules","id",array("name"=>"quiz"));
	$ta=$DB->get_field("modules","id",array("name"=>"teacherassistant"));
	$module=$DB->get_field("course_modules","module",array("id"=>$cmid));
	if($module!=$quiz && $module!=$ta)
		return $cmid;
	return -1;
}
//ritorna un booleano a seconda dell'esistenza o meno di un test per quella risorsa, ossia all'interno della sezione che contiene il materiale didattico
function exist_test($section,$course){
	global $DB;
	$records=$DB->get_records_select("teacherassistent_attivita","section=$section AND id_course=$course");
	foreach($records as $record){
		if($record->type_activity=='quiz')
			return true;	
	}
	return 0;
}

//Ritorna il tempo di fruizione del LN con cmid $ln:il tempo di fruizione e' in secondi
function get_fruition_time($ln,$userid,$lastCallTime){
	global $DB;
	
	if($lastCallTime=='' || $lastCallTime==' ')
		$lastCallTime=0;
	
	$record=$DB->get_record_select('log','cmid='.$ln.' AND userid='.$userid." AND action='view' AND time>".$lastCallTime);//la ricerca parte da time maggiori di quello dell'ultima chiamata quindi e' l'ultimo tentativo del LN
	$timeStart=$record->time;
	if(!$timeStart)
		return 0;
	

	
	
	
	$record=$DB->get_record_select('log','userid='.$userid.' AND time>'.$timeStart.' AND cmid<>'.$ln);
	$timeFinish=$record->time;
	$fruitionTime=$timeFinish-$timeStart;
	
	return $fruitionTime;
}

//effettua la prima chiamata di lsplan. Per fare questo elabora opportunamente le varie informazioni da mandare in input a lsplan, calcolando il goal richiesto e il CS
function first_call_lsplan($user,$cs,$recordLS,$goal,$course){
	$ls='';
	if(empty($recordLS))
		$ls='0^0^0^0';
	else{	
		
		$ls=$recordLS->activereflective.'^';
		$ls.=$recordLS->sensingintuitive.'^';
		$ls.=$recordLS->visualverbal.'^';
		$ls.=$recordLS->sequentialglobal;
		
	}
	$goal=explode(",",$goal);
	$goalKI='';
	$goalLevel='';
	if($goal[0]!=''){//Vuol dire che il goal non e' vuoto(riciclare per cs)
		$pos=strrpos($goal[0],"_");
		$goalKI=substr($goal[0],0,$pos);
		$goalLevel=substr($goal[0],$pos+1);
		for($i=1;$i<count($goal);$i++){
			$pos=strrpos($goal[$i],"_");
			$goalKI.=','.substr($goal[$i],0,$pos);
			$goalLevel.=','.substr($goal[$i],$pos+1);
		}
	}
	$cs=explode(',',$cs);
	$csKI='';
	$csLevel='';
	if($cs[0]!=''){//Vuol dire che il CS non e' vuoto
		$pos=strrpos($cs[0],"_");
		$csKI=substr($cs[0],0,$pos);
		$csLevel=substr($cs[0],$pos+1);
		for($i=1;$i<count($cs);$i++){
			$pos=strrpos($cs[$i],"_");
			$csKI.=','.substr($cs[$i],0,$pos);
			$csLevel.=','.substr($cs[$i],$pos+1);
		}
	}
	else{
			$csKI='empty';
			$csLevel='empty';
	}
	$prefix="./format/adaptive/lsplan";
	$dir=getcwd();
	chdir($prefix);
	require_once("./src/Lsplan.php");
	$nome=str_replace(" ","_",$user->firstname);
	$cognome=str_replace(" ","_",$user->lastname);
    //$classpath="$prefix/classes:$prefix/classes/fiji.jar:$prefix/classes/mysql-connector-java-5.1.6-bin.jar";
    //per ora il cs rimane empty, poi dovra' essere gestito come ora e' gestito il goal
    
	$info='1^'.$user->id.'^'.$csKI.'^'.$csLevel.'^'.$ls.'^'.$nome.'^'.$cognome.'^'.$goalKI.'^'.$goalLevel.'^'.$course;
	Lsplan::main($info);
	restore_connection_DB();
	chdir($dir);
	//echo $command;
	//exec($command);
	return $info;
}
//ritorna una stringa che rappresenta la sequenza di id dei record della tabella course_modules delle istanze degli elementi che sono nella sezione.
function get_sequence($section,$course){
        global $DB;
	$sequence = $DB->get_field("course_sections","sequence",array('course'=> $course,'section'=> $section));
	return explode(",",$sequence);
}
//ritorna il cmid, ossia l'id del record della tabella course_modules relativo al test iniziale del corso, verificando il tipo di attività ogni elemento della sezione 0, ritornando il cmid dell'istanza che è di tipo 'quiz'.
function getCmidTestIniziale($course){
    global $DB;
	$sequence=get_sequence(0,$course);
	for($i=0;$i<count($sequence);$i++){
		$moduleid=$DB->get_field('course_modules','module',array('id'=>$sequence[$i]));
		$type=$DB->get_field('modules','name',array('id'=>$moduleid));
		if($type=='quiz')
				return $sequence[$i];
	}
}	


//imposta e aggiorna i ki nella tabella teacherassistant_domain
function set_Ki($course){
	global $DB;

	$sections = $DB->get_fieldset_select("graph", 'section', 'course='.$course);


	//cancella righe dal database relative a corsi non più presenti

	$identificativi = $DB->get_fieldset_select("teacherassistant_domain", 'id', null);
	foreach ($identificativi as $i) {
		$corso = $DB->get_field('teacherassistant_domain','id_course',array('id'=>$i));
		if(empty($DB->get_record("course",array('id'=>$corso)))){
			$DB->delete_records('teacherassistant_domain',array('id_course'=>$corso));
		}
	}

	$dimensione = count($sections);


	for($s = 0; $s<$dimensione; $s++){

	$sezione = $sections[$s];
	$riga = $DB->get_record("teacherassistant_domain", array('id_course'=>$course, 'section'=>$sezione));
	$ak = $DB->get_field("graph", 'name', array('course'=>$course, 'section'=>$sezione));
	$rk = $DB->get_field("graph", 'prerequisiti', array('course'=>$course, 'section'=>$sezione));

	if(empty($riga)){

		if(empty($identificativi)){
			$nuovoId = 1;
		}
		else{
			$idMax = max($identificativi);
			$nuovoId = $idMax+1;
		}
		$ins = (object)array('id' => $nuovoId, 'section'=> $sezione ,'id_course' => $course, 'ak'=> $ak, 'aklevels'=> '', 'rk'=> $rk, 'rklevels'=> '');
		$DB->insert_record("teacherassistant_domain", $ins);
	}
	else{
		$DB->set_field("teacherassistant_domain",'ak',$ak, array('id_course'=>$course,'section'=>$sezione));
		$DB->set_field("teacherassistant_domain",'rk',$rk, array('id_course'=>$course,'section'=>$sezione));
		}
	}

}

//imposta e aggiorna i ki della tabella adaptive_goal
function set_adaptive_goal($course){
	global $DB;

	$studentiIscritti = enrol_get_course_users($course);
	$arrayStudenti = array_keys($studentiIscritti);
	$idStudenti = [];

	for($i=0; $i<count($arrayStudenti); $i++){
		array_push($idStudenti, $studentiIscritti[$arrayStudenti[$i]]->id);
	}


	$identificativi = $DB->get_fieldset_select("adaptive_goal", 'id', null); //chiavi della tabella daptive_goal
	foreach ($identificativi as $i) {
		$corso = $DB->get_field('adaptive_goal','course',array('id'=>$i));
		if(empty($DB->get_record("course",array('id'=>$corso)))){
			$DB->delete_records('adaptive_goal',array('course'=>$corso));
		}
	}

	//se non è già presente aggiungi una riga al database relativa al corso corrente
	for($j = 0; $j<count($idStudenti); $j++){
		if(!$DB->get_record("adaptive_goal", array('course'=>$course, 'studentid'=> $idStudenti[$j]))){

			for($k= 0; $k<count($idStudenti); $k++){
				if(empty($identificativi)){
					$nuovoId = 1;
				}
				else{
					$idMax = max($identificativi);
					$nuovoId = $idMax+1;
				}
				if(!$DB->get_record("adaptive_goal", array('course'=>$course, 'studentid'=> $idStudenti[$j]))){
					$ins = (object)array('id' => $nuovoId, 'studentid'=> $idStudenti[$k] , 'course' => $course, 'ak'=> '', 'rk'=> '');
					$DB->insert_record("adaptive_goal", $ins);
				}
			}	
		}
		else{

			$array_definitivo = [];
			$rk = $DB->get_fieldset_select("teacherassistant_domain", 'ak', 'id_course='.$course);
			var_dump($rk);
			for($r = 0; $r<count($rk); $r++){
				$rk_nuovo = explode(";", $rk[$r]);
				for($n = 0; $n<count($rk_nuovo); $n++){
					array_push($array_definitivo, $rk_nuovo[$n]);
				}
			}

			$array_unico = array_unique($array_definitivo);
			$array_finale = implode(';', $array_unico);
			var_dump($array_finale);

			$DB->set_field("adaptive_goal",'rk',$array_finale, array('course'=>$course,'studentid'=>$idStudenti[$j]));
		}
	}

}

//testato
//Legge il goal relativo al corso dalla tabella acoure_goal_course: se presente è considerato come goal, se non presente si considera tutto il dominio
function get_goal($course){
	global $DB, $USER;
	$studentid = $USER->id;
	$stringa='';
	$goalRecord=$DB->get_record('adaptive_goal',array('course'=>$course,'studentid'=>$studentid));//si assume che l'id dello studente sia quello dello user 
																								  //perchè la funzione viene invocata solo in modalità studente
	//caso in cui il goal e' tutto il dominio:
	if(empty($goalRecord)){
		$KIs=$DB->get_records_select("teacherassistant_domain",'id_course='.$course.' AND section<>0');
		$arrayKI=array();
		foreach($KIs as $ki){
			$app=$ki->ak.'_'.$ki->aklevels;
			$arrayKI[$app]=$app;
		}
		foreach($arrayKI as $ki){
			if($stringa=='')
				$stringa.=$ki;
			else
				$stringa.=','.$ki;
		}
		//print_r($stringa);
		
	}
	else{//caso in cui il goal non e' tutto il dominio:
		$stringa=$goalRecord->goal;
	}
	return $stringa;
}
//fino a qui ok
//testato
//ritorna il primo record degetaklla tabella log relativo al test iniziale
function get_record_initial_test($course,$userid){
	global $CFG;
        global $DB;
	$prefix=$CFG->prefix;
	
	
	
	
	//$sql='select * from '.$prefix."log where course=$course AND userid=$userid AND time=(select max(time) from ".$prefix."log where course=$course AND userid=$userid)";
	//$record=get_record_sql($sql,true);
	//$where="course=$course AND userid=$userid AND time=(select max(time) from ".$prefix."log where course=$course AND userid=$userid)";
	$cm=getCmidTestIniziale($course);
	
	$where="course=$course AND userid=$userid AND module='quiz' AND action='close attempt' AND cmid=$cm";
	$record=$DB->get_record_select("log",$where);
	
		
	
	return $record;
}

function get_record_last_action($course,$userid){
	global $CFG, $DB;
	$prefix=$CFG->prefix;
	//$sql='select * from '.$prefix."log where course=$course AND userid=$userid AND time=(select max(time) from ".$prefix."log where course=$course AND userid=$userid)";
	//$record=get_record_sql($sql,true);
	$where="course=$course AND userid=$userid AND time=(select max(time) from ".$prefix."log where course=$course AND userid=$userid)";
	$record=$DB->get_record_select("log",$where);
	return $record;
}

function prova($user,$course){
	global $CFG;
	@mysql_close();
	mysql_connect($CFG->dbhost,$CFG->dbuser,$CFG->dbpass);
	mysql_select_db($CFG->dbname);
	//$record = get_record('adaptive_log_lsplan','userid',$user,'course',$course);
		$prefix=$CFG->prefix;
		$query='SELECT * FROM '.$prefix.'adaptive_log_lsplan WHERE userid='.$user.' AND course='.$course;
	//$record=mysql_query($query);
	

	$percorsoFile=$CFG->dirroot.'/course/format/adaptive/';
		$pf = $percorsoFile.'/logger.txt';
		$logger = fopen($pf,'a');
				fwrite($logger,$query);
				fwrite($logger,"\r\n inserisci nodo:   ");
		fwrite($logger,$user);
						fwrite($logger,"\r\n ");
		fwrite($logger, $course);
						fwrite($logger,"\r\n");
	$record=mysql_query($query);
	ob_start();
	var_dump($record);
	$data=ob_get_clean();
			fwrite($logger, $data);
						fwrite($logger,"\r\n");
	
	if (!$record) {
		$message  = 'Invalid query: ' . mysql_error() . "\n";
		$message .= 'Whole query: ' . $query;
   		fwrite($logger,$message);
	}
	
	if (mysql_num_rows($record) == 0) {
    fwrite($logger,"No rows found, nothing to print so am exiting");
	return 0;
    
}

	while ($row = mysql_fetch_assoc($record)) {
		fwrite($logger,$row['id']);
		fwrite($logger,$row['ln_type']);
	}
		
		fclose($logger);
		return $record;
} 





// ritorna un array contente le tre righe del file di output di lsplan, ossia la prima riga riporta l'intera sequenza dei LN non personalizzati sullo studente, la seconda riga è la sequenza personalizzata e la terza riga riporta un eventuale messaggio di output di lsplan a seguito della personalizzazione
function read_output_lsplan($course,$userid){
	$prefix="./format/adaptive/lsplan/corsi";
	$urlFile="$prefix/$course/los/$userid.txt";
	chmod($urlFile,0777);	
	$varTXT=fopen($urlFile, "r");
	$leggiTXT=fread($varTXT, filesize($urlFile));
	$arrayTXT=file($urlFile);
	$arrayTXT[0]=str_replace("id","",$arrayTXT[0]);
	$arrayTXT[1]=str_replace("id","",$arrayTXT[1]);
	fclose($varTXT);
	return $arrayTXT;
}
//effettua la chiamata intermedia a Lsplan, ossia tutte le chiamate a Lsplan a seguito della pianificazione iniziale
function call_lsplan($userid,$section,$courseid,$score,$fruitionTime){
	$prefix="./format/adaptive/lsplan";
	$dir=getcwd();
	chdir($prefix);
	require_once("./src/Lsplan.php");
   // $classpath="$prefix/classes:$prefix/classes/fiji.jar:$prefix/classes/mysql-connector-java-5.1.6-bin.jar";
    //per ora il cs rimane empty, poi dovra' essere gestito come ora e' gestito il goal
	$info='2^'.$userid.'^id'.$section.'^'.$score.'^'.$fruitionTime.'^'.$courseid;
	Lsplan::main($info);
	restore_connection_DB();
	chdir($dir);
	//echo $command;
	//exec($command);
	return $info;
}
//ritorna un array che ha come chiave l'ak e come valori un oggetto che contiene l'ak e la section dei KI del corso indicato da $course(id)
function getKiCourse($course){
	global $DB;
	$KIs=$DB->get_records_select("graph",'course='.$course.' AND section<>0');
	$arrayKI=array();
	foreach($KIs as $ki){
		//print_r($ki->ak);
		if(!isset($arrayKI[$ki->ak])){
			$app= new stdClass();
			$app->section=$ki->section;
			$app->ak=$ki->ak;
			$app->aklevels=$ki->aklevels;
			$arrayKI[$app->ak]=$app;
		}
		else if($arrayKI[$ki->ak]==''){
				$app= new stdClass();
				$app->section=$ki->section;
				$app->ak=$ki->ak;
				$app->aklevels=$ki->aklevels;
				$arrayKI[$app->ak]=$app;
		}
	}
	return $arrayKI;
}
//Effettua la correzione del test iniziale, ritornando l'insieme dei KI acquisiti(CS)
function correction_initial_test($idTestIniziale,$userId,$courseId){
	global $DB;
	$KIs = getKiCourse($courseId);
	
	$cs = "";
	//prendo dal db le domande che compongono il test iniziale

	//$questionsTest = $DB->get_field("quiz",'questions',array('id'=>$idTestIniziale));        //corretta sotto
	$questionsTest = $DB->get_records("pretest_slots",array('pretestid'=>$idTestIniziale));
	
	$idAttempt = $DB->get_field("pretest_attempts",'uniqueid',array('userid'=>$userId,'pretest'=>$idTestIniziale));
	
	$cont=0;
	$answers = $DB->get_records("question_attempts", array('questionusageid'=>$idAttempt));//tutte le risposte alle domande del test iniziale relative a $userId
	
	
	
	//NOTA:la stringa delle domande di un quiz termina con 0, che va eliminato dalla sequenza
//	$pos = strrpos($questionsTest,',');
	
//	$questionsTest = substr($questionsTest,0,$pos);
//	$qTestArray = explode(',',$questionsTest);                 //commentata, no stringa
	

	//Per ogni KI si controlla se è già acquisito(da aggiungere al CS) o no
	foreach($KIs as $ki){
		if (acquisitoKI($questionsTest,$userId,$ki,$courseId,$idTestIniziale,$answers)!="n"){
		print_object(acquisitoKI($questionsTest,$userId,$ki,$courseId,$idTestIniziale,$answers));
			$cs.=','.$ki->ak.'_'.acquisitoKI($questionsTest,$userId,$ki,$courseId,$idTestIniziale,$answers);
			}
	}
	
	$cs=substr($cs,1);
	print_object($cs);
	
	return $cs;
}
//controlla se lo studente ha ottenuto punteggio valido(tra tutte le domande associate al Ki
// e contenute nel test iniziale) per considerare il KI già posseduto
function acquisitoKI($qTestArray,$userId,$ki,$courseId,$idTestIniziale,$answers){
	$questions = getQuestions($ki, $qTestArray,$courseId);
	
	
	$scoreStudent = getScoreStudent($questions,$answers);
	$scoreMax = getScoreMax($questions);
	
	
	
	
	
	
	//NOTA: $soglia serve a stabilire la soglia minima per considerare un KI già posseduto e può assumere valori tra 0 e 1
	$soglia = get_soglia($courseId);

	// verisione a soglia
	if((($scoreMax * $soglia) <= $scoreStudent) && $scoreMax!=0)//scoreMax!=0 il ki non ha question nel corso
		return $ki->aklevels;
	return 'n';
	 
	/*if($scoreStudent==0)
		return "n";
	if($scoreStudent<$scoreMax*0.2){
		
		return "n";
		}
	else {
		if($scoreStudent<$scoreMax*0.4){
			
			return "K";
		}
		
	else {
		if($scoreStudent<$scoreMax*0.8)	{
			
			return "A";
		
		}
	else {
		
		return "E";
		}
		}
		}*/
}

//ritorna la soglia minima,compresa tra 0 e 1,per impostare il minimo
//punteggio da ottenere tra le domande del test iniziale relative a un KI per considerarlo già
//posseduto dallo studente prima di iniziare il corso(CS). Questa soglia è relativa al solo corso con id $courseid
function get_soglia($courseid){
	global $DB;
	$soglia=$DB->get_field('graph','threshold',array('course'=>$courseid));
	if(empty($soglia))
		return 0.7;
	return $soglia;
}
//ritorna un array di id della tabella question relativo alle domande inserite nel test iniziale e relative al KI $ki
function getQuestions($ki, $qTestArray,$courseId){//$qTestArray è un array di id della tabella question
	global $DB;
	$questions = array();
	$kiQuestions = $DB->get_records_select("adaptive_questions_ki","section=$ki->section and id_course=$courseId");
	foreach($kiQuestions as $q){
		if(in_array($q->id_question,$qTestArray)){
			$questions[] = $q->id_question;
		}
	}
	
	return $questions;
	
}


//Ritorna il punteggio ottenuto dallo studente relativamente alle domande di un KI contenute nel test iniziale
function getScoreStudent($questions,$answers){//$questions è un array con gli id delle domande relative a un KI
	//per ogni domanda di $questions dobbiamo prendere il campo grade e sommarlo a $gradeStudent, delle question che hanno il campo
	//event = 6 (lo stud ha risposto definitivamente)
	
	$gradeStudent=0;

	foreach($answers as $answer){
		if((in_array($answer->questionid,$questions))and ($answer->rightanswer==$answer->responsesummary))
			$gradeStudent += $answer->maxmark;
	}
	return $gradeStudent;
	//$questionGrade = get_field("question",'defaultgrade','id',$question->question);
	//$answer = $question->answer;
	
	
}
//testato
//Ritorna il punteggio massimo ottenibile da tutte le domande di un KI contenute nel test iniziale
function getScoreMax($questions){
	global $DB;
	
	$maxGrade=0;
	foreach($questions as $question){
		$q=$DB->get_field("question","defaultmark",array('id'=>$question));
		$maxGrade+=$q;
	}
	
	
	return $maxGrade;
}

//testato
//restituisce il record relativo all'ultima visualizzazione del corso
function get_last_course_view($courseid,$userid){
	global $CFG,$DB;
	$prefix=$CFG->prefix;
	$param = array($courseid,$userid,'course','view');
	$query="SELECT * FROM {log} WHERE time=(SELECT max(time) from {log} where course=? and userid=? and module=? and action=?)";
	$record=$DB->get_record_sql($query,$param,true);
	return $record;
}

//Ritorna il record della tabella mdl_log relativo all'ultima attivita' del corso visualizzata
function get_secondlast_course_view($courseid,$userid,$lastId){
	global $CFG,$DB;
	$prefix=$CFG->prefix;
	$param = array($courseid,$userid,'course','view',$lastId);
	$query="SELECT * FROM {log} WHERE time = (SELECT max(time) FROM {log} WHERE course=? AND userid=? AND module=? AND action=? AND id<?)";
	$record=$DB->get_record_sql($query,$param);
	return $record;
}
//Controlla se sono state aggiunte o eliminate delle domande all'interno di un quiz intermedio:
//se e' stato modificato un quiz ritorna il cmid del quiz, altrimenti 0
function is_edit_questions($courseid,$userid){
	global $DB;
	//prendo l'utlima visualizzazione del corso del docente $userid
	$appRecord=get_last_course_view($courseid,$userid);
	$lastId=$appRecord->id;
	//prendo la penultima visualizzazione del corso del docente $userid
	$appRecord=get_secondlast_course_view($courseid,$userid,$lastId);
	$secondLastId=$appRecord->id;
	$where="id>=$secondLastId AND id<=$lastId AND action='editquestions' AND userid=$userid AND course=$courseid";
	//prendo i record della tabella log compresi tra l'ultima e la penultima visualizzazione del corso
	$records=$DB->get_records_select("log",$where);
	$count=0;
	
	//controllo se tra questi record ce n'e' uno che indica la modifica della struttura di un quiz
	foreach($records as $record){
		//if($record->action='editquestions')
			$count++;
		if($count>1)
			return $record->cmid;
	}

	return 0;
}

function associaKIQuestions($section,$course,$cmidQuiz){
	global $CFG,$DB;
	$record=$DB->get_record("course_modules",array("id"=>$cmidQuiz));
	$idQuiz=$record->instance;
	if($idQuiz>=0){
		$questions=$DB->get_field("quiz","questions",array('id'=>$idQuiz));
		$questArray=explode(",",$questions);
		for($i=0;$i<count($questArray)-1;$i++)
			KIToQuestion($section,$questArray[$i],$course);
	}
	$info->section=$section;
	$info->course=$course;
	$scores=getScores($info);
	$maxScore=normalizzaPunteggio($scores->punteggio,$course,$scores->punteggio,$scores->voto);
	$minScore=getMinScore($scores->idQuiz);
	$minScore=normalizzaPunteggio($minScore,$course,$scores->punteggio,$scores->voto);
	$modId=get_module_id("teacherassistant");
	$idSection=$DB->get_field("course_sections",'id',array('course'=>$course,'section'=>$section));
	$cm=$DB->get_record("course_modules",array("course"=>$course,"section"=>$idSection,"module"=>$modId));
	//$sql="update lsplan.learningnodes set minimumPossibleScore=$minScore, maximumPossibleScore=$maxScore where corso=$course and id=id".$section;
	//echo $CFG->wwwroot.'/course/modedit.php?update='.$cm->id.'&type=&course='.$cm->course.'&section='.$cm->section.'&return=0&msg=1&minScore='.$minScore.'&maxScore='.$maxScore;
			print_r("<b>CARICAMENTO IN CORSO...</b>");
	$metadati=get_Metadati_LN('id'.$section,$course);
	$metadati=substr($metadati,0,strlen($metadati)-1);
	$appArray=explode(';',$metadati);
	$appArray[10]=$minScore;	
	$appArray[11]=$maxScore;
	//print_r('<br> '.$appArray[10].' '.$appArray[11]);
	$metadati='id'.$appArray[0];
	for($i=1;$i<count($appArray);$i++)
		$metadati.=";$appArray[$i]";
	$prefix="./format/adaptive/lsplan";
	$dir=getcwd();
	chdir($prefix);
	require_once("./src/Accesso.php");
    //$classpath="$prefix/classes:$prefix/classes/fiji.jar:$prefix/classes/mysql-connector-java-5.1.6-bin.jar";
    //per ora il cs rimane empty, poi dovra' essere gestito come ora e' gestito il goal
	
    //$classpath="$prefix/classes:$prefix/classes/fiji.jar:$prefix/classes/mysql-connector-java-5.1.6-bin.jar";
    $info = '2 '.$metadati;
    Accesso::main($info);
    restore_connection_DB();
	chdir($dir);
	//print_r($command." \n");
	//exec($command);
	redirect($CFG->wwwroot.'/course/modedit.php?update='.$cm->id.'&type=&course='.$cm->course.'&section='.$cm->section.'&return=0&modQuiz=1&minScore='.$minScore.'&maxScore='.$maxScore);

}

function get_Metadati_LN($idLN,$idCourse){
	$prefix="./format/adaptive/lsplan";
	$dir=getcwd();
	chdir($prefix);
	require_once("./src/Accesso.php");
    //$classpath="$prefix/classes:$prefix/classes/fiji.jar:$prefix/classes/mysql-connector-java-5.1.6-bin.jar";
    //per ora il cs rimane empty, poi dovra' essere gestito come ora e' gestito il goal
	
    //$classpath="$prefix/classes:$prefix/classes/fiji.jar:$prefix/classes/mysql-connector-java-5.1.6-bin.jar";
   
   // $classpath="$prefix/classes:$prefix/classes/fiji.jar:$prefix/classes/mysql-connector-java-5.1.6-bin.jar";
    $info = '4 '.$idLN.';'.$idCourse;
    Accesso::main($info);
     	restore_connection_DB();
	chdir($dir);
	//exec($command);
	$urlFile=$prefix.'/temp/'.$idLN.$idCourse.'.txt';
	$varTXT=fopen($urlFile, "r");
	$leggiTXT=fread($varTXT, filesize($urlFile));
	$arrayTXT=file($urlFile);
	$initTXT=str_replace("id", "", $arrayTXT[0]);
	fclose($varTXT);
	return $initTXT;
}
//lega ki e question nel db
function KIToQuestion($section,$idQuestion,$course){
	global $DB;
	$info->id_question=$idQuestion;
	$info->section=$section;
	$info->id_course=$course;
	if($DB->get_record("adaptive_questions_ki",array("id_course"=>$course,"section"=>$section,"id_question"=>$idQuestion))==0)
	//$sql="insert ignore into ".$CFG->prefix."adaptive_questions_ki set `id_question` = $idQuestion,`section` = $section,`id_course` = $course";
	 $DB->insert_record("adaptive_questions_ki",$info);
}	
//Ritorna l'id della tabella modules del modulo con nome $moduleName
function get_module_id($moduleName){
	global $DB;
	$id=$DB->get_field("modules","id",array("name"=>$moduleName));
	return $id;
}
//Ritorna il record della tabella course_sections della sezione $section del corso $courseid
function get_record_section($courseid,$section){
	global $DB;
	return $DB->get_record("course_sections",array("course"=>$courseid,"section"=>$section));
}

//Completa l'oggetto $cm per l'inserimento di una nuova istanza di un modulo in Moodle:
//inoltre, tramite la variabile $visible e' possibile stabile se tale istanza potra' essere visibile
//allo studente o no
function insert_in_cm($cm,$visible){
	global $DB;
	$cm->idnumber=NULL;
	$cm->added=time();
	$cm->score=0;
	$cm->indent=0;
	$cm->visible=$visible;
	$cm->visibleold=$visible;
	$cm->groupmode=0;
	$cm->groupingid=0;
	$cm->groupmembersonly=0;
	return $DB->insert_record("course_modules",$cm);
}
//Aggiunge nella sezione 0 la risorsa per il link al grafo del corso
function add_link_to_graph($courseid,$coursename){
	global $CFG,$DB;
	
	$checkWord = "Visualizza il grafo del corso";
	$checkWord2 = "Show the course learning path";
	$check = $DB->get_record("url",array("course"=>$courseid,"name"=>$checkWord));
	$check2 = $DB->get_record("url",array("course"=>$courseid,"name"=>$checkWord2));
	if(!$check and !$check2){
		
		//prendo l'id relativo al tipo di modulo
		$moduleId=get_module_id("url");
		
		$object->course=$courseid;
		$object->name='Show the course learning path';
		$object->intro='file';
		$object->introformat=1;
		//imposto il link alla pagina php che mi permette di visualizzare il grafo
		$object->externalurl=$CFG->wwwroot.'/course/format/adaptive/visualizza_grafo.php?courseid='.$courseid.'&coursename='.$coursename;
		
		$object->display='';
		$object->displayoptions='resizable=1,scrollbars=1,directories=1,location=1,menubar=1,toolbar=1,status=1,width=620,height=450';
		$object->parameters='';
		$object->timemodified=time();
		//Prendo l'id del record appena inserito relativo alla nuova istanza del modulo
		$idResource=$DB->insert_record("url",$object);
		//Prendo il record della sezione 0
		$sectionZero=get_record_section($courseid,0);
		$cm->course=$courseid;
		$cm->module=$moduleId;
		$cm->instance=$idResource;
		$cm->section=$sectionZero->id;
		//Inserisco la nuova istanza nella tabella course_modules in modo che sia visibile a Moodle
		$cmid=insert_in_cm($cm,0);
		$seq=$sectionZero->sequence;
		//Nella sequenza delle istanze dei vati moduli prenseti nella sezione 0, aggiungo la risorsa per il link al grafo
		if($seq=='' || $seq==' ')
			$seq=$cmid;
		else
			$seq.=','.$cmid;
		$sectionZero->sequence=$seq;
		$DB->update_record("course_sections",$sectionZero);
	}
}


function add_link_to_check($courseid,$coursename) {
	global $DB;
	
	$checkWord = "Effettua il controllo di consistenza della struttura del corso";
	$checkWord2 = "Consistency check for this course";
	$check = $DB->get_record("url",array("course"=>$courseid,"name"=>$checkWord));
	$check2 = $DB->get_record("url",array("course"=>$courseid,"name"=>$checkWord2));
	if(!$check and !$check2){
		global $CFG;
		//prendo l'id relativo al tipo di modulo
		$moduleId=get_module_id("url");
		
		$object->course=$courseid;
		$object->name='Consistency check for this course';
		$object->intro='file';
		$object->introformat=1;
		//imposto il link alla pagina php che mi permette di visualizzare il grafo
		$object->externalurl=$CFG->wwwroot.'/course/format/adaptive/check_consistenza.php?courseid='.$courseid.'&coursename='.$coursename;
		$object->display='';
		$object->displayoptions='resizable=1,scrollbars=1,directories=1,location=1,menubar=1,toolbar=1,status=1,width=620,height=450';
		$object->parameters='';
		$object->timemodified=time();
		
		
		
		
		//Prendo l'id del record appena inserito relativo alla nuova istanza del modulo
		$idResource=$DB->insert_record("url",$object);
		//Prendo il record della sezione 0
		$sectionZero=get_record_section($courseid,0);
		$cm->course=$courseid;
		$cm->module=$moduleId;
		$cm->instance=$idResource;
		$cm->section=$sectionZero->id;
		//Inserisco la nuova istanza nella tabella course_modules in modo che sia visibile a Moodle
		$cmid=insert_in_cm($cm,0);
		$seq=$sectionZero->sequence;
		//Nella sequenza delle istanze dei vati moduli prenseti nella sezione 0, aggiungo la risorsa per il link al check
		if($seq=='' || $seq==' ')
			$seq=$cmid;
		else
			$seq.=','.$cmid;
		$sectionZero->sequence=$seq;
		$DB->update_record("course_sections",$sectionZero);
	}

}

//Aggiunge nella sezione 0 un'istanza del modulo acourse, visibile solo al docente
function insert_acourse($courseid){
	global $DB;
	$checkWord = "Impostazioni generali"; 
	$check = $DB->get_record("resource",array("course"=>$courseid,"name"=>$checkWord));
	$checkWord2 = "General settings";
	$check2 = $DB->get_record("resource",array("course"=>$courseid,"name"=>$checkWord2));
	$object = new stdClass();
	$cm = new stdClass();
	if(!$check and !$check2){
		$moduleId=get_module_id("acourse");
		$object->course=$courseid;
		$object->name='General settings';
		$idacourse=$DB->insert_record("acourse",$object);
		$sectionZero=get_record_section($courseid,0);
		$cm->course=$courseid;
		$cm->module=$moduleId;
		$cm->instance=$idacourse;
		$cm->section=$sectionZero->id;
		$cmid=insert_in_cm($cm,0);
		$seq=$sectionZero->sequence;
		if($seq=='' || $seq==' ')
			$seq=$cmid;
		else
			$seq.=','.$cmid;
		$sectionZero->sequence=$seq;
		
		$DB->update_record("course_sections",$sectionZero);
	}
}

//Aggiunge nella sezione 0 un'istanza del modulo testls, visibile solo allo studente
function insert_testLS($courseid){
	global $DB;
	$checkWord = "Come mi piacerebbe imparare";
	$check = $DB->get_record("resource",array("course"=>$courseid,"name"=>$checkWord));
	$checkWord2 = "How I'd like to learn";
	$check2 = $DB->get_record("resource",array("course"=>$courseid,"name"=>$checkWord2));
	
	if(!$check and !$check2){
		$moduleId=get_module_id("testls");
		$object->course=$courseid;
		$object->name="How I'd like to learn";
		$idTestls=$DB->insert_record("testls",$object);
		$sectionZero=get_record_section($courseid,0);
		$cm->course=$courseid;
		$cm->module=$moduleId;
		$cm->instance=$idTestls;
		$cm->section=$sectionZero->id;
		$cmid=insert_in_cm($cm,1);
		$seq=$sectionZero->sequence;
		if($seq=='' || $seq==' ')
			$seq=$cmid;
		else
			$seq.=','.$cmid;
		$sectionZero->sequence=$seq;
		$sectionZero->summary=str_replace("'","''",$sectionZero->summary);//viene fatto perche' se ci sono apici nella query update MySql non va,con i doppi apici si
		
		
		$DB->update_record("course_sections",$sectionZero);
		
	}
}

//Aggiunge nella sezione 0 un'istanza del link al grafo individuale dello studente, visibile solo a lui
function insert_student_graph($courseid,$coursename,$studentid){
	global $CFG,$DB;
	$checkWord = "Visualizza il grafo del corso dello studente";
	$check = $DB->get_record("url",array("course"=>$courseid,"name"=>$checkWord));
	$checkWord2 = "Show your learning path for this course";
	$check2 = $DB->get_record("url",array("course"=>$courseid,"name"=>$checkWord2));
	if(!$check and !$check2){
		//prendo l'id relativo al tipo di modulo
		$moduleId=get_module_id("url");
		
		$object->course=$courseid;
		$object->name='Show the course learning path';
		$object->intro='file';
		$object->introformat=1;
		//imposto il link alla pagina php che mi permette di visualizzare il grafo
		$object->externalurl=$CFG->wwwroot.'/course/format/adaptive/visualizza_grafo_studente.php?courseid='.$courseid.'&coursename='.$coursename.'&userid='.$studentid;

		
		$object->display='';
		$object->displayoptions='resizable=1,scrollbars=1,directories=1,location=1,menubar=1,toolbar=1,status=1,width=620,height=450';
		$object->parameters='';
		$object->timemodified=time();
		
		
		//Prendo l'id del record appena inserito relativo alla nuova istanza del modulo
		$idResource=$DB->insert_record("url",$object);
		//Prendo il record della sezione 0
		$sectionZero=get_record_section($courseid,0);
		$cm->course=$courseid;
		$cm->module=$moduleId;
		$cm->instance=$idResource;
		$cm->section=$sectionZero->id;
		//Inserisco la nuova istanza nella tabella course_modules in modo che sia visibile a Moodle
		$cmid=insert_in_cm($cm,1);
		$seq=$sectionZero->sequence;
		//Nella sequenza delle istanze dei vati moduli prenseti nella sezione 0, aggiungo la risorsa per il link al grafo
		if($seq=='' || $seq==' ')
			$seq=$cmid;
		else
			$seq.=','.$cmid;
		$sectionZero->sequence=$seq;
		//$sectionZero->summary=str_replace("'","''",$sectionZero->summary);//viene fatto perche' se ci sono apici nella query update MySql non va,con i doppi apici si
		$DB->update_record("course_sections",$sectionZero);
	}
}


//ritorna il punteggio minimo ottenibile dalle domande contenute nel quiz con id $idquiz
function getMinScore($idQuiz){
	global $DB;
	$min=0;
	$quiz=$DB->get_record("quiz",array("id"=>$idQuiz));
	$questions=explode(",",$quiz->questions);//ATTENZIONE: questa sequenza ha come ultimo elemento lo 0, imposto dalla struttara di questions di quiz
	for($i=0;$i<count($questions)-1;$i++){
		$question=$DB->get_record("question",array("id"=>$questions[$i]));
		$questionGrade=$question->defaultgrade;
		$minFraction=get_min_fraction($question);
		$min+=$minFraction*$questionGrade;
	}
	return $min;
}

//ritorna il valore più penalizzante della domanda(fraction più basso)
function get_min_fraction($question){
	global $DB;
	$min=1;//il massimo valore che può assumere fraction e' 1(il minimo e' -1)
	$answers=$DB->get_records_select("question_answers","question=$question->id");
	foreach($answers as $ans){
		if($ans->fraction<$min)
			$min=$ans->fraction;		
	}
	return $min;
}
//Ritorna il punteggio massimo e il voto massimo all'interno di un oggetto, -1 se nella sezione non c'e' quiz
function getScores($form){
	global $DB;
	$idQuiz=hasQuiz($form->section,$form->course);
	if($idQuiz>=0){ //Vuol dire che nella sezione in cui si sta inserendo il TeacherAssistant ci sono gia' due elementi quindi c'è il quiz
		$app=$DB->get_record("quiz",array('id'=>$idQuiz));
		$punteggiQuiz->idQuiz=$idQuiz;
		$punteggiQuiz->voto=$app->grade;
		$punteggiQuiz->punteggio=$app->sumgrades;
		return $punteggiQuiz;
	}
	return -1;
}
//Controlla se nella sezione $section del corso $course e' presente un quiz:
//In caso positivo ritorna l'id della tabella mdl_course_modules del quiz
//altrimenti -1
function hasQuiz($section,$course){
	global $DB;
	$seq=get_sequence($section,$course);
	$numElements=count($seq);
	//Nella sezione in cui si sta inserendo il TeacherAssistant ci devono essere gia' almeno due elementi se e' presente il quiz(risorsa+quiz)
	if($numElements>=2){
		//Dato che ci possono essere piu' risorse dobbiamo scorrere e controllare qual'e', se presente, il quiz
		for($i=0;$i<$numElements;$i++){
			//prendo il course module relativo al modulo i-esimo
			$cm=$DB->get_record("course_modules",array('id'=>$seq[$i]));
			//prendo il nome del modulo i-esimo
			$moduleName=$DB->get_field("modules","name",array("id"=>$cm->module));
			if($moduleName=='quiz')
				return $cm->instance;
		}
	}	
	return -1;
}
/*Questa funzione serve per normalizzare il punteggio che gli viene passato come parametro:
 * Se la scala è il voto, allora lo score viene normalizzato
 * altrimenti e' gia' nella giusta scala*/
function normalizzaPunteggio($score,$course,$maxScore,$votoMax){
	//capire dove va messo tale valore, dovrebbe essere a livello di corso e non di LN per nn incasinare tutto!
	//$scala=get_field("teacherassistant","typeScore","section",$section,"course",$course);
	/*$scala=$maxScore;
	if($scala==$votoMax)
		return ($votoMax*$score)/$maxScore;
	else
		return $score;*/
		$scala=get_scala($course);
	if($scala=='punteggio')
		return $score;
	else
		return ($votoMax*$score)/$maxScore;
}

//ritorna la scala di normalizzazione impostata dal docente per il corso con id $course
function get_scala($course){
	global $DB;
	$scala=$DB->get_record('acourse_quiz_course',array('courseid'=>$course));
	if(empty($scala)){
		return 'punteggio';
	}
	return $scala->scale;
}

//Restituisce il punteggio(normalizzato) ottenuto dallo studente nell'ultimo tentativo del quiz $idQuiz
function get_sumgrades_last_attempt($userid,$idQuiz,$courseid){
	global $DB;
	$records=$DB->get_records_select('quiz_attempts',"quiz=$idQuiz and userid=$userid");
	$attempt=0;
	$sumgrades=0;
	foreach($records as $r)
		if($r->attempt > $attempt){
			$attempt=$r->attempt;
			$sumgrades=$r->sumgrades;
		}
	$recordQuiz=$DB->get_record("quiz",array("id"=>$idQuiz));
	//print_r("quiz in sumgrades: $recordQuiz->id");
	$sumgrades=normalizzaPunteggio($sumgrades,$courseid,$recordQuiz->sumgrades,$recordQuiz->grade);
	return $sumgrades;
}
//introdotta nella versione del plugin con lsplan in php, per ripristinare la connessione al DB di Moodle, a seguito delle operazioni eseguite sul DB di lsplan
function restore_connection_DB(){
	global $CFG;
	mysql_close();
	mysql_connect($CFG->dbhost,$CFG->dbuser,$CFG->dbpass);
	mysql_select_db($CFG->dbname);
}

//Verifica se è stato modificato il materiale didattico di una sezione del corso, eventualmente aggiorna la tabella teacherassistent_attivita.
//Ritorna il cmid in caso di modifica altrimenti -1
function is_modified_section($courseid){
	global $CFG,$DB;
	$prefix=$CFG->prefix;
	$cond = array($courseid,'add');
	$query="SELECT * FROM {log} WHERE id=(SELECT max(id) from {log} where course=? and action=?)";
	$record=$DB->get_record_sql($query,$cond);
	$cmid=$record->cmid;
	
	$record=$DB->get_record("teacherassistent_attivita",array("id_cm"=>$cmid,"id_course"=>$courseid));
	if(empty($record) && isLN($cmid)!=-1){
		add_activity_course($cmid);
	}else
		$cmid=-1;
	return $cmid;
}
//Aggiunge al corso personalizzato(tabella teacherassistent_attivita) l'ultima attività aggiunta nella sezione,
//in modo che venga considerata durante la personalizzazione per il calcolo del tempo di fruizione.
//Questo avviene registrando il suo cmid($cmid) come materiale didattico del corso personalizzato
function add_activity_course($cmid){
	global $DB;
	$cm=$DB->get_record("course_modules",array("id"=>$cmid));
	$sectionid=$cm->section;
	$sectionRecord=$DB->get_record("course_sections",array("id"=>$sectionid));
	$section=$sectionRecord->section;
	$courseid=$sectionRecord->course;
	$sequence=$sectionRecord->sequence;
	if(check_ta($sequence)){
		$object->section=$section;
		$object->type_activity='ln';
		$object->id_cm=$cmid;
		$object->id_course=$courseid;
		$DB->insert_record("teacherassistent_attivita",$object);
	}
}
//Controlla se è presente un istanza di treacherassistant nella sequenza di attività di una sezione($sequence)
function check_ta($sequence){
	global $DB;
	$arraySeq=explode(",",$sequence);
	$i=0;
	$ta=$DB->get_field("modules","id",array("name"=>"teacherassistant"));
	while($i<count($arraySeq)){
		$app=$arraySeq[$i];
		$cm=$DB->get_record("course_modules",array("id"=>$app));
		if($ta==$cm->module)
			return true;
		$i++;
	}
	return false;
}
function creaGrafoPerStudente($sequence,$userid,$corsoid,$nomeCorso){
	global $CFG;
	require_once($CFG->dirroot."/course/format/adaptive/grafo.php");
	$los=array();
	foreach($sequence as $id)
		$los[]=getAkFromId($id,$corsoid);
	creaGrafoStudente($userid,$corsoid,$nomeCorso,$los);
}

function aggiornaGrafoPerStudente($sequence,$userid,$corsoid){
	global $CFG;
	require_once($CFG->dirroot."/course/format/adaptive/grafo.php");
	if($sequence[0]!='-'){
		$los=array();
		foreach($sequence as $id)
			$los[]=getAkFromId($id,$corsoid);
	}
	else
		$los='fine';
	aggiornaGrafoStudente($userid,$corsoid,$los);

}
function getAkFromId($id,$corsoid){
	global $DB;
	
	return $DB->get_field('teacherassistant_domain','ak',array('section'=>$id,'id_course'=>$corsoid));
}

function risorseNodo($corsoId,$nodoNome){
	global $CFG,$DB;
	//$section = get_field('teacherassistant','section','course',$corsoId,'name',$nodoNome);
	//$where ="name=$nodoNome AND course=$corsoId";
	//print_r($where);
	//$section = get_fieldset_select('teacherassistant',$where);
	$param =array($corsoId,$nodoNome);
	$sql = "SELECT section FROM {teacherassistant} WHERE course=? AND name=?";
	$section = array_keys($DB->get_records_sql($sql,$param,0,0));
	
	$utili = array();
	$instance = array();
	foreach($section as $res){
		$sequence = get_sequence($res,$corsoId);
		
		foreach($sequence as $resId){
			
			if($DB->get_field('course_modules','module',array('id'=>$resId))==18){
				$utili[] = $resId;
				$instance[] = $DB->get_field('course_modules','instance',array('id'=>$resId));
			}
		}
	}


	$link = array();
	foreach($utili as $resId)
		$link[] = $CFG->wwwroot.'/mod/resource/view.php?id='.$resId;
	
	
	$nomi = array();
	foreach($instance as $resId)
		$nomi[] = $DB->get_field('resource','name',array('id'=>$resId));
	
	$result = array();
	$result[] = $link;
	$result[] = $nomi;
	
	return $result;
}

//recupera il voto minimo per considerare un LN come appreso
function getThreshold($idLn, $corso) {

	global $CFG;
	/*
	$prefix=$CFG->dirroot.'/course/format/adaptive/lsplan/format/adaptive/lsplan';
	$dir=getcwd();
	chdir($prefix);*/
	require_once($CFG->dirroot.'/course/format/adaptive/lsplan/src/GestoreDB.php');
	$threshold = GestoreDB::getSoglia($idLn, $corso);
	restore_connection_DB();
	//chdir($dir);
	
	return $threshold;
}

?>
