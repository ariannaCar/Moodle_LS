<?php

/**
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package KBS
 * @version 1.0
 * 
 **/



	require_once("InitParser.php");
	require_once("GrafoKBS.php");
	require_once("KBS.php");


/**
 * E' l'oggetto incaricato di eseguire l'algoritmo KBS 
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package KBS
 * @version 1.0
 * 
 * 
 **/


class EsecutoreKbs {
   /**
    * @var array
    **/
 
	private $los; //List<Nodo>
    
/**
 * Avvia l'algoritmo KBS a partire dal modello studente e AlberoXml
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param StudentModel $sm Il modello studente
 * @param AlberoXml $alb La sorgente dati AlberoXml
 * 
**/
    public function __construct($sm,$alb) {
		$this->los=array();
        $initPars=new InitParser($alb);
        $grafoKBS = new GrafoKBS($initPars);
        $kbs=new KBS($sm, $grafoKBS,$initPars);

		

        $this->los=$kbs->getLos();
        
		
    }
    
    
/**
 * Ritorna il Learning Object Sequence di output dell'algoritmo
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * 
 * @return array Il Learning Object Sequence di output dell'algoritmo
**/
    public function getLos(){//List<Nodo> 
        return $this->los;
    }

}
?>
