<?php

/**
 * Viene implementato un grafo mediante una mappa, dove la chiave e' il nodo e il valore e' la sua lista di nodi adiacenti. I nodi visitati sono memorizzati insieme dei nodi visitati (serve per la DFS), inizialmente vuoto
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package KBS
 * @version 1.0
 * 
 * 
 **/

class GrafoKBS {
	/**
	 * @var array
	 **/
	private $gs; //Map<String, Set<String>>  mappa dei successori del grafo: CHIAVE:nodo | VALORE:lista_adiacenza
	/**
	 * @var array
	 **/
	private $gp; //Map<String, Set<String>> mappa dei predecessori del grafo
    /**
	 * @var array
	 **/
    private $ids; //Map<String,String>
    /**
	 * @var string
	 **/
    private $nodostart; //String il nodo di partenza
    
    private $sorgenti;
	
/**
 * crea il GrafoKBS
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param InitParser $p Il parser per prelevare le informazioni per la costruzione del grafo
 * 
 * 
**/
	
	/* Costruttore di Grafo */
	public function __construct($p){//p � InitParser
		$this->ids = array();
        $this->gs = $p->getRKtoAK(); // preleva le mappe del grafo dal Parser
		$this->gp = $p->getAKtoRK();
        $this->ids = $p->getAKtoID();
        $keys = array_keys($this->gp); //le chiavi della mappa AKtoRK
        foreach ($keys as $s) { //s � stringa
            //if (this.gp.get(s).isEmpty())
			if(count($this->gp[$s])==0){
        		$this->nodostart = $s;
        	}
        }
        $this->sorgenti=$p->getSorgenti();
	}

/**
 * Ritorna la mappa dei successori del grafo, serve per la DFS in KBS
 * @author Matteo Lombardi <maluit@alice.it>
 * @version 1.0
 * 
 * 
 * @return array La mappa dei successori del grafo
**/

	
	// Ritorna l'HashMap del grafo (serve per la dfs in kbs)
	public function getHashMap() {//Map<String, Set<String>>
		return $this->gs;
	}
/**
 * Ritorna l'id del nodo con ak pari a $ak
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $ak L'AK del nodo di cui si vuole l'id
 * 
 * @return string L'id del nodo
**/

    public function corrispondenzaID($ak) {//String
        return $this->ids[$ak];
    }
/**
 * Ritorna il nodo da cui iniziare la visita del grafo
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * 
 * @return string L'ak del nodo da cui iniziare la visita del grafo
**/
    // Ritorna il nodo di partenza per la dfs
    public function getNodoStart() {//String
        return $this->nodostart;
    }
    
    public function getSorgenti(){
		return $this->sorgenti;
	}
}
?>
