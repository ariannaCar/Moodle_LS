<?php

//	require_once("../../LSPLAN/AlberoXml.php");

/**
 * E' il parser dedicato all'algoritmo KBS
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package KBS
 *
 * @version 1.0
 *
 * 
 **/

class InitParser {
/**	
 *  @var AlberoXml
 **/
    private $alb; // La sorgente dati AlberoXml
  
/**
 * Crea l'InitParser a partire dalla sorgente dati
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param AlberoXml $alb La sorgente dati AlberoXml
 * 
**/
    public function __construct($alb) {
		//$this->visitati=array();
        $this->alb=$alb;
      
    }
/**
 * Ritorna la mappa dei predecessori del grafo, ossia gli RK di un nodo
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @return array I predecessori del grafo, ossia gli RK del nodo
 * 
 **/
    public function getAKtoRK() {//Map<String,Set<String>> 
		$a=$this->alb;
        return $a->getAKtoRK();
    }

/**
 * Ritorna la mappa dei successori del grafo
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * 
 * @return array La mappa dei successori del grafo
**/

    public function getRKtoAK() {//Map<String,Set<String>>
        return $this->alb->getRKtoAK();
    }
/**
 * 
 * Ritorna la mappa dei successori del grafo
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @return array La mappa dei successori del grafo
**/
    public function getAKtoCorso() {//Map<String,String>
        return $this->alb->getAKtoCorso();
    }
/**
 * Ritorna la mappa degli id dei nodi con chiave AK
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @return array La mappa degli id dei nodi con chiave AK
**/
    public function getAKtoID() {//Map<String,String>
        return $this->alb->getAKtoID();
    }
/**
 * Ritorna la lista di AK dei nodi del grafo
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @return array La lista di AK dei nodi del grafo
**/
   
 public function getListaNodi(){ //ritorna String[]
        return $this->alb->getListaNodi();
 }
 /**
 * Ritorna un LearningNode, dato l'AK
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 * @version 1.0
 * @param string $Ak L'AK del LearningNode da cercare
 * 
 * @return LearningNode Il LearningNode con AK pari a quello richiesto
**/
public function searchNodeForAK($Ak){//ritorna LearningNode
  return $this->alb->searchNodeForAK($Ak);
}
 public function getSorgenti(){
		return $this->alb->getSorgenti();
	}
		
	

}



?>
