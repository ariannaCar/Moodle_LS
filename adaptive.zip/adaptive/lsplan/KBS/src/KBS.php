<?php

/**
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package KBS
 * @version 1.0
 *
 **/
/*
	require_once("../../LSPLAN/StudentModel.php");
	require_once("GrafoKBS.php");
	require_once("InitParser.php");
	require_once("../../LSPLAN/GestoreDB.php");
*/
/**
 * E' l'istanza dell'algoritmo KBS
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package KBS
 * @version 1.0
 *
 **/


class KBS {

    /**
	 * @var StudentModel
	 **/
    private $sm;//StudentModel 
	/**
	 * @var array
	 **/
	private $cs;  //Cognitive State
	/**
	 * @var GrafoKBS
	 **/
	private $grafo;//GrafoKBS
	/**
	 * @var array
	 **/
	private $visitati; // 0 = false 1 = true   //HashMap<String,Boolean>
	/**
	 * @var array
	 **/
	private $ordinamentoTopologicoNodi;  //E' uno stack:lo trattiamo come semplice lista poi INVERTIRE!!
    /**
	 * @var InitParser
	 **/
    private $initPars;//InitParser
        /**
	 * @var array
	 **/
    private $goal;//array(string)
    


/**
 * Crea l'istanza dell'algoritmo KBS e chiama il metodo start_kbs 
 * 
 * NOTA: il cognitive state viene preso dall'oggetto StudentModel
 *  
 * @author Matteo Lombardi <maluit@alice.it>

 * @version 1.0
 * @param StudentModel $sm Lo student model
 * @param GrafoKBS $graph Il grafo del corso
 * @param InitParser $initPars L'oggetto InitParser
 * 
**/

	/* Costruttore con i CS */
	public function __construct($sm,$graph,$initPars) {
            $this->visitati =array();
            $this->cs = array();
            $appCS = $sm->getCognitiveState();
            $csa=array();
            foreach($appCS as $a)
				$csa[]=$a->getId();
			$this->cs=$csa;
            $this->sm = $sm;
            $this->goal = array();
            $appG = $sm->getGoal();
            $ga=array();
            foreach($appG as $a)
				$ga[]=$a->getId();
			$this->goal=$ga;
            $this->grafo = $graph;
            $this->initPars=$initPars;
            $this->start_kbs();
	}

	/* Setta la stringa dei CS */
	public function setCS($cs) {
		$this->cs = $cs;
	}

        public function setGrafo($grafo) {
            $this->grafo = $grafo;
        }

	/* Ritorna la stringa dei CS */
	public function getCS() {//List<String
		return $this->cs;
	}
	
/**
 * La funzione stampaSequenzaOrdinamentoTopologico
 * 
 * Stampa la sequenza dei learning node ordinata topologicamente
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @deprecated
 * 
 * @return array la sequenza dei learning node ordinata topologicamente
**/

	// Richiama la stampa della Learning Sequence dell'ordinamento topologico
	public function stampaSequenzaOrdinamentoTopologico() {//ritorna List
		$lista = array();//List<String>
        for($i = count($this->ordinamentoTopologicoNodi)-1; $i >=0; $i-- ){
			$nodo = $this->ordinamentoTopologicoNodi[$i]->getId()." : ".$this->ordinamentoTopologicoNodi[$i]->getAK();//Nodo è una stringa
			$lista[$i]=nodo;
		}
                return $lista;
	}

/**
 * Effettua la visita topologica, ricorsiva a partire dal nodo x, del grafo e aggiunge i nodi al learning object sequence
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $x l'acquired knowledge del nodo
 * 
 * @return bool TRUE se il nodo è stato aggiunto al learning object sequence 
**/

	// DFS ricorsiva a partire dal nodo x
	public function dfs($x) {//ritorna boolean, x è una stringa
		$trovato=false;//boolean
		$this->dfs_visita($x);
		// ottieni i successori di x
		$lista =array();//Set di stringhe , quindi mappa in php
		$listaHashMap = $this->grafo->getHashMap();
		
		$lista = $listaHashMap[$x];
		if(in_array($x,$this->goal)==TRUE){
			//this.listaTk.remove(x);
			$trovato=true;
		}
			if (!empty($lista)){
						foreach($lista as $nodo) {//$nodo è una stringa
							// se il nodo non e' stato visitato
							if($this->visitati[$nodo] == false)
								$trovato=$this->dfs($nodo)||$trovato;
							else
								$trovato=$trovato || $this->visitati[$nodo];
						}
			}
		
		if($trovato!=false && in_array($x,$this->cs) == FALSE){
				$n=$this->initPars->searchNodeForAK($x);//$n è di tipo LearningNode (di Lsplan)
				
				$this->ordinamentoTopologicoNodi[]=$n;
		}
		$this->visitati[$x]=$trovato;
		return $trovato;
   }

/**
 * La funzione dfs_visita
 * 
 * Effettua la visita del nodo x
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $x l'acquired knowledge del nodo
 * 
 * 
**/
	// Visita del nodo x
	public function dfs_visita($x) {//ritorna void, $x è una stringa
		/**
         * @var bool
		**/
            $trovatoCS;//boolean,  trovatoCS - TRUE il nodo corrente è nel cognitive state, FALSE altrimenti
		// se il nodo non e' presente nei CS inseriscilo nella LearningSequence
            if (in_array($x, $this->cs) == false) {
				$trovatoCS = false;
            }
            else {
                $trovatoCS = true;
            }
	}

/**
 * La funzione getLos
 * 
 * Ritorna la sequenza che verrà proposta allo studente
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * @return array la sequenza che verrà proposta allo studente
**/
	  
    public function getLos(){
		$j = 0;
		$los = array();
		for($i = count($this->ordinamentoTopologicoNodi)-1; $i >= 0; $i--){
			$los[$j] = $this->ordinamentoTopologicoNodi[$i];
			$j++;
		}
		
		return $los;
		
		
	}

/**
 * Fa partire l'algoritmo KBS chiamando dfs, passandogli la radice del grafo.
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * 
 **/
    
	public function start_kbs() {//ritorna void
	    $this->ordinamentoTopologicoNodi= array();//Era Stack<LearningNode>
	    $sorgenti=$this->grafo->getSorgenti();
	   // print_r($sorgenti);
	    foreach($sorgenti as $s){
			$aks=$s->getAcquiredKnowledge();
			if(!array_key_exists($aks[0],$this->visitati))
				$this->dfs($aks[0]);
		}
	}

}
?>
