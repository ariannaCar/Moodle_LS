<?php
/**
 * E' l'istanza dell'algoritmo IWT
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package IWT
 * @version 1.0
 *
 **/

class IWT {
	/**
	 * @var array
	 **/
      private $presentation; //List<Nodo> 
	/**
	 * @var IwtParser
	 **/
      private $parser; //IwtParser 
	/**
	 * @var array
	 **/      
      private $target;//List<Nodo> 
	/**
	 * @var array
	 **/      
      private $cs; //List<Nodo> 
      
/**
 * Crea l'istanza dell'algoritmo IWT e chiama il metodo start 
 * 
 * NOTA: il cognitive state viene preso dall'oggetto StudentModel
 *  
 * @author Matteo Lombardi <maluit@alice.it>

 * @version 1.0
 * @param IwtParser $parser Il parser
 * @param array $target Il target dello studente
 * @param array $cs Il Cognitive State dello studente
 * 
**/ 
      
      public function __construct ($parser,$target,$cs){
      
          $this->parser=$parser;
          $this->presentation= array();
          $this->target = $target;
         /* echo '-------<br>';
         foreach($target as $t){
			$ak=$t->getAcquiredKnowledge();
			print_r($ak[0].'<br>');
		}
		print_r('<br>----------------<br><br>');*/
          $this->cs=$cs;
          $this->start();

      }
  
/**
 * Fa partire l'algoritmo IWT chiamando visitaPerR, passandogli i nodi del target e il Cognitive State.
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * 
 **/ 
      
      private function start(){
          foreach($this->target as $n){
            $this->visitaPerR($n,$this->cs);
           }
      }
      
/**
 * Effettua la visita ricorsiva del grafo, a partire dal nodo n, appoggiandosi alla funzione checkR per l'esplorazione ed aggiungendo i nodi alla Presentation
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param LearningNode $n il nodo da visitare
 * @param array $cs il Cognitive State dello studente
 * 
**/      
      
      private function visitaPerR($n,$cs){ //$n è un LearningNode
			$tempCheck = $n->check;
            if(!($tempCheck=="black")){
                $n->check="gray";
                $this->checkR($n,$cs);
				if(empty($cs)){
					$this->presentation[] = $n;
				}
				else{
					$aks=$n->getAcquiredKnowledge();
					if (in_array($aks[0], $cs)==false){
						$this->presentation[] = $n;
					}
				}
                $n->setCheck("black");
            }
        }

/**
 * Effettua un controllo di consistenza del grafo e richiama il metodo visitaPerR degli RK del nodo n
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param LearningNode $n il nodo da controllare
 * @param array $cs il Cognitive State dello studente
 * 
**/ 

    private function checkR($n, $cs){ //$n è LearningNode

        $required = $n->getRequiredKnowledge();
        $app = $required;
        if (!empty($required)){
            foreach($app as $ndAK){
				$nd=$this->parser->searchNodeForAK($ndAK);
				if($nd!=''){
					if($nd->getCheck()=="gray")
						print_r("Inconsistenza tra $n->getId() e $nd->getId()");
					else
						if (!($nd->getCheck()=="black"))
							$this->visitaPerR($nd,$cs);
				}
            }
        }
    }


    public function getPresentation(){//List<Nodo>
        return $this->presentation;
    }

}
?>
