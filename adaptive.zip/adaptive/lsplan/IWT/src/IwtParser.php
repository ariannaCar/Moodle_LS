<?php

//	require_once("../../LSPLAN/src/AlberoXml.php");
//	require_once("../../LSPLAN/src/StudentModel.php");



/**
 * E' il parser dedicato all'algoritmo IWT
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package IWT
 *
 * @version 1.0
 *
 * 
 **/

class IwtParser {

/**	
 *  @var AlberoXml
 **/
    private $alb; //AlberoXml 
    
/**	
 *  @var StudentModel
 **/    
    private $sm; //StudentModel 

/**
 * Crea l'IwtParser a partire dalla sorgente dati e il modello studente
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param AlberoXml $alb La sorgente dati AlberoXml
 * @param StudentModel $sm Il modello studente
**/

    public function __construct ($alb, $sm) {
        $this->alb = $alb;
        $this->sm = $sm;
    }
    
    public function getTarget(){ //List<Nodo>
        $appTarget = $this->sm->getGoal();
        $target=array();
        foreach($appTarget as $t){
			$nodo=$this->searchNodeForAK($t->getId());
			$target[]=$nodo;
		}
        return $target;
    }
    public function getCS(){//List<String>
        $appcs=$this->sm->getCognitiveState();
        $cs=array();
        foreach($appcs as $a){
			$nodo=$a->getId();
			$cs[]=$nodo;
		}
        return $cs;
    }
    
/**
 * Ritorna un LearningNode, dato l'AK
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 * @version 1.0
 * @param string $ak L'AK del LearningNode da cercare
 * 
 * @return LearningNode Il LearningNode con AK pari a quello richiesto
**/
    
    public function searchNodeForAK($ak){//LearningNode, ak è string
        return $this->alb->searchNodeForAK($ak);
    }
    
    
       public function searchNodeForId($ak){//LearningNode, ak è string
        return $this->alb->searchNodeForId($ak);
    }
    
    
/**
 * Ritorna tutti i nodi sorgente del grafo
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0 
 * 
 * @return array i nodi sorgente del grafo
 * 
**/    
    
    public function getSorgenti(){ //List<Nodo>
        return $this->alb->getSorgenti();
    }
    
/**
 * Ritorna tutti i nodi del grafo
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0 
 * 
 * @return array i nodi del grafo
 * 
**/    
    public function getNodi(){//List<Nodo> 
            return $this->alb->getNodi();
    }
    
}


?>
