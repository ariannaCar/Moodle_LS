<?php

//	require_once("../../LSPLAN/src/AlberoXml.php");
//	require_once("../../LSPLAN/src/StudentModel.php");
require_once("IwtParser.php");
require_once("IWT.php");

/**
 * E' l'oggetto incaricato di eseguire l'algoritmo IWT 
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package IWT
 * @version 1.0
 *
 **/

class EsecutoreIwt {

	/**
	 * @var array
	 **/
    private $presentation; //List<Nodo>
  
  /**
 * Avvia l'algoritmo IWT a partire dal modello studente e AlberoXml
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param StudentModel $sm Il modello studente
 * @param AlberoXml $alb La sorgente dati AlberoXml
 * 
**/
  
    public function __construct($sm,$alb) {
        
            $parser = new IwtParser($alb, $sm);
            //$nodi = $parser->getNodi();
            $this->presentation = $this->lanciaAlg($parser,$sm);
            
    }
    
/**
 * Ritorna il Learning Object Sequence di output dell'algoritmo
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * 
 * @return array Il Learning Object Sequence di output dell'algoritmo
**/
    
    public function getLos(){//List<Nodo>
        $los=array();
        foreach($this->presentation as $p)
			$los[] = $p;
        return $los;
    }
    
/**
 * Prepara l'input e lancia l'algoritmo
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * 
 * @return array la Presentation finale dell'algoritmo
**/   
    
    private function lanciaAlg($parser,$sm){ //List<Nodo>
        $t=$parser->getTarget();
        $cs=$parser->getCS();
        $iwt=new IWT($parser,$t,$cs);
        return $iwt->getPresentation();
    }

}



?>
