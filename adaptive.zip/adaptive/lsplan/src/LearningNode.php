<?php
/**
 * Descrive un metadato
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 * 
 **/

class LearningNode {
/**
	* @var array
	**/
  public $ak; // elenco ki di tipo Vector
  /**
	 * @var array
	 **/
  public $rk; //vector
  /**
	 * @var string
	 **/
  public $id; // String
  /**
	 * @var array
	 **/
  public $learningStyles;//array di double
  /**
	 * @var double
	 **/
  public $minimumScore;//double
  /**
	 * @var double
	 **/
  public $minimumPossibleScore;//double
  /**
	 * @var double
	 **/
  public $maximumPossibleScore;//double
  /**
	 * @var long
	 **/
  public $fruitionTime;//long	
  /**
	 * @var long
	 **/
  public $minimumTime;//long
  /**
	 * @var long
	 **/
  public $maximumTime;//long
  /**
	 * @var bool
	 **/
  public $existsPosttest;//boolean
  /**
	 * @var bool
	 **/
  public $read;//boolean
  /**
	 * @var string
	 **/
  public $recommended;//String
  /**
	 * @var double
	 **/
  public $obtainedScore;//double
  /**
	 * @var string
	 **/
  public $approach;//String
  /**
	 * @var string
	 **/
  public $corso;//String
  /**
	 * @var bool
	 **/
  public $alternativo;//boolean
  /**
	 * @var string
	 **/
  public $colour;
  /**
	 * @var string
	 **/
  public $RkColour;
  /**
	 * @var string
	 **/
  public $check;
/**
 * Crea un learning node vuoto 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * 
**/
  public function __construct(){
	  $this->learningStyles = array();
  	$this->read = false;
  	$this->recommended = "false";
  	$this->alternativo = false;
	$this->colour='white';
	$this->RkColour='white';
	$this->check="white";
  }
  
  

  public function setColour($colour){
	$this->colour=$colour;
  }
 

  public function setRkColour($RkColour){
	$this->RkColour=$RkColour;
  }
  public function setCheck($check){
	$this->check=$check;
  }
  public function setAcquiredKnowledge($acquiredknowledge){//ritorna void e $acquiredknowledge è un Vector
  	$this->ak = array();
  	for($i=0; $i<count($acquiredknowledge); $i++){
  		$this->ak[]=$acquiredknowledge[$i];
  	}
  }
  
  public function setRequiredKnowledge($requiredknowledge){//ritorna void e $arequiredknowledge è un Vector
  	$this->rk = array();
  	for($i=0; $i<count($requiredknowledge); $i++){
  		$this->rk[]=$requiredknowledge[$i];
  	}
  }
  
  public function setId($identificativo){//$identificativo è String
  	$this->id = $identificativo;
  }
  
   public function setLearningStyles($ls){//$ls è un array di double
  	for($i=0; $i<4; $i++){
  		$this->learningStyles[$i]=$ls[$i];
  	}
  }
  
   public function setMinimumScore($ms){//$ms è double
  	$this->minimumScore = $ms;
  }
  
   public function setMinimumPossibleScore($ms){//$ms è double
  	$this->minimumPossibleScore = $ms;
  }
  
   public function setMaximumPossibleScore($ms){//$ms è double
  	$this->maximumPossibleScore = $ms;
  }
  
    public function setFruitionTime($mt){//$mt è long
  	$this->fruitionTime = $mt;
  }
    public function setMinimumTime($mt){//$mt è long
  	$this->minimumTime = $mt;
  }
  
    public function setMaximumTime($mt){//$mt è long
  	$this->maximumTime =$mt;
  }
  
   public function setExistsPosttest($mt){//$mt è boolean
  	$this->existsPosttest =$mt;
  }
  
   public function setAlternative($mt){//$mt è boolean
  	$this->alternativo = $mt;
  }
  
    public function setRead($mt){//$mt è boolean
  	$this->read = $mt;
  }
  
  public function setRecommended($mt){//$mt è boolean
  	$this->recommended = $mt;
  }
  
  public function setObtainedScore($mt){//$mt è double
  	$this->obtainedScore = $mt;
  }
  
  public function setApproach($app){//$app è String
  	$this->approach = $app;
  }
  
  public function setCorso($c){//$c è una stringa
  	$this->corso = $c;
  }
  
  public function getAcquiredKnowledge(){//ritorna Vector
  	return $this->ak;
  }
  
  public function getRequiredKnowledge(){//ritorna Vector
  	return $this->rk;
  }
  
  public function getId(){//ritorna String
  	return $this->id;
  }
  
   public function getLearningStyles(){//ritorna array di double
  	return $this->learningStyles;
  }
   public function getFruitionTime(){//ritorna long
  	return $this->fruitionTime;
  }
   public function getMinimumScore(){//ritorna double
  	return $this->minimumScore;
  }
  
    public function getMinimumPossibleScore(){//ritorna double
  	return $this->minimumPossibleScore;
  }
  
    public function getMaximumPossibleScore(){//ritorna double
  	return $this->maximumPossibleScore;
  }
  
    public function getMinimumTime(){//ritorna long
  	return $this->minimumTime;
  }
  
    public function getMaximumTime(){//ritorna long
  	return $this->maximumTime;
  }
  
   public function getExistsPosttest(){//ritorna boolean
  	return $this->existsPosttest;
  }
  
    public function getRead(){//ritorna boolean
  	return $this->read;
  }
  
    public function getRecommended(){//ritorna boolean
  	return $this->recommended;
  }
  
   public function getAlternativo(){//ritorna boolean
  	return $this->alternativo;
  }
  
    public function getObtainedScore(){//ritorna double
  	return $this->obtainedScore;
  }
  
    public function getApproach(){//ritorna String
  	return $this->approach;
  }
  
    public function getCorso(){//ritorna String
  	return $this->corso;
  }
  public function getRkColour(){
	return $this->RkColour;
  }
  public function getColour(){
	return $this->colour;
  }
  public function getCheck(){
	return $this->check;
  }
  /**
   * Confronta due Learning Node, sulla base dell'id
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * 
 * @param LearningNode $ln il Learning Node da confrontare
 * @return bool
 * 
 * 
**/
  public function equals($ln){
	  return ($this->id == $ln->getId());
  }
}
?>
