<?php

/**
 * Messaggi di interazione tra Lsplan e lo studente 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 *  
 * 
 **/

class Constants {
 /**
 * @var string
 **/	
	public static $acquisito1 = "Hai acquisito la conoscenza del modulo \"";
	
/**
 * @var string
 **/
	public static $acquisito2 = "\"!<br>Passa al prossimo modulo, seguendo l'ordine consigliato dal sistema.";
	
 /**
 * @var string
 **/
 	public static $replan = "I tuoi learning styles sono cambiati in modo considerevole, il sistema ti proporr&agrave; una nuova sequenza pi&ugrave; adeguata";
 /**
 * @var string
 **/
 	public static $riprova = "Forse non hai studiato con sufficiente attenzione l'unit&agrave; didattica, prova a rileggerla.";
 /**
 * @var string
 **/
	public static $rispiega = "Prova a studiare nuovamente questo argomento con materiale alternativo.";
 /**
 * @var string
 **/
	public static $prerequisiti = "Verifica la tua conoscenza dei prerequisiti di questo modulo.";
 /**
 * @var string
 **/
	public static $nulladafare = "Il sistema prover&agrave; a proporti una nuova sequenza, ma visti i problemi riscontrati contatta il docente.";
 /**
 * @var string
 **/
	//public static $finecorso = "complimenti! hai terminato il corso!";
	public static $finecorso = "Complimenti, hai terminato il corso!<br>Ora compila il Test Finale ed il questionario<br>sulla valutazione di questa esperienza.";
/**
 * @var string
 **/
	public static $doTestLS = "Ti invitiamo, prima di iniziare il corso, a darci alcune informazioni su come ti piacerebbe imparare, cioe' sul tipo di materiale didattico che preferiresti avere a disposizione.";
/**
 * @var string
 **/
	public static $doQuiz = "Esegui il test d'ingresso per verificare le conoscenze che gia' hai sull'argomento.";

	
}
?>
