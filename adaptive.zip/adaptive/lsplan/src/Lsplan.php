<?php
require_once("AdaptationEngine.php");
//TODO RENDERE PARAMETRICO NELLA GESTIONEDB  IL DB
// NELLA UTILS IL PERCORSO
//TODO GESTIONE ECCEZIONI

/**
 * Classe di controllo dell'esecuzione
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 * 
 **/

class Lsplan {
	
	
	/** Avvia Lsplan, a seconda del tipo di operazione
	 * Lsplan viene chiamato con diversi parametri:
	 * il primo rappresenta l'operazione da eseguire
	 * 1 - creazione modello studente e prima los consigliata
	 * 2 - aggiornamento modello studente e los
	 * 3 - reperimento del modello studente attuale
	 *
	 * in caso di conoscenze iniziali nulle il chiamante deve passare la costante "empty"
	 * LsPlan scrive nel file con cui viene chiamato la los completa e quella raccomandata
	 * le possibili azioni sono in Constants.php
	 *
	* @author Matteo Lombardi <maluit@alice.it>
	*
	* @version 1.0
	 *  
	 * @param string $values stringa contenente il numero dell'operazione e i parametri necessari, separati da spazio
	 *
	 **/
	 public static function main($values){ //void
	 	$argv=explode('^',$values);
	 	if($argv[0] != '')
        {
            $operazione = $argv[0];
           // System.out.println("operazione da lecomps : " + operazione);
            if($operazione==1){
            	$matricola = $argv[1];
            	//System.out.println("matricola da lecomps : " + matricola);
            	$startingKnowledge = $argv[2];

            	//System.out.println("startingKnowledge da lecomps : " + startingKnowledge);
               	$startingKnowledgelevels = $argv[3];
            	//System.out.println("startingKnowledgelevels da lecomps : " + startingKnowledgelevels);
            	if($startingKnowledge=='empty'){
            		$startingKnowledge='';
            		$startingKnowledgelevels='';
            	}

            	//System.out.println("startingKnowledge eventualmente convertita : " + startingKnowledge);
            	//System.out.println("startingKnowledgelevels eventualmente convertita : " + startingKnowledgelevels);
            	$ls1 = $argv[4];
            //	System.out.println("ls1 da lecomps : " + ls1);
            	$ls2 = $argv[5];
            //	System.out.println("ls2 da lecomps : " + ls2);
            	$ls3 = $argv[6];
            //	System.out.println("ls3 da lecomps : " + ls3);
            	$ls4 =$argv[7];
            //	System.out.println("ls4 da lecomps : " + ls4);
            	$nome = $argv[8];

            //	System.out.println("nome da lecomps : " + nome);
            	$cognome = $argv[9];

            //	System.out.println("cognome da lecomps : " + cognome);
            	$targetKnowledge = $argv[10];

            //	System.out.println("targetKnowledge da lecomps : " + targetKnowledge);
            	$targetKnowledgelevels = $argv[11];

           // 	System.out.println("targetKnowledgelevels da lecomps : " + targetKnowledgelevels);
            	$corso = $argv[12];

            //	System.out.println("corso da lecomps : " + corso);
            	$sm = Lsplan::createStudentModel($matricola,$startingKnowledge,$startingKnowledgelevels,$ls1,$ls2,$ls3,$ls4,$nome,$cognome,$targetKnowledge,$targetKnowledgelevels,$corso);
            	Lsplan::createFirstLearningObjectsSequence($sm, $corso);
            	GestoreDB::logCreateSMeLOS($sm->getIdstudente(),$corso);
            }
            else if ($operazione==2){
            	$matricola = $argv[1];
            //	System.out.println("matricola da lecomps : " + matricola);
            	$nodo = $argv[2];
            //	System.out.println("nodo da lecomps : " + nodo);
            	$punteggio = $argv[3];
            //	System.out.println("punteggio da lecomps : " + punteggio);
            	$fruitiontime = $argv[4];
           // 	System.out.println("fruitiontime da lecomps : " + fruitiontime);
            	$corso = $argv[5];
           // 	System.out.println("corso da lecomps : " + corso);
            	Lsplan::update($matricola,$fruitiontime, $punteggio, $corso, $nodo);
            	GestoreDB::logUpdateSMeLOS($matricola,$corso,$nodo,$punteggio,$fruitiontime);
            }
            else{
            	$matricola = $argv[1];
            	$corso = $argv[2]; //AL MOMENTO IL CORSO NON C'E'
            	/*print_r("matricola : ".$matricola."<br>");
            	print_r("corso : ".$corso."<br>");*/
            	$actualSM = AdaptationEngine::getStudentModel($matricola,$corso); //AL MOMENTO IL CORSO NON C'E'
            	//Lsplan::stampaModelloStudente($actualSM);
            	return $actualSM;
            	/*print_r("nome :".$actualSM->getNome()."<br>");
  				print_r("cognome :".$actualSM->getCognome()."<br>");
  				$actualLS = $actualSM->getLearningStyles();
  				print_r("activereflective :".$actualLS[0]."<br>");
  				print_r("sensingintuitive :".$actualLS[1]."<br>");
  				print_r("visualverbal :".$actualLS[2]."<br>");
  				print_r("sequentialglobal :".$actualLS[3]."<br>");
  				$cognitiveState = $actualSM->getCognitiveState();
  				if (!empty($cognitiveState)){
  					$cs ="";
  					$levels="";
  					for($i=0; $i<count($cognitiveState); $i++){
  						$ki = $cognitiveState[$i];
  						$cs = $cs.$ki->getId().",";
  						$levels = $levels.$ki->getLevel().",";
  					}
  					if ($cs != ''){
  						$cs = substr($cs,0, strlen($cs)-1);
  						print_r("cognitivestate : ".$cs."<br>");
  					}  						
  					else 
  						print_r("cognitivestate : empty <br>");
  					if ($levels!=''){
  						$levels = substr($levels,0, strlen($levels)-1);
  						print_r("levels : ".$levels."<br>");
  					}  						
  					else
  						print_r("levels : empty <br>");			
  				}
  				else{
  					print_r("cognitivestate : empty <br>");
  					print_r("levels : empty <br>");
  				}
  				$visited = $actualSM->getVisitedNodes();
  				if (!empty($visited)){
  					$visitati = "";
  					for($i=0; $i<count($visited); $i++){
  						$ln = $visited[$i];
  						$visitati = $visitati.$ln->getId().","; 
  					}
  					if($visitati!=''){
  						$visitati = substr($visitati,0, strlen($visitati)-1);
  						print_r("visitati : ".$visitati."<br>");
  					}
  					else
  						print_r("visitati : empty <br>");
  				}
				else
					print_r("visitati : empty <br>");
  				$goal = $actualSM->getGoal();
  				if ((!empty($goal) && ($goal!=''))){
  					$g ="";
  					$levelsg="";
  					for($i=0; $i<count($goal); $i++){
  						$kig = $goal[$i];
  						$g = $g.$kig->getId().",";
  						$levelsg = $levelsg.$kig->getLevel().",";
  					}
  					if($g!=''){ 
  						$g = substr($g,0, strlen($g)-1);
  						print_r("goal : $g <br>");
  					}
  					else
  						print_r("goal : empty <br>");
  					if($levelsg!=''){ 
  						$levelsg = substr($levelsg,0, strlen($levelsg)-1);
  						print_r("goallevels : ".$levelsg."<br>");
  					}
  					else  					
  						print_r("goallevels : empty <br>");
  				}
  				else{
  					print_r("goal : empty <br>");
  					print_r("goallevels : empty <br>");
  				}
  */
  
            }
        }    	
	 }
	
	 /** 
 * In base alle informazioni iniziali sullo studente ne crea il modello
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * @param long $matricola identificativo unico dello studente
 * @param string $startingknowledge stringa con gli id dei concetti che lo studente conosce, separati da virgola
 * @param string $startingknowledgelevels stringa con i livelli con cui lo studente conosce gli id del parametro precedente, separati da virgola
 * @param double $ls1 attivo-riflessivo
 * @param double $ls2 pratico-intuitivo
 * @param double $ls3 visuale-verbale
 * @param double $ls4 sequenziale-globale
 * @param string $nome il nome dello studente
 * @param string $cognome il cognome dello studente
 * @param string $targetknowledge stringa con gli id dei concetti che lo studente deve apprendere, separati da virgola
 * @param string $targetknowledgelevels stringa con i livelli con cui lo studente deve apprendere gli id del parametro precedente, separati da virgola
 *
 * @return StudentModel il modello studente creato 
**/	
	
	/*
	 * In base alle informazioni iniziali sullo studente ne crea il modello
	 * parametri di input:
	 * long matricola - identificativo unico dello studente
	 * String startingknowledge - stringa con gli id dei concetti che lo studente conosce, separati da virgola
	 * String startingknowledgelevels - stringa con i livelli con cui lo studente conosce gli id del parametro precedente, separati da virgola
	 * 4 double rappresentativi delle 4 dimensioni dei ls di F-S (attivo-riflessivo, sensing intuitive,visuale verbale,sequenziale globale)
	 * String nome
	 * String cognome
	 * String targetknowledge - stringa con gli id dei concetti che lo studente deve apprendere, separati da virgola
	 * String targetknowledgelevels - stringa con i livelli con cui lo studente deve apprendere gli id del parametro precedente, separati da virgola
	 */
	
				//long matricola,String startingknowledge, String startingknowledgelevels,double ls1, double ls2, double ls3, double ls4, String nome,String cognome,String targetknowledge,String targetknowledgelevels, String corso
	private static function createStudentModel($matricola,$startingknowledge, $startingknowledgelevels,$ls1, $ls2, $ls3, $ls4, $nome,$cognome,$targetknowledge,$targetknowledgelevels,$corso){ //StudentModel
		$sk = array();
		$levels = array();
		if($startingknowledge!=''){
			$startingKnow = explode(",",$startingknowledge);
			for($i = 0; $i< count($startingKnow); $i++)
				$sk[]=$startingKnow[$i];
				
				
			$startingKnowlev = explode(",",$startingknowledgelevels);
			for($i = 0; $i< count($startingKnowlev); $i++)
				$levels[]=$startingKnowlev[$i];
		}
		
		$goals = explode(",",$targetknowledge);
		$goal = array();
		for($i = 0; $i< count($goals); $i++)
			$goal[]=$goals[$i];
			
		$goalslev = explode(",",$targetknowledgelevels);
		$goalLevels = array();
		for($i = 0; $i< count($goalslev); $i++)
			$goalLevels[]=$goalslev[$i];
		
		$ls = array();
		$ls[0]=$ls1;
		$ls[1]=$ls2;
		$ls[2]=$ls3;
		$ls[3]=$ls4;
		$sm = AdaptationEngine::createStudentModel($matricola,$sk,$levels,$ls,$nome,$cognome,$goal,$goalLevels,$corso);
	    return $sm;
	}
	 /** 
 * Crea la prima sequenza di Learning Objects, scrivendo sulla prima riga di un file la sequenza completa e nella seconda riga la sequenza raccomandata
 * Nota: il nome del file è [idstudente].txt
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param StudentModel $sm il modello dello studente
 * @param string $corso il corso
 * 
 * 
**/
	
			//StudentModel sm, String corso
	private static function createFirstLearningObjectsSequence($sm,$corso){
		$los = AdaptationEngine::createFirstLearningObjectsSequence($sm, $corso, 1);
		$completa = AdaptationEngine::getLOScompleta($sm->getIdstudente(),0,$corso);
		//print_r($completa);
		$idstud=$sm->getIdstudente();
		$locazione="./corsi/$corso/los/$idstud.txt";
		Lsplan::scriviSuFile($locazione,$completa,"w");
		$raccomandata = AdaptationEngine::getLOScompleta($sm->getIdstudente(),1,$corso);
		//print_r($raccomandata);
		if($raccomandata=='' || $raccomandata==' '){
			Lsplan::scriviSuFile($locazione,'-',"a");
			Lsplan::scriviSuFile($locazione,Constants::$finecorso,"a");
		}
		else
			Lsplan::scriviSuFile($locazione,$raccomandata,"a");
	}

	/** Scrive una stringa su un file 
	 *
	* @author Matteo Lombardi <maluit@alice.it>
	*
	* @version 1.0
	 *  
	 * @param string $locazione path completo del file da scrivere
	 * @param string $stringa la riga da scrivere
	 * @param string $tipo il tipo di apertura del file
	 *
	 **/
	
	public static function scriviSuFile($locazione,$stringa,$tipo){
		$fp=fopen($locazione,$tipo);
		fwrite($fp,$stringa."\n");
		fclose($fp);
	}
	

	/** Effettua le operazioni necessarie a seguito della navigazione dello studente all'interno del corso
	* @author Matteo Lombardi <maluit@alice.it>
	*
	* @version 1.0
	 *  
	 * @param long $idstudente l'id dello studente
	 * @param long $fruitionTime il tempo di fruizione del LN
	 * @param double $score il punteggio ottenuto
	 * @param string $corso il corso
	 * @param string $idnode l'id del LN
	 *
	 **/
		
				//long idStudente, long fruitiontime, double score, String corso, String idnode
	private static function update($idStudente,$fruitiontime,$score,$corso,$idnode){
	//	System.out.println("idnodo dentro update " + idnode);
	//	System.out.println("fruitiontime dentro update " + fruitiontime);
	//	System.out.println("score dentro update " + score);
	//	System.out.println("corso dentro update " + corso);
		$locazione="./corsi/$corso/los/$idStudente.txt";
	
		$ln = AdaptationEngine::createStudiedLearningNode($idnode,$fruitiontime,$score,$corso);
		$sm = AdaptationEngine::getStudentModel($idStudente,$corso);
    	$los = AdaptationEngine::getLOS($idStudente, 0, $corso);

    	$acquisito = AdaptationEngine::updateStudentModel($sm,$ln,$los);
 
    	$cd=$sm->getChangedDimension();

    	$azione = "";
    	//acquisito = -1: corso finito
    	if($acquisito == -1)
    		$azione = Constants::$finecorso;
    	else
    		if($acquisito==0 || $sm->getChangedDimension()!=-1)
    			$azione = AdaptationEngine::updateLearningObjectsSequence($sm,$ln,$los,$corso);
		$completa = AdaptationEngine::getLOScompleta($idStudente,0,$corso);
		//print_r($completa);
		Lsplan::scriviSuFile($locazione,$completa,"w");
		$raccomandata = AdaptationEngine::getLOScompleta($idStudente,1,$corso);
		//print_r($raccomandata);
		Lsplan::scriviSuFile($locazione,$raccomandata,"a");
		if ($acquisito==1){
			$temp = $ln->getAcquiredKnowledge();
			$ak=$temp[0]->getId();
			Lsplan::scriviSuFile($locazione,Constants::$acquisito1.$ak.Constants::$acquisito2,"a"); //print_r(Constants::$acquisito);
			}
		else
			Lsplan::scriviSuFile($locazione,$azione,"a"); //print_r($azione);
	}
/*	public static function stampaModelloStudente($sm){
		print_r('<font face="Comic Sans MS">');
		print_r('<tr><strong><p align="center"'.">Ciao sono ".$sm->getNome().", il tuo modello virtuale di studente,<br>e fino adesso ");
		$cs=$sm->getCognitiveState();
		if(empty($cs))
			print_r("non ho conoscenze sugli argomenti del corso</p></strong></tr>");
		else{
			print_r("ho conoscenze sui seguenti argomenti del corso: </strong><br>");
			print_r("</p></tr>");
			print_r('<div align="center"><ul>');
			foreach($cs as $ki){
				$stringa=str_replace("_"," ",$ki->getId());
				print_r('<li>'.$stringa.'</li>');
			}
			print_r('</ul></div>');
		}
		print_r("<center>");
		print_r("<tr><strong><p>Mi piace imparare un nuovo argomento in questo modo:</p></strong></tr>");
		$ls=$sm->getLearningStyles();
		//prima dimensione: attivo-riflessivo
		$valdimensactrefl=$ls[0];
		if(($valdimensactrefl>=-11)&&($valdimensactrefl<-7))
		 //$stampaactrefl = "Sei uno studente molto attivo";
		 $stampaactrefl = "Molto attivamente, facendo tante prove su quello che sto studiando";
		else if(($valdimensactrefl>=-7)&&($valdimensactrefl<-3))
		// $stampaactrefl = "Sei uno studente abbastanza attivo";
		 $stampaactrefl = "Abbastanza attivamente, facendo delle prove su quello che sto studiando";
		else if(($valdimensactrefl>=-3)&&($valdimensactrefl<0))
		// $stampaactrefl = "Sei uno studente leggermente piu' attivo che riflessivo";
		$stampaactrefl = "Generalmente piu' attivamente, facendo qualche prova su quello che sto studiando, piuttosto che riflettendo";
		if(($valdimensactrefl>=0)&&($valdimensactrefl<3))
		// $stampaactrefl = "Sei uno studente leggermente piu' riflessivo che attivo";
		$stampaactrefl = "Generalmente riflettendo sull'argomento piuttosto che facendo prove";
		else if(($valdimensactrefl>=3)&&($valdimensactrefl<7))
		// $stampaactrefl = "Sei uno studente abbastanza riflessivo";
		$stampaactrefl = "Riflettendo abbastanza sull'argomento piuttosto che facendo prove";
		else if(($valdimensactrefl>=7)&&($valdimensactrefl<=11))
		// $stampaactrefl = "Sei uno studente molto riflessivo";
		$stampaactrefl = "Riflettendo a lungo sull'argomento piuttosto che facendo prove";
		
		//seconda dimensione: pratico-intuitivo
		$valdimenssensint=$ls[1];
		if(($valdimenssensint>=-11)&&($valdimenssensint<-7))
		// $stampasensint = "Sei uno studente molto pratico";
		$stampasensint = "in modo molto pratico piuttosto che teorico";
		else if(($valdimenssensint>=-7)&&($valdimenssensint<-3))
		// $stampasensint = "Sei uno studente abbastanza pratico";
		$stampasensint = "in modo abbastanza pratico piuttosto che teorico";
		else if(($valdimenssensint>=-3)&&($valdimenssensint<0))
		// $stampasensint = "Sei uno studente leggermente piu' pratico che intuitivo";
		$stampasensint = "in modo piuttosto pratico invece che teorico";
		if(($valdimenssensint>=0)&&($valdimenssensint<3))
		// $stampasensint = "Sei uno studente leggermente piu' intuitivo che pratico";
		$stampasensint = "in modo piuttosto teorico invece che pratico";
		else if(($valdimenssensint>=3)&&($valdimenssensint<7))
		// $stampasensint = "Sei uno studente abbastanza intuitivo";
		$stampasensint = "in modo abbastanza teorico piuttosto che pratico";
		else if(($valdimenssensint>=7)&&($valdimenssensint<=11))
		// $stampasensint = "Sei uno studente molto intuitivo";
		$stampasensint = "in modo molto teorico piuttosto che pratico";
		
		//terza dimensione: visuale-verbale
		$valdimensvisverb=$ls[2];
		if(($valdimensvisverb>=-11)&&($valdimensvisverb<-7))
		// $stampavisverb = "Sei uno studente molto visuale";
		$stampavisverb = "Guardando molti video, grafici, immagini, piuttosto che leggendo e ascoltando spiegazioni";
		else if(($valdimensvisverb>=-7)&&($valdimensvisverb<-3))
		// $stampavisverb = "Sei uno studente abbastanza visuale";
		$stampavisverb = "Preferendo abbastanza video, grafici, immagini, piuttosto che leggendo e ascoltando spiegazioni";
		else if(($valdimensvisverb>=-3)&&($valdimensvisverb<0))
		// $stampavisverb = "Sei uno studente leggermente piu' visuale che verbale";
		$stampavisverb = "Preferendo leggermente i video, grafici, immagini, ai testi scritti";
		if(($valdimensvisverb>=0)&&($valdimensvisverb<3))
		// $stampavisverb = "Sei uno studente leggermente piu' verbale che visuale";
		$stampavisverb = "Preferendo leggermente i testi scritti piuttosto che video, grafici, immagini";
		else if(($valdimensvisverb>=3)&&($valdimensvisverb<7))
		// $stampavisverb = "Sei uno studente abbastanza verbale";
		$stampavisverb = "Preferendo abbastanza i testi scritti piuttosto che video, grafici, immagini";
		else if(($valdimensvisverb>=7)&&($valdimensvisverb<=11))
		// $stampavisverb = "Sei uno studente molto verbale";
		$stampavisverb = "Preferendo moltissimo i testi scritti piuttosto che video, grafici, immagini";
		
		//quarta dimensione: sequenziale-globale
		$valdimensseqglb=$ls[3];
		if(($valdimensseqglb>=-11)&&($valdimensseqglb<-7))
		// $stampaseqglb = "Sei uno studente molto sequenziale";
		$stampaseqglb = "osservando molto attentamente le parti per cogliere il tutto";
		else if(($valdimensseqglb>=-7)&&($valdimensseqglb<-3))
		// $stampaseqglb = "Sei uno studente abbastanza sequenziale";
		$stampaseqglb = "osservando attentamente le parti per cogliere il tutto";
		else if(($valdimensseqglb>=-3)&&($valdimensseqglb<0))
		// $stampaseqglb = "Sei uno studente leggermente piu' sequenziale che globale";
		$stampaseqglb = "osservando superficialmente le parti per cogliere il tutto";
		if(($valdimensseqglb>=0)&&($valdimensseqglb<3))
		// $stampaseqglb = "Sei uno studente leggermente piu' globale che sequenziale";
		$stampaseqglb = "osservando superficialmente il tutto piuttosto che le parti";
		else if(($valdimensseqglb>=3)&&($valdimensseqglb<7))
		// $stampaseqglb = "Sei uno studente abbastanza globale";
		$stampaseqglb = "osservando attentamente il tutto piuttosto che le parti";
		else if(($valdimensseqglb>=7)&&($valdimensseqglb<=11))
		// $stampaseqglb = "Sei uno studente molto globale";
		$stampaseqglb = "osservando molto attentamente il tutto piuttosto che le parti";
		
		print_r("<tr>$stampaactrefl <br></tr>");
		print_r("<tr>$stampasensint <br></tr>");
		print_r("<tr>$stampavisverb <br></tr>");
		print_r("<tr>$stampaseqglb  <br></tr>");
		
		print_r("<tr><br><strong><p>Quanto ti assomiglio?</p></strong></tr>");
		print_r("</font></center>");
		 $csstronglydisagree = "per niente";
		  $csquitedisagree = "molto poco";
		  $csdisagree = "poco";
		  $csneutral = "non so";
		  $csagree = "abbastanza";
		  $csquiteagree = "tanto";
		$csstronglyagree = "tantissimo";
		$idstud=$sm->getIdstudente();
		$corso=$sm->getCorso();
?>
<table>
<form name="form_feedback" action="visualizzaProfilo.php?userid=<?php echo $idstud; ?>&courseid=<?php echo $corso; ?>" method="GET">
<tr><td width="14%" align="right" ><?php  echo '<input type="radio" name="feedback" value="' . $csstronglydisagree . '">'.$csstronglydisagree;?></td>
<td width="14%" align="right"><?php  echo '<input type="radio" name="feedback" value="' . $csquitedisagree. '">'.$csquitedisagree;?></td>
<td width="14%" align="right"><?php  echo '<input type="radio" name="feedback" value="' . $csdisagree . '">'.$csdisagree;?></td>
<td width="14%" align="right"><?php  echo '<input type="radio" name="feedback" value="' . $csneutral . '">'.$csneutral;?></td>
<td width="14%" align="right"><?php  echo '<input type="radio" name="feedback" value="' . $csagree . '">'.$csagree;?></td>
<td width="14%" align="right"><?php  echo '<input type="radio" name="feedback" value="' . $csquiteagree . '">'.$csquiteagree;?></td>
<td width="14%" align="right"><?php  echo '<input type="radio" name="feedback" value="' . $csstronglyagree . '">'.$csstronglyagree;?></td>
<?php  echo '<input type="hidden" name="userid" value="'.$idstud.'">'; 
		echo '<input type="hidden" name="courseid" value="'.$corso.'">';
?>
</tr>
<tr><td></td><td></td><td></td><td align="right"><input type="Submit" Name="Submit1" value="Invia"></td></tr>
</form>
</table>
<?php
	}*/
}

?>
