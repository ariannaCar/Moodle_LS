<?php
require_once("AlberoXml.php");
require_once("./IWT/src/EsecutoreIwt.php");

/**
 * Classe di interfaccia tra Lsplan e un algoritmo di sequencing
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 * 
 **/

class Utils {

			
/**
 * Chiama l'algoritmo di sequencing scelto, fornendogli modello studente e corso
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param StudentModel $sm il modello studente
 * @param string $corso il corso
 * @return string la LOS prodotta dall'algoritmo
 * 
 * 
**/		
	public static function callAlg($sm,$corso) { //los, String (Alg torna array(LearningNode))		
		
		$cs=$sm->getCognitiveState();
		
		$alb=new AlberoXml($corso);
		//$alb->stampa();
		$e=new EsecutoreIwt($sm,$alb);
		
		$losString = '';
		$los=$e->getLos();
		foreach($los as $ki)
			$losString .= ','.$ki->getId();

		$losString = substr($losString,1);
//		print_r($losString);
		return $losString;
	}
 
    
}

?>
