<?php

/**
 * L'oggetto che rappresenta un Knowledge Item (KI)
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 *  
 * 
 **/
//NB: In php5 non si può sovracaricare il costruttore, mettiamo un metodo costruttore alternativo al costruttore di default(sempre se usato)
class KnowledgeItem {
/**
	 * @var string
	 **/	
  public $id;
  /**
	 * @var string
	 **/
  public $level;
  /**
	 * @var bool
	 **/
  private $posseduto;
  
  
  /**
 * Crea un Knowledge Item vuoto
 * @author Matteo Lombardi <maluit@alice.it>
 *@version 1.0
 * 
 * 
**/
  public function __construct(){
  
  }
    /**
 * Crea un Knowledge Item con id e livello
 * @author Matteo Lombardi <maluit@alice.it>
 *@version 1.0
 * @param string $id l'id del KI
 * @param string $level il livello del KI
 * 
 * 
**/
  public function costruttore($id, $level){
  	$this->id = $id;
  	$this->level = $level;
  }
  
  public function getId() {
  	return $this->id;
  }

  public function getLevel() {
  	return $this->level;
  }
  
  public function getPosseduto() {
  	return $this->posseduto;
  }

  public function setId($ki) {
  	$this->id = $ki;
  }

  public function setLevel($level) {
  	$this->level = $level;
  }

  public function setPosseduto($poss) {
  	$this->posseduto = $poss;
  }
  /**
 * Confronta due oggetti Knowledge Item
 * @author Matteo Lombardi <maluit@alice.it>
 *@version 1.0
 * @param KnowledgeItem $aux il KI da confrontare con il this
 * 
 * @return bool
 * 
**/
  public function confronta($aux){//$aux e' di tipo KnowledgeItem
	$level=$aux->level;
	$id=$aux->id;
  	if (strcasecmp($id,$this->id)==0 && strcasecmp($level,$this->level)==0){
  		return true;
  		}
  	else 
		return false;
  	
  	}
}
?>
