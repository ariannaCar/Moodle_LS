<?php
require_once("GestoreDB.php");
require_once("Lsplan.php");
/**
 * Permette al LMS l'accesso al DB di Lsplan per svolgere delle funzioni particolari 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 *  
 * 
 **/
class Accesso{

	/**
	* Metodo per la selezione delle operazioni da svolgere sul DB
	* @author Matteo Lombardi <maluit@alice.it>
	* @version 1.0
	* 
	* @param string $arg Stringa che contiene l'operazione da svolgere e i dati necessari (separati da spazio)
	**/
	public static function main($arg){
		$args = explode("^",$arg);
		$operazione = $args[0];
		$dati = $args[1];
		switch($operazione){
			case 1: GestoreDB::inserisciLN($dati);
				break;
			case 2: GestoreDB::aggiornaLN($dati);
				break;
			case 3: GestoreDB::cancellaLN($dati);
				break;	
			case 4: $datiLN = explode(";",$dati);
				$idLN=$datiLN[0]; //String 
				$course= $datiLN[1]; //String
				$locazione="./temp/".$idLN.$course.".txt";
				Lsplan::scriviSuFile($locazione,GestoreDB::getMetadatiLN($dati),"w");
				break;
		
		}
	
	}
}
?>
