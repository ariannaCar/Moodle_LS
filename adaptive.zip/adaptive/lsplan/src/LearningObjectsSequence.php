<?php
/**
 * La sequenza di Learning Node proposta allo studente
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 * 
 **/
class LearningObjectsSequence {
	
	/**
	* @var array
	**/
  private $path;//Vector
   /**
	* @var long
	**/
  public $idStudente;//long
   /**
	* @var string
	**/
  public $corso;//String

/**
 * Crea una istanza di LearningObjectsSequence a partire dall'insieme dei LN, lo studente e il corso 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param array $lns l'insieme dei LN
 * @param long $idstud l'id dello studente
 * @param string $corso il corso
 * 
 * 
**/

  public function __construct($lns, $idstud, $corso){//Vector lns, long idstud
  	$this->idStudente = $idstud;
  	$this->path = array();
  	for($i=0; $i<count($lns); $i++){
  		$this->path[]=$lns[$i];
	}
	$this->corso = $corso;
  }
  
  /**
 * Ritorna la LOS dello studente al quale è associata questa istanza di LearningObjectsSequence
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @return array la sequenza LOS
 * 
 * 
**/
  	//return Vector
  public function getLearningObjectsSequence(){
  	return $this->path;
  }
  
 /**
 * Ritorna l'indice del LN nella LOS
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * @param string $id l'id del LN
 * 
 * @return integer l'indice, altrimenti -2
 * 
 * 
**/
	//return int
  public function indexOfLN($id){//String id
  	for ($i = 0; $i < count($this->path); $i++){
     	$ln = $this->path[$i];
     	if ($id==$ln->getId())
     		return $i;
     }
  	return -2;
  }
  
   /**
 * Imposta la LOS
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * @param array $los la LOS
 * 
 * 
 * 
**/
  
  public function setLearningObjectsSequence($los){
  	$this->path =$los;
  }
  
  public function setCorso($c){
  		$this->corso = $c;
  	}
  	//return String
  	public function getCorso(){
  		return $this->corso;
  	}
}
?>
