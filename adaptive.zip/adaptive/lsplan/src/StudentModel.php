<?php

/**
 * Descrive il modello studente
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 *  
 * 
 **/

//cognitiveState e visitedNodes sono vettori di ki
class StudentModel {
/**
 * @var long
 **/
   	private $id; //long
/**
 * @var string
 **/
	private $nome;
 /**
 * @var string
 **/
 	private $cognome;
/**
 * @var array
 **/
	private $learningStyles;  //double[]
/**
 * @var array
 **/
	private $cognitiveState; //Vector
/**
 * @var array
 **/	
	private $visitedNodes;
/**
 * @var integer
 **/	
	private $changedDimension; //int
/**
 * @var array
 **/	
	private $goal;
/**
 * @var string
 **/	
	private $corso;
/**
 * @var long
 **/	
	private $idstudente;//long

	private $percentuale;
/**
 * Crea un modello studente vuoto
 * @author Matteo Lombardi <maluit@alice.it>
 * @version 1.0
 * 
 * 
**/
  	public function __construct(){
	  	$this->learningStyles = array();
	  	$this->cognitiveState = array();
	  	$this->visitedNodes = array();
	  	$this->goal = array();
		$this->changedDimension = -1;
	}

	public function setId($identificativo){//void
	  	$this->id = $identificativo;
	}
	public function setNome($nomestudente){//void
		$this->nome = $nomestudente;
	}
//  
public function setPercentuale($perce){
	$this->percentuale=$perce;
}
	public function setCognome($cognomestudente){// void
		$this->cognome = $cognomestudente;
	}
	  
	public function setCognitiveState($cs){//void
		$this->cognitiveState=array();
	  	for($i=0; $i<count($cs); $i++){
	  		$this->cognitiveState[]=$cs[$i];
	  	}
  	}
//  
	public function setGoal($goalSM){ //void
	  	$goal = array();
	  	for($i=0; $i<count($goalSM); $i++){
	  		$this->goal[]=$goalSM[$i];
  		}
	}
//  
//vettore di 4 double rappresentativi delle dimensioni di Felder e Silverman
	public function setLearningStyles($ls){//void
	  	for($i=0; $i<4; $i++){
	  		$this->learningStyles[$i]=$ls[$i];
	  	}
  	}
  	
  	public function setCorso($c){
		$this->corso=$c;
	}
	
	public function setIdstudente($ids){
		$this->idstudente=$ids;
	}
/**
 * Aggiunge un learning node ai nodi visitati
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0 
 * @param LearningNode $ln il learning node visitato
 * 
 * 
**/	
  	public function addVisitedNodes($ln){//void
	 	$this->visitedNodes[]=$ln; //ln � LearningNode
	}
//  
//vale -1 se non � cambiato il segno di nessuna dimensione di FS, altrimenti il suo valore individua la dimensione che ha cambiato segno
	public function setChangedDimension($dimension){//void
		$this->changedDimension = $dimension;
	}
 

	public function getId(){ //long
		return $this->id;
	}
//  	
	public function getNome(){//String
		return $this->nome;
	}
	public function getPercentuale(){//String
		return $this->percentuale;
	}
	
	public function getCognome(){//String
		return $this->cognome;
	}
	
	public function getCognitiveState(){//Vector
		return $this->cognitiveState;
	}
//  
	public function getGoal(){//Vector
	  	return $this->goal;
	}
//  
	public function getLearningStyles(){//double[]
	    return $this->learningStyles;
	}
	public function getVisitedNodes(){//Vector
	  	return $this->visitedNodes;
	}
	public function getCorso(){//string
	  	return $this->corso;
	}
	public function getIdstudente(){//long
	  	return $this->idstudente;
	}
//  
	public function getChangedDimension(){//int
	  	return $this->changedDimension;
	}
/**
 * Verifica se il nodo con un certo id � stato visitato
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $id l'id del nodo da controllare
 * 
 * @return bool TRUE se il nodo � gi� stato visitato, altrimenti FALSE 
**/
	public function isVisitedNode($id){//boolean, id � tipo String 
	  	for ($i = 0; $i < count($this->visitedNodes); $i++){
			$ln = $this->visitedNodes[$i]; //ln � LearningNode 
			if ($id == $ln->getId())
				return true;
	    }
	  	return false;
	}
//  
}
?>
