<?php

require_once("Utils.php");
require_once("Constants.php");
require_once("LearningObjectsSequence.php");
require_once("StudentModel.php");
require_once("GestoreDB.php");
require_once("KnowledgeItem.php");

/**
 * Motore adattivo
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 * 
 **/

class AdaptationEngine {


/*+++++++++++++++++++++ METODI DI INIZIALIZZAZIONE: MODELLO STUDENTE, LOS, LN  +++++++++++++++++++++++++++++++++++++++++++++++/
  
 /** 
 * inizializza il modello studente
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param long $matricola la matricola dello studente
 * @param array $startingKnowledge le conoscenze iniziali
 * @param array $levels i livelli delle conoscenze iniziali
 * @param array $learningStyles i Learning Styles
 * @param string $nome il nome dello studente
 * @param string $cognome il cognome dello studente
 * @param array $goal gli obiettivi di apprendimento
 * @param array $goalLevels i livelli degli obiettivi
 * @param string $corso il corso
 * 
 * @return StudentModel il modello studente
 * 
 * 
**/
		//long matricola, Vector startingKnowledge, Vector levels, double[] learningStyles, String nome, String cognome,Vector goal, Vector goalLevels
  public static function createStudentModel($matricola,$startingKnowledge,$levels,$learningStyles,$nome,$cognome,$goal,$goalLevels,$corso) { //StudentModel
  	$cognitivestate = "";
  	$lev = "";
  	$studentGoal = "";
  	$percentuale="";
  	$goalLev = "";
  	$sm = new StudentModel();
  	$sm->setIdstudente($matricola);
  	$sm->setNome($nome);
  	$sm->setCognome($cognome);
  	$sm->setLearningStyles($learningStyles);
  	
  	/*NOTA1: Implementazione come vettore di ki posseduti 
  	valutare se creare array di tutti i ki segnalando solo i posseduti
  	e fare quindi passare a questo metodo anche i ki non posseduti	*/
  	$cs = array();
  		
  	for($i = 0; $i<count($startingKnowledge); $i++){
  		$ki = new KnowledgeItem();
  		$k = $startingKnowledge[$i];
  		$ki->setId($k);
  		$cognitivestate = $cognitivestate.$k.",";
  		if($percentuale=="")
  		$percentuale = $percentuale."100";
  		else
  		$percentuale = $percentuale.",100";
  		$l = $levels[$i];
  		$ki->setLevel($l);
  		$lev = $lev.$l.",";
  		$ki->setPosseduto(true);
  		$cs[]=$ki;
  	}
  	if ($cognitivestate!= null && $cognitivestate!="")
  		$cognitivestate = substr($cognitivestate,0,strlen($cognitivestate)-1);
  	if ($lev!= null && ! $lev == "")
  		$lev = substr($lev,0,strlen($lev)-1);
  	$sm->setCognitiveState($cs);
  	
  	
  	$g = array();
  		
  	for($i = 0; $i< count($goal); $i++){
  		$kig = new KnowledgeItem();
  		$kg = $goal[$i];
  		$kig->setId($kg);
  		$studentGoal = $studentGoal.$kg.",";
  		$lg = $goalLevels[$i];
  		$kig->setLevel($lg);
  		$goalLev = $goalLev.$lg.",";
  		$kig->setPosseduto(true);
  		$g[]=$kig;
  	}
  	if ($studentGoal!= null && $studentGoal!="")
  		$studentGoal = substr($studentGoal,0, strlen($studentGoal)-1);
  	if ($goalLev!= null && $goalLev!="")
  		$goalLev = substr($goalLev,0,strlen($goalLev)-1);
  	$sm->setGoal($g);
  	$sm->setCorso($corso);
  	
    $sm->setLearningStyles($learningStyles);
   // System.out.println("cs in create student model -" + cognitivestate+"-");
   // long id = GestoreDB.createStudentModel(cognitivestate,lev,learningStyles[0],learningStyles[1],learningStyles[2],learningStyles[3],nome,cognome);
 	$id = GestoreDB::createStudentModel($matricola,$cognitivestate,$lev,$learningStyles[0],$learningStyles[1],$learningStyles[2],$learningStyles[3],$nome,$cognome,$studentGoal,$goalLev,$corso,$percentuale);
   
   $sm->setId($id);

  	return $sm;
  }
  
 /** 
 * inizializza la LOS per lo studente, creando sia quella completa che quella personalizzata
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param StudentModel $sm il modello dello studente
 * @param string $corso il corso
 * @param integer $firstTime firstTime vale 1 se il metodo viene chiamato per un nuovo studente, 2 se il metodo viene chiamato per il re-planning
 * @return LearningObjectsSequence la LOS completa
 * 
 * 
**/
	
	
public static function createFirstLearningObjectsSequence($sm,$corso,$firstTime) {//StudentModel sm, String corso, int firstTime
  	/*il metodo deve
  	 1. creare il problem.pddl per il caso più generale: studente con i ls di sm e con conoscenza vuota 
  	 2. chiamare pdk per la generazione della LOS "completa"	
  	 3. tradurre l'uscita di pdk nella LOS 			
  	 	3.b completandola con nodi alternativi
  	 4. creare il problem.pddl per lo studente specifico 		
  	 5. chiamare pdk per la generazione della LOS	
  	 6. tradurre l'uscita di pdk nella LOS effettiva per lo studente 
  	   6.b settare a true gli attributi recommended dei LN della LOS generale proposti per lo specifico studente 
  	   e creare la LOS di ausilio con i soli nodi consigliati
  	 NOTA: supponiamo il domain.pddl fissato e già creato
   	*/
  	/* firstTime vale 
  	 *	1 se il metodo viene chiamato per un nuovo studente
  	 *	2 se il metodo viene chiamato per il re-planning
  	 **/
  	
  	//modello studente fittizio, con uguali ls dello studente, ma cs vuota
  	$smFittizio =new StudentModel();
  	$smFittizio->setId(-$sm->getId());
  	$smFittizio->setIdstudente($sm->getIdstudente());
  	$vuoto = array();//Vector
  	$smFittizio->setCognitiveState($vuoto);
  	$smFittizio->setLearningStyles($sm->getLearningStyles());
  	$smFittizio->setGoal(GestoreDB::getAllAK($corso));
  	$startTime=time();
  	//chiamata a algoritmo di Sequencing

   $losComplete = Utils::callAlg($smFittizio, $corso);//String

  //	System.out.println("los completa generata da pdk = "+losComplete);
  	//chiamata a algoritmo di Sequencing
  	$startTime=microtime(true);

   	$losRecomm = Utils::callAlg($sm, $corso);//String
	$finishTime=microtime(true);
	$totalTimeAlg=($finishTime-$startTime)*1000;
	//print_r("<b>Tempo totale di esecuzione dell'algoritmo: $totalTimeAlg ms</b>");
	//System.out.println("los personalizzata generata da pdk = "+losRecomm);
  	//String losComplete = "id3,id10,id14,id6,id15,id11,id16,id13,id7,id2";
  	//String losRecomm = "id3,id10,id15,id16,id13,id7,id2";
  	$recommOnCompleta = "";
  	// dei ln conosco gli id e, volendo, dal db potrei recuperare altre info quali ak, rk, ls, etc.
  	// ma quì penso bastino gli id
  	
  	//vettore rappresentativo della sequenza completa
  	$lns = array();//Vector
  	//vettore rappresentativo della sequenza raccomandata
  	$lnsrecom = array();//Vector  
  	$losRecommArray=array();	
  	$losCompleteArray = explode(",",$losComplete);//array di stringhe
  	if($losRecomm!='' && $losRecomm!=' ')
		$losRecommArray = explode(',',$losRecomm);//array di stringhe
  	$losRecommVector = array();//Vector
  	//creo la sequenza raccomandata in base ai ls dello studente, ovvero dalla sequenza tirata fuori da pdk 
  	// se ci sono nodi alternativi inserisco il più adeguato allo studente
  	$losRecomm = "";
  	for($k = 0; $k < count($losRecommArray); $k++){
  			$lnr = GestoreDB::createLN($losRecommArray[$k],$corso);
  			$closest = AdaptationEngine::checkClosestNode($sm,$lnr,1);
  			$closest->setRecommended("true");
  			$lnsrecom[]=$closest;
  		  	$losRecomm = $losRecomm.$closest->getId().",";
  	}
  	
  	//System.out.println("los recomm dopo check closest= " + losRecomm);
  	$losComplete="";
  	
  	//creo la los completa, aggiungendo i ln alternativi
    //la los salvata su db sarà del tipo: id3,id10;id14,id6;id15...
    //dove ; tra due id vuol dire che essi sono alternativi
    // la , detta la sequenza
  	for($z = 0; $z < count($losCompleteArray); $z++){
  		//creo il learning node e lo inserisci nella los completa 
  	//	print_r("createln ".$losCompleteArray[$z].' '.$z.' ');
  		$ln1 = GestoreDB::createLN($losCompleteArray[$z],$corso);

  		$losComplete = $losComplete.$losCompleteArray[$z].",";
  		$ln1->setId($losCompleteArray[$z]);
  		//se il nodo è fra quelli consigliati
  		$pos = strpos($losRecomm,$losCompleteArray[$z]);
  		
  		$lunghezzaid = strlen($losCompleteArray[$z]);
  		
  		if(!($pos===FALSE)&&(($losRecomm[$pos + $lunghezzaid]==',')||(($pos + $lunghezzaid) ==strlen($losRecomm)))){
  					$ln1->setRecommended("true");
  					$recommOnCompleta = $recommOnCompleta."true,";
  		}
  				else
  					$recommOnCompleta = $recommOnCompleta."false,";
				
  		/*  		
  		if(losRecomm.indexOf(losCompleteArray[z])!=-1){
  			ln1.setRecommended(true);
  		//	lnsrecom.add(ln1);
  			recommOnCompleta = recommOnCompleta + "true,";
  		}
  		else
  			recommOnCompleta = recommOnCompleta + "false,";
  		*/
  		$lns[]=$ln1;
  		//inserisco nella los completa anche i ln alternativi
  		$alternatives = GestoreDB::getAlternativeNodes($ln1);//Vector
  		if (!empty($alternatives)){
  		for($g = 0; $g < count($alternatives); $g++){
  			$lna = GestoreDB::createLN($alternatives[$g],$corso);
  			$lna->setId($alternatives[$g]);
  			$lna->setAlternative(true);
  			$pos = strpos($losRecomm,$alternatives[$g]);
  			$lunghezzaid = strlen($alternatives[$g]);
  			if(!($pos===FALSE)&&(($losRecomm[$pos + $lunghezzaid]==',')||($pos + $lunghezzaid ==strlen($losRecomm)))){
  					$lna->setRecommended("true");
  					$recommOnCompleta = $recommOnCompleta."true,";
  			}
  			else
  					$recommOnCompleta = $recommOnCompleta."false,";
  			
  	/*	if(losRecomm.indexOf(String.valueOf(alternatives.get(g)))!=-1){
  				lna.setRecommended(true);
  				//	lnsrecom.add(ln1);
  				recommOnCompleta = recommOnCompleta + "true,";
  			}
  			else
  				recommOnCompleta = recommOnCompleta + "false,";*/
  			$lns[]=$lna;
  			$losComplete = substr($losComplete,0,strlen($losComplete)-1).";".$alternatives[$g].",";
  		}
  		}	
  	}
  	
  	
  	
  	$recommOnCompleta = substr($recommOnCompleta,0,strlen($recommOnCompleta)-1);
  	$losComplete = substr($losComplete,0,strlen($losComplete)-1);
  	//$losRecomm = substr($losRecomm,0,strlen($losRecomm)-1);
  	$losRecomm='';
	foreach($lns as $ln){
		if($ln->getRecommended()=="true")
			$losRecomm.=$ln->getId().',';
	}
	$losRecomm=substr($losRecomm,0,strlen($losRecomm)-1);
  
  //	System.out.println("los completa (presenti anche i nodi alternativi) " + losComplete);
  //	System.out.println("los personalizzata ottenuta da los pdk scegliendo tra i nodi alternativi i piu' vicini ai ls dello studente " + losRecomm);
  	
  	//los completa 
  	$losCompleta = new LearningObjectsSequence($lns,$sm->getIdstudente(),$corso);  
  	
  	if($firstTime == 1)	{
  		GestoreDB::createLOS($sm->getIdstudente(), $losComplete, $recommOnCompleta, 0,$corso);
  	}
  	else
  		GestoreDB::updateLOS($sm->getIdstudente(), $losComplete, $recommOnCompleta, 0, $corso); 		
  	
  	
  	//per usi futuri
  	$losRecommended = new LearningObjectsSequence($lnsrecom,$sm->getIdstudente(),$corso);
  	if($firstTime == 1)
  		GestoreDB::createLOS($sm->getIdstudente(), $losRecomm,"", 1,$corso);
  	else
  		GestoreDB::updateLOS($sm->getIdstudente(), $losRecomm,"", 1,$corso);
  	  		
  	return $losCompleta;
  } 
  
/** 
 * Seleziona il Learning Node studiato e lo aggiorna con tempo di fruizione e punteggio dello studente
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $idLN l'id del Learning Node
 * @param long $fruitionTime il tempo di fruizione
 * @param double $obtainedScore il punteggio ottenuto
 * @param string $corso il corso
 * 
 * @return LearningNode il Learning Node aggiornato
 * 
 * 
**/
  
			//String idLN, long fruitionTime, double obtainedScore, String corso
   public static function createStudiedLearningNode($idLN,$fruitionTime,$obtainedScore,$corso){ //LearningNode
 	//System.out.println("idLN dentro createstudiedln " + idLN);	
 	//System.out.println("fruitionTime dentro update " + fruitionTime);	
 	//System.out.println("obtainedScore dentro update " + obtainedScore);	
 	//System.out.println("corso dentro update " + corso);	
 	$ln = GestoreDB::createLN(trim($idLN),$corso); //LearningNode  
 	$ln->setFruitionTime($fruitionTime);
 	$ln->setObtainedScore($obtainedScore);
 	$ln->setRead(true);  	
 	$ln->setCorso($corso);	
 	return $ln;
 }
 
/** 
 * aggiorna il modello studente
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param StudentModel $currentSM il modello dello studente corrente
 * @param LearningNode $studiedLN il Learning Node studiato
 * @param LearningObjectsSequence $los la LOS associata allo studente
 * 
 * @return integer 	0 --> non acquisito, 1 --> acquisito, -1 --> acquisito e fine corso 
 * 
 * 
**/
 
 		//StudentModel currentSM, LearningNode studiedLN, LearningObjectsSequence los
  public static function updateStudentModel($currentSM, $studiedLN, $los) { //int
 	$corso = $currentSM->getCorso();
 	//acquisito = 0 --> non acquisito
 	//acquisito = 1 --> acquisito
 	//acquisito = -1 --> acquisito e fine corso
 	$acquisito = 0;
 	//se il post test non c'è oppure il punteggio nel test è sufficiente il ki (ak del ln) è considerato acquisito
 	var_dump($studiedLN->getObtainedScore());
 	$percentuale = ceil((100 * $studiedLN->getObtainedScore())/$studiedLN->getMaximumPossibleScore());
 	
 	/*if(($studiedLN->getObtainedScore() >= $studiedLN->getMinimumScore()) || (!$studiedLN->getExistsPosttest())){*/
 	if($percentuale >= $studiedLN->getMinimumScore() || !$studiedLN->getExistsPosttest() ){
 		//System.out.println("ki acquisito");
 		$aks = $studiedLN->getAcquiredKnowledge();
 		$ak = $aks[0]; //KnowledgeItem
 		// si aggiorna il cs dello studente aggiungendo il ki acquisito
 		$present = false;
 		for ($i = 0; $i< count($currentSM->getCognitiveState()); $i++)
 		{	
			$cs = $currentSM->getCognitiveState();
 			$kiauxil = $cs[$i]; //KnowledgeItem 
 			if ($kiauxil->confronta($ak)){
				$present=true;
			}
			
 		}
 		if (!$present){ 
			$cs = $currentSM->getCognitiveState();
 			
 			$cs[] = $ak;
 			$currentSM->setCognitiveState($cs);
 			
		}
 		// si aggiunge il nodo all'elenco dei nodi visitati
 		$currentSM->addVisitedNodes($studiedLN);
 		// si memorizza il nuovo modello studente sul db
 		$cs = $currentSM->getCognitiveState();
 		$cognitivestate = "";
 		$level = "";
 		$k = "";
 		$l = "";
 		
 		
 		for($i = 0; $i<count($cs); $i++){
  			$ki =$cs[$i]; //KnowledgeItem 
  			$k = $ki->getId();
  			$cognitivestate = $cognitivestate.$k.",";
  			$l = $ki->getLevel();
  			$level = $level.$l.",";
  		
  			
  			
  		 }
  		 
  		$cognitivestate = substr($cognitivestate,0,strlen($cognitivestate)-1);
  		$level = substr($level,0,strlen($level)-1);
  		
  		$visitati = $currentSM->getVisitedNodes();
  		$visited = "";
  	
  		for($i =0; $i<count($visitati); $i++){
  			$ln = $visitati[$i]; //LearningNode 
  		    $k = $ln->getId();
  			$visited = $visited.$k.",";
  		 }
  		 $visited = substr($visited,0, strlen($visited)-1);
  		 
  		 
  	//	 System.out.println("cognitive state aggiornato " + cognitivestate);
  	//	 System.out.println("livello dei ki del cognitive state " + level);
  	//	 System.out.println("nodi visitati aggiornati " + visited);
  		 //System.out.println("currentSM.getId() " + currentSM.getId());
  		
  		 //aggiorna il modello studente sul db
  		 if($percentuale!=0)
  		 GestoreDB::updateStudentModelKiAcquired($cognitivestate, $level, $visited, $currentSM->getId(),$percentuale);
  		 //aggiorna la los dello studente non consigliando piu' il nodo acquisito
  		 $elementoDaModificare = $los->indexOfLN($studiedLN->getId()); //int oppure false
  		// System.out.println("elemento da modificare nella los (acquisito) = "+ elementoDaModificare);
  		 if($elementoDaModificare!=-2){
			$appLos = $los->getLearningObjectsSequence();
			
  		 	$aux = $appLos[$elementoDaModificare]; //LearningNode 
  		 	
  		 	$aux->setRecommended("false");
  		 }
  		 	//aggiorna la los dello studente non consigliando piu' il nodo equivalente a quello acquisito, presente nella los
  		 	//è il caso in cui lo studente studia un nodo non consigliato, alternativo ad uno presente nella los consigliata
  		 	// la los consigliata va modificata in modo che il modo alternativo che spiega lo stesso concetto acquisito con 
  		 	// l'altro nodo, non sia più raccomandato
  		 	$alternativi = GestoreDB::getAlternativeNodes($studiedLN);
  		 	for($j =0; $j<count($alternativi); $j++){
  		 		$aux2 = $alternativi[$j]; //String 
  		 		$elementoDaModificare2 = $los->indexOfLN($aux2);
  		 	//	System.out.println("aux2 " + aux2);
  		 	//	System.out.println("elementoDaModificare2 " + elementoDaModificare2);
  		 		if($elementoDaModificare2!=false){
					$appLos3 = $los->getLearningObjectsSequence();
  		 			$aux3 = $appLos3[$elementoDaModificare2]; //LearningNode 
  		 			$aux3->setRecommended("false");
  		 			//System.out.println("aux3.setRecommended " + aux3.getRecommended());
  		 	}
  		 	}  		 	
  		 	
  		 $loscompleta = "";
         $recommOnCompleta = "";	
         $recomm = "";		
         $appLos = $los->getLearningObjectsSequence();
  		 for($i = 0; $i <count($appLos); $i++ ){
     		$node = $appLos[$i]; //LearningNode 
     		//loscompleta = loscompleta + node.getId() + ",";
     		if ($node->getRecommended() == "true"){
				$recommOnCompleta = $recommOnCompleta."true,";
     			$recomm = $recomm.$node->getId().",";
			}
			else
				$recommOnCompleta = $recommOnCompleta."false,";
  		}	
  		 //loscompleta = loscompleta.substring(0, loscompleta.length()-1);
  		 $recommOnCompleta = substr($recommOnCompleta,0,strlen($recommOnCompleta)-1);
  		 if ($recomm != "")
  		 	$recomm = substr($recomm,0,strlen($recomm)-1);
  		 else{
  		 	$acquisito=-1;
  		 	$recomm="-";
  		 }
  		 	
  		//aggiorna la los completa
  		GestoreDB::updateLOS($currentSM->getIdstudente(),$loscompleta,$recommOnCompleta,0,$los->getCorso()); 
  		//aggiorna la los suggerita
  		GestoreDB::updateLOS($currentSM->getIdstudente(),$recomm,"",1,$los->getCorso());
  			
  	//	System.out.println("los personalizzata aggiornata " + recomm);
  		//acquisito è inizializzato a zero, se è diverso da zero ho rilevato la fine del corso		
  		if($acquisito==0)
  		 	$acquisito = 1;
 		}
 		
 		// aggiorna i ls se ci sono post test sul nodo
 		if ($studiedLN->getExistsPosttest()){
 	
 		$ls = $currentSM->getLearningStyles();
	 	$lsOldSign =array();
	 	$lsOldSign[0] = AdaptationEngine::signum($ls[0]);
	 	$lsOldSign[1] = AdaptationEngine::signum($ls[1]);
	    $lsOldSign[2] = AdaptationEngine::signum($ls[2]);
	 	$lsOldSign[3] = AdaptationEngine::signum($ls[3]);
	 	$Smin = $studiedLN->getMinimumPossibleScore();//double
	 	$Smax = $studiedLN->getMaximumPossibleScore();//double
	 	$Tmin = $studiedLN->getMinimumTime();//double
	 	$Tmax = $studiedLN->getMaximumTime();//double
	 	$learningStylesNode = $studiedLN->getLearningStyles();//array di double
	 	$Sobtained = 0;//double
	 	$etaAcquisito = 0;//double
	 	$etaNonAcquisito = 0;//double
	 	$Tfruition = $studiedLN->getFruitionTime();//double
	 	if ($Tfruition < $Tmin)
	 		$Tfruition = $Tmin;
	 	else
	 		if($Tfruition > $Tmax)
	 			$Tfruition = $Tmax;
	 //	System.out.println("tf = "+ Tfruition);
	 	if($studiedLN->getExistsPosttest()){
	 		$Sobtained = $studiedLN->getObtainedScore();
	 		$etaAcquisito = ((($Sobtained - $Smin)/($Smax-$Smin))+1-(($Tfruition-$Tmin)/($Tmax -$Tmin)))/2;
	 		$etaNonAcquisito = (1-(($Sobtained - $Smin)/($Smax-$Smin))+(($Tfruition-$Tmin)/($Tmax -$Tmin)))/2;
	 	} 	
 		
 		//se il ki è acquisito o è acquisito e porta alla fine del corso
 		if($acquisito==1 || $acquisito ==-1){
 			for($i = 0; $i<4; $i++){
 				$ls[$i] = $ls[$i]+($etaAcquisito * AdaptationEngine::signum($learningStylesNode[$i] - $ls[$i]));
 				if($ls[$i]<-11.0)
 					$ls[$i]=-11.0;
 				if($ls[$i]>11.0)
 					$ls[$i]=11.0;
 			}
 						
 		}
 		else {
 			for($i = 0; $i<4; $i++){
 				$ls[$i] = $ls[$i] - ($etaNonAcquisito * AdaptationEngine::signum($learningStylesNode[$i] - $ls[$i])); 	
 				if($ls[$i]<-11.0)
 					$ls[$i]=-11.0;
 				if($ls[$i]>11.0)
 					$ls[$i]=11.0;	
 			}
 		}
	 	
	 	$currentSM->setLearningStyles($ls);
	 	
	 	//nell'attributo changedDimension del modello studente viene memorizzato un intero che individua 
	 	//l'eventuale dimensione che ha cambiato segno
	 	if (AdaptationEngine::signum($ls[0])!=$lsOldSign[0])
	 		$currentSM->setChangedDimension(0);
	 	if (AdaptationEngine::signum($ls[1])!=$lsOldSign[1])
	 		$currentSM->setChangedDimension(1);
	 	if (AdaptationEngine::signum($ls[2])!=$lsOldSign[2])
	 		$currentSM->setChangedDimension(2);
	 	if (AdaptationEngine::signum($ls[3])!=$lsOldSign[3])
	 		$currentSM->setChangedDimension(3);	
	 	
	 	 //aggiorna il modello studente sul db
	 	GestoreDB::updateStudentModelLS($ls[0],$ls[1],$ls[2],$ls[3],$currentSM->getId());
	 //	System.out.println("ls dello studente aggiornati :" + ls[0] + " "+ ls[1]+ " "+ls[2]+ " "+ls[3]);
 	
 //	System.out.println("acquisito = "+acquisito);
		//print_r($currentSM);
	}
 	return $acquisito;
	
}

/** 
 * aggiorna la Learning Objects Sequence dello studente
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param StudentModel $currentSM il modello dello studente corrente
 * @param LearningNode $studiedLN il Learning Node studiato
 * @param LearningObjectsSequence $currentLOS la LOS associata allo studente
 * @param string $corso il corso
 * 
 * @return string messaggio di interazione tra Lsplan e lo studente
 * 
 * 
**/
			//StudentModel currentSM, LearningNode studiedLN, LearningObjectsSequence currentLOS, String corso
 public static function updateLearningObjectsSequence($currentSM,$studiedLN,$currentLOS,$corso){//String
	$stampe = false;
  	 $azione = "";
  	 if($stampe)
  	print_r("<br>update<br>");
  	// primo controllo: se nel modello studente esiste una dimensione di FS che ha cambiato segno è necessario ripianificare la LOS
  	if ($currentSM->getChangedDimension()!=-1){
		
  	//	System.out.println("replan");
  	if($stampe)
  	print_r("replan<br>");
  		$azione = Constants::$replan;
  		//se lo studente è passato da sequenziale a globale o viceversa deve ripianificare
  		if ($currentSM->getChangedDimension()==3){
  			//System.out.println("currentSM.getcs in replan : "+ currentSM.getCognitiveState());
  			$newLOS = AdaptationEngine::createFirstLearningObjectsSequence($currentSM,$corso, 2); //LearningObjectsSequence 
  			//return newLOS;
  			return $azione;
  		}
  		else{
  			//vanno solo modificati i ln raccomandati in base ai ls
  		if($stampe)
  		print_r("ripianifica solo post processamento<br>");
  			$losComplete = GestoreDB::getLOS($currentSM->getIdstudente(),0,$corso); //String 
  		   	$losRecomm = GestoreDB::getLOS($currentSM->getIdstudente(),1,$corso); //String 
  			
  		//	System.out.println("losComplete= "+losComplete);
  		//	System.out.println("losRecomm= "+losRecomm);
  			
  			$recommOnCompleta = "";
  	
  			//vettore rappresentativo della sequenza completa
  			$lns = array();
  			//vettore rappresentativo della sequenza raccomandata
  			$lnsrecom = array();
  	
  			$losCompleteArray = preg_split("/[,;]/",$losComplete);//String[] 
  			$losRecommArray = explode(",",$losRecomm);//String[] 
  			$losRecommVector = array();
  			//creo la sequenza raccomandata in base ai ls dello studente, ovvero modifico la sequenza precedente in modo da tenere conto dei nuovi ls 
  			// se ci sono nodi alternativi inserisco il più adeguato allo studente
  			$losRecomm = "";
  			for($k = 0; $k < count($losRecommArray); $k++){
  				//System.out.println("losRecommArray[k]= "+losRecommArray[k]);
  				$lnr = GestoreDB::createLN($losRecommArray[$k],$corso); //LearningNode 
  				$closest = AdaptationEngine::checkClosestNode($currentSM,$lnr,1); //LearningNode 
  				$closest->setRecommended("true");
  				$lnsrecom[]=$closest;
  		  		$losRecomm = $losRecomm.$closest->getId().",";
  			}
  	
  	//		losComplete="";
			
  			for($z = 0; $z < count($losCompleteArray); $z++){
  				//segno come raccomandato l'id se
  				//1. è contenuto nella losraccomandata
  				//2. non è una sottostringa di un'altro id raccomandato
  				//es. per id1 in id2,id3,id10 la condizione deve restituire false
  				//quindi intanto id1 deve essere contenuto in losraccomandata losRecomm.indexOf(losCompleteArray[z])!=-1
  				//e poi il carattere alla posizione
  				// losRecomm.indexOf(losCompleteArray[z]) + la lunghezza dell'id deve essere una , 
  				// oppure la stringa losrecomm è finita (l'id cercato è l'ultimo dei consigliati
  				$pos = strpos($losRecomm,$losCompleteArray[$z]); //int 
  				$lunghezzaid = strlen($losCompleteArray[$z]);
  				if(!($pos===FALSE)&&(($losRecomm[$pos+$lunghezzaid]==',')||($pos + $lunghezzaid == strlen($losRecomm))))
  				//	if(losRecomm.indexOf(losCompleteArray[z])!=-1)
  					$recommOnCompleta = $recommOnCompleta."true,";
  				else
  					$recommOnCompleta = $recommOnCompleta."false,";
  			}
  	
		  	//creo la los completa, aggiungendo i ln alternativi
		    //la los salvata su db sarà del tipo: id3,id10;id14,id6;id15...
		    //dove ; tra due id vuol dire che essi sono alternativi
		    // la , detta la sequenza

		  	
		  	
		  	$recommOnCompleta = substr($recommOnCompleta,0,strlen($recommOnCompleta)-1);
		  //	losComplete = losComplete.substring(0,losComplete.length()-1);
		  	$losRecomm = substr($losRecomm,0,strlen($losRecomm)-1);
		  	
		//  	 System.out.println("losComplete = "+losComplete);
		//    System.out.println("recommOnCompleta = "+recommOnCompleta);
		//     System.out.println("losRecomm = "+losRecomm);
		     
		  	$losCompleta = new LearningObjectsSequence($lns,$currentSM->getIdstudente(),$corso);  //LearningObjectsSequence 
  				GestoreDB::updateLOS($currentSM->getIdstudente(), $losComplete, $recommOnCompleta, 0, $corso); 		
  		  	//per usi futuri
  			$losRecommended = new LearningObjectsSequence($lnsrecom,$currentSM->getIdstudente(),$corso); //LearningObjectsSequence 
  			GestoreDB::updateLOS($currentSM->getIdstudente(), $losRecomm,"", 1,$corso);
  			
  		//	System.out.println("los personalizzata aggiornata "+losRecomm);
  		
  			//return losCompleta;
  			return $azione;	  			
  		}
  	}
  	else //secondo controllo: se il tempo di studio non è ragionevole o lo studente ha visitato il nodo una sola volta gli si ripropone
  		//lo stesso nodo: la los non viene modificata
  		if(($studiedLN->getFruitionTime() < $studiedLN->getMinimumTime()) || ($studiedLN->getFruitionTime() > $studiedLN->getMaximumTime()) || ($currentSM->isVisitedNode($studiedLN->getId()) == false))
  			{ 
  				$azione = Constants::$riprova;
  			if($stampe)
  			print_r("ripropongo la stessa los perche' ln studiato in tempo non ragionevole o visto solo una volta<br>");
  				$currentSM->addVisitedNodes($studiedLN);
  				$visited = "";
  				for($i = 0; $i<count($currentSM->getVisitedNodes()); $i++){
					$vn = $currentSM->getVisitedNodes();
  					$k = $vn[$i]; //LearningNode 
  					$visited = $visited.$k->getId().",";
  				}
  				$visited = substr($visited,0, strlen($visited)-1);
  				GestoreDB::updateStudentModelIdRivisitato($visited,$currentSM->getId());
  		//		System.out.println("aggiorno il modello studente per tracciare comunque la visita di questo nodo; nodi visitati: "+visited);
  				//return currentLOS;
  				return $azione;
  			}
  	// terzo controllo: verifico se esiste un LN equivalente a quello studiato e non visitato e lo propongo 
  	else{
  		$azione= Constants::$rispiega;
  	if($stampe) print_r("cerco nodo alternativo <br>");
  		
  		$vicino = AdaptationEngine::checkClosestNode($currentSM, $studiedLN,2);

  		if($vicino!=null){  			  			
  			//sostituisci nella los il ln appena visitato con quello ritornato dalla checkClosestNode  			
     	//	System.out.println("vicino =  " + vicino.getId());
     		$elementoDaTogliere = $currentLOS->indexOfLN($studiedLN->getId()); //int 
     	//	System.out.println("elementoDaTogliere =  " + elementoDaTogliere);
     		$elementoDaSuggerire = $currentLOS->indexOfLN($vicino->getId());
     	//	System.out.println("elementoDaSuggerire =  " + elementoDaSuggerire);
     		$recommendedLOS = array();
     		//modifica la los originaria mettendo a "non raccomandato" il nodo da togliere
     		// a "raccomandato" il nuovo nodo proposto
     		//costruisce anche la sequenza coi soli nodi raccomandati
     		//nonchè le stringhe rappresentative delle sequenze sul db
     		$loscompleta = "";
     		$losraccomandata = "";
     		$recommOnCompleta = "";
     		for($i = 0; $i <count($currentLOS->getLearningObjectsSequence()); $i++ ){
				$appLos=$currentLOS->getLearningObjectsSequence();
     			$node = $appLos[$i]; //LearningNode 
     			if ($i == $elementoDaTogliere)
     					$node->setRecommended("false");
     			else if ($i == $elementoDaSuggerire)
     					$node->setRecommended("true");
     			//loscompleta = loscompleta + node.getId() + ",";
     			if ($node->getRecommended()=="true"){
					$recommOnCompleta = $recommOnCompleta."true,";
     			//System.out.println("node.getRecommended()" + node.getRecommended());
     				$recommendedLOS[]=$node;
     				$losraccomandata = $losraccomandata.$node->getId().",";
				}
				else
					$recommOnCompleta = $recommOnCompleta."false,";
     			
     				
     		}
     		//loscompleta = loscompleta.substring(0, loscompleta.length()-1);
  		 	$recommOnCompleta = substr($recommOnCompleta,0,strlen($recommOnCompleta)-1);
  		 	$losraccomandata = substr($losraccomandata,0,strlen($losraccomandata)-1);	
     	    $losRecommended = new LearningObjectsSequence($recommendedLOS,$currentSM->getIdstudente(),$corso); //LearningObjectsSequence 
     		
     		GestoreDB::updateLOS($currentSM->getIdstudente(), $loscompleta,$recommOnCompleta, 0, $corso); 		
  			GestoreDB::updateLOS($currentSM->getIdstudente(), $losraccomandata,"", 1, $corso);
  			
  		//	System.out.println("los personalizzata aggiornata "+losraccomandata);
  			
     		//return currentLOS;
     		return $azione;	
  		}
  		// quarto controllo: verifico se ci sono prerequisiti del nodo attuale e li inserisco come recommended
  		// nella LOS completa e in testa alla LOS raccomandata
  		else{
  			$azione = Constants::$prerequisiti;
  		if($stampe) print_r("verifico i predecessori<br>");
  			
  			$predecessors = AdaptationEngine::orderedPredecessorsList($studiedLN, $currentSM, $corso); //Vector 

  			$losRecomm = "";
  			if($predecessors!=null){ //c'è almeno un nodo prerequisito
  				for($j = 0; $j<count($predecessors); $j++){
  					//modifica la LOS completa inserendo i prerequisiti come nodi raccomandati
  					$p = $predecessors[$j]; //LearningNode 
  					
  				//	System.out.println("predecessori trovati : " + p.getId());
  					
  					/*$elementoDaTogliere = $currentLOS->indexOfLN($p->getId()); //int
  					
  					
  					$app = AdaptationEngine::my_array_delete($currentLOS->getLearningObjectsSequence(),$elementoDaTogliere);
  					$currentLOS->setLearningObjectsSequence($app);
  					array_splice($currentLOS->getLearningObjectsSequence(),$elementoDaTogliere,0,$p);
  					*/
  					$appLOS =$currentLOS->getLearningObjectsSequence();
  					$posInLos=$currentLOS->indexOfLN($p->getId());
  					$p->setRecommended("true");
  					$appLOS[$posInLos]=$p;
  					$currentLOS->setLearningObjectsSequence($appLOS);
  					//$currentLOS->getLearningObjectsSequence().insertElementAt(p,elementoDaTogliere);
  					//costruisce la stringa degli id dei prerequisiti ordinati, che andra' inserita
  					//alla testa della stringa rappresentativa dell'attuale sequenza raccomandata
  					$losRecomm = $losRecomm.$p->getId().",";
  					$aks = $p->getAcquiredKnowledge();
  					$akp = $aks[0];//KnowledgeItem 
  					$cs = $currentSM->getCognitiveState(); //Vector
  					for($m = 0; $m < count($cs); $m++){  					
  						if ($akp->confronta($cs[$m])){
  							$cs =AdaptationEngine::my_array_delete($cs,$m);
  						}  						
  					}
  					$currentSM->setCognitiveState($cs);
  					
  				} 
  				$loscompleta = "";
                $recommOnCompleta = "";			
  				for($i = 0; $i <count($currentLOS->getLearningObjectsSequence()); $i++ ){
     				$appLos=$currentLOS->getLearningObjectsSequence();
     				$node = $appLos[$i]; //LearningNode 
     				//loscompleta = loscompleta + node.getId() + ",";
     				if($node->getRecommended()=="true")
						$recommOnCompleta = $recommOnCompleta."true,";
					else
						$recommOnCompleta = $recommOnCompleta."false,";
  				}	
  					
  				//loscompleta = loscompleta.substring(0, loscompleta.length()-1);
  				$recommOnCompleta = substr($recommOnCompleta,0,strlen($recommOnCompleta)-1);
  				//aggiorna la los completa
  				GestoreDB::updateLOS($currentSM->getIdstudente(),$loscompleta,$recommOnCompleta, 0, $corso); 
  					
  				//aggiorna l'elenco dei nodi raccomandati inserendo in testa alla sequenza i prerequisiti nell'ordine richiesto
  				$currentLOSrecommended = GestoreDB::getLOS($currentSM->getIdstudente(),1, $corso); //String 
  			//	System.out.println("currentLOSrecommended " + currentLOSrecommended);
  				GestoreDB::updateLOS($currentSM->getIdstudente(),$losRecomm.$currentLOSrecommended,"", 1, $corso); 
  					
  			//	System.out.println("los personalizzata aggiornata "+losRecomm+currentLOSrecommended);
  					
  				//aggiorna il modello studente (eventuale perdita di conoscenza)
  				$cognitivestate = "";
  				$lev = "";
  				for($k = 0; $k < count($currentSM->getCognitiveState()); $k++){
  					 $appCS = $currentSM->getCognitiveState();
  					 $kinoto = $appCS[$k]; //KnowledgeItem 
  					 $cognitivestate = $cognitivestate.$kinoto->getId().",";
  					 $lev = $lev.$kinoto->getLevel().",";
  					}
  				if($cognitivestate != ""){
  				$cognitivestate = substr($cognitivestate,0,strlen($cognitivestate)-1);
  				$lev = substr($lev,0, strlen($lev)-1);
  					}
  				GestoreDB::updateStudentModelKiLost($cognitivestate,$lev,$currentSM->getId());
  				
  		//		System.out.println("suppongo perdita di conoscenza, cognitive state aggiornato: "+cognitivestate);
  				//return currentLOS;
  				return $azione;
  			}
  			else
  				// ripianifica l'intera sequenza
  				//TODO forse sarebbe più corretto "contatta il docente"
  				$azione = Constants::$nulladafare;
  		if($stampe) print_r("ripianifica -  contatta il docente<br>");
  				//return createFirstLearningObjectsSequence(currentSM, corso, 2);
  				return $azione;
  		}
  	}
  		
//  	return currentLOS;
  }

/** 
 * verifica se esiste un learning node equivalente a quello studiato, cioè cerca i learning node con = ak e = rk del nodo studiato e verifica in ordine di vicinanza dei ls dei learning node possibili ai ls dello studente se ne esiste uno non visitato. 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param StudentModel $currentSM il modello dello studente corrente
 * @param LearningNode $studiedLN il Learning Node studiato
 * @param integer $firstTime  firstTime testimonia se la funzione è chiamata: 1 - per proporre la prima sequenza allo studente (postprocessing dell'uscita di pdk per prendere i ln con ls migliori), 2 - per proporre il nodo alternativo
 * 
 * @return LearningNode il Learning Node piu' vicino
 * 
 * 
**/

	/*verifica se esiste un learning node equivalente a quello studiato, cioè cerca i learning node con = ak e = rk del nodo studiato
	 * e verifica in ordine di vicinanza dei ls dei learning node possibili ai ls dello studente se ne esiste uno non visitato. 
 	 *	1. recupera dal db i ln equivalenti a quello studiato (= rk ed =ak)
 	 *	2. individua il più vicino ai ls dello studente 
 	 *	3. partendo dal più vicino verifica se ne esiste uno che non sia già stato visitato
 	 *	se esiste restituirlo, altrimenti tornare null 
 	 */
 	
				//StudentModel currentSM, LearningNode currentLN, int firstTime
 public static function checkClosestNode($currentSM,$currentLN,$firstTime) { //LearningNode 
 	
 	/* firstTime testimonia se la funzione è chiamata:
 	 * 1 - per proporre la prima sequenza allo studente (postprocessing dell'uscita di pdk per prendere i ln con ls migliori)
 	 * 2 - per proporre il nodo alternativo
 	*/  		

 	$idLnVicini = array();
 	 $idLnVicini = GestoreDB::getAlternativeNodes($currentLN); //Vector 
 	 //System.out.println("idLnVicini.size() tornati da db "+ idLnVicini.size());
  	 $lnVicini = array(); //Vector 
  	 if($firstTime ==1){
  	 //	lnVicini.add(currentLN);
  	 	$idLnVicini[]=$currentLN->getId();
  	 }
 	 	
 	 if (count($idLnVicini)>0){
 	 	for($i=0; $i<count($idLnVicini); $i++ ){
 	 		//System.out.println("alternativo "+ (String)idLnVicini.get(i));
 	 		$alt = GestoreDB::createLN(trim($idLnVicini[$i]), $currentLN->getCorso()); //LearningNode 
 	 		$lnVicini[]=$alt;
 	 	}
 	 	
 	 
 	 	$learningStylesSM = $currentSM->getLearningStyles();
 	 	while (count($lnVicini)!=0){  
			
		    	$vicino = AdaptationEngine::nearestLearningNode($lnVicini,$learningStylesSM); //LearningNode 
		    
		    //	System.out.println("piu' vicino " + vicino.getId());
		    //if ((!currentSM.isVisitedNode(vicino.getId()))||(firstTime ==1)){
		    	if ((!$currentSM->isVisitedNode($vicino->getId())) || ($firstTime ==1)){
			    	//if (!currentSM.isVisitedNode(vicino.getId())){
			    //	System.out.println("ho trovato il nodo piu' vicino proponibile");
		     		return $vicino;
     			}
	     		else{
	    			
	     			$lnVicini=AdaptationEngine::ln_array_delete($lnVicini,$vicino);

	     		}	
     	}	
 	 }
 	 return null;
  }

/** 
 * Ritorna il Learning Node con Learning Styles piu' vicini a quelli dello Student Model
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param array $lnVicini l'insieme dei LN
 * @param array $learningStylesSM i LS dello Student Model
 * 
 * @return LearningNode il Learning Node piu' vicino
 * 
 * 
**/

			//Vector lnVicini, double[] learningStylesSM
  private static function nearestLearningNode($lnVicini,$learningStylesSM){ //LearningNode
  	$nearestLN = $lnVicini[0]; //LearningNode 
  	$learningStyles = $nearestLN->getLearningStyles(); 
    $distanzaMinima = sqrt(pow($learningStyles[0]-$learningStylesSM[0],2)+
     							    pow($learningStyles[1]-$learningStylesSM[1],2)+
     							    pow($learningStyles[2]-$learningStylesSM[2],2)+
     							    pow($learningStyles[3]-$learningStylesSM[3],2)); //double 
    
     for($i = 1; $i<count($lnVicini); $i++ ){
     	$l = $lnVicini[$i]; //LearningNode 
     	$learningStyles = $l->getLearningStyles(); 
     	$distanza = sqrt(pow($learningStyles[0]-$learningStylesSM[0],2)+
     							    pow($learningStyles[1]-$learningStylesSM[1],2)+
									pow($learningStyles[2]-$learningStylesSM[2],2)+
     							    pow($learningStyles[3]-$learningStylesSM[3],2));
     	if($distanza < $distanzaMinima){
     		$distanzaMinima = $distanza;
     		$nearestLN = $l;
     	}
     }
     return $nearestLN;
  	
  }
  
 /** 
 * recupera dal db i ln prerequisito di quello studiato (ak = rk del nodo studiato)
 * ordina i ln secondo la seguente priorità:
 *		- prima i nodi non visitati dallo studente
 *		- poi i nodi visitati dallo studente che non hanno test (in ordine di livello)
 *		- infine i nodi visitati dallo studente, che hanno test, disposti in base alla vicinanza ai ls dello studente
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param LearningNode $currentLN il LN corrente
 * @param StudentModel $currentSM lo Student Model corrente
 * @param string $corso il corso
 * 
 * @return array il vettore ordinato
 * 
 * 
**/ 
  	/*
 	 *	1. recupera dal db i ln prerequisito di quello studiato (ak = rk del nodo studiato)
 	 *  TODO NOTA va considerato anche l'approccio?
 	 *  TODO NOTA non abbiamo messo ordine di preferenza tra nodi non visitati
 	 *	2. ordinarli secondo la seguente priorità:
 	 *		- prima i nodi non visitati dallo studente
 	 *		- poi i nodi visitati dallo studente che non hanno test (in ordine di livello)
 	 *		- infine i nodi visitati dallo studente, che hanno test, disposti in base alla vicinanza ai ls dello studente
 	 *	3. ritornare il vettore ordinato
 	 */
 	
			//LearningNode currentLN, StudentModel currentSM, String corso
 public static function orderedPredecessorsList($currentLN,$currentSM,$corso) { //Vector
 	
 	 
 	 $rk = $currentLN->getRequiredKnowledge(); //Vector 
 	  
 	//vettore degli id dei nodi prerequisito
 	 $idprerequisiti = GestoreDB::getPrerequisites($rk,$corso);
     $prerequisiti = array();
     
     if(count($idprerequisiti) > 0){
     	//System.out.println("prerequisiti ");
     	for ($i = 0; $i < count($idprerequisiti); $i++){
	     	//System.out.println(" " + idprerequisiti.get(i));
	     	$l = GestoreDB::createLN(trim($idprerequisiti[$i]),$corso);//LearningNode 
	     	$alternativoPiuVicino = AdaptationEngine::checkClosestNode($currentSM,$l,1); //LearningNode 
	     	if($alternativoPiuVicino != null){
	     		$presente = false;
	     		
	     		for($k = 0; $k<count($prerequisiti); $k++){
	     			$pr = $prerequisiti[$k]; //LearningNode 
	     			if($alternativoPiuVicino->getId() == $pr->getId())
	     				$presente = true;
	     		}	     			
	     		if(!$presente)
	     			$prerequisiti[]=$alternativoPiuVicino;
	     	}
	     	else
	     		$prerequisiti[]=$l;
     }      
         
     
     //NOTA non abbiamo messo ordine di preferenza tra nodi non visitati
     $notVisited = array();
     $visitedNotTest = array();
     $visitedTest = array();
     
     //divido i ln prerequisiti in tre gruppi: mai visitati, visitati senza posttest, visitati con posttest
     for ($i = 0; $i < count($prerequisiti); $i++){
     	$ln = $prerequisiti[$i]; //LearningNode 
     	$ln->setRecommended("true");
     	if (!$currentSM->isVisitedNode($ln->getId()))
     		$notVisited[]=$ln;
     	else
     		if (!$ln->getExistsPosttest())
     			$visitedNotTest[]=$ln;
     		else 
     			$visitedTest[]=$ln;
     }
     

     
     
     //ordino il secondo vettore (NOTA: non abbiamo definito ordine di preferenza per il primo)
     $klevel = array();
     $alevel = array();
     $elevel = array();
     for ($i = 0; $i < count($visitedNotTest); $i++){
     	$ln = $visitedNotTest[$i]; //LearningNode 
     	$aks= $ln->getAcquiredKnowledge();
     	$ki = $aks[0]; //KnowledgeItem 
     	if ($ki->getLevel() == "K")
     		$klevel[]=$ln;
     	else
     		if ($ki->getLevel()=="A")
     			$alevel[]=$ln;
     		else 
     			$elevel[]=$ln;
     }
     
     // unisco i vettori notVisited, klevel, alevel, elevel
     $notVisited = array_merge($notVisited,$klevel);
     $notVisited = array_merge($notVisited,$alevel);
     $notVisited = array_merge($notVisited,$elevel);
     $learningStylesSM = $currentSM->getLearningStyles();
     while (count($visitedTest)!=0){ 
       
     	$vicino = AdaptationEngine::nearestLearningNode($visitedTest,$learningStylesSM); //LearningNode 

     	$notVisited[] = $vicino;
     	$visitedTest = AdaptationEngine::ln_array_delete($visitedTest,$vicino);
     }
     return $notVisited;
     }
     else 	return null;
  }
  
 /** 
 * Ritorna lo Student Model di uno studente 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param long $idstudente l'id dello studente
 * @param string $corso il corso
 * 
 * @return StudentModel lo Student Model richiesto
 * 
 * 
**/ 
		//long id, string corso
  public static function getStudentModel($idstudente,$corso){ //StudentModel
  	   // System.out.println("id dello studente cercato "+id);
  		$ht = GestoreDB::getStudentModel($idstudente,$corso); //Hashtable 
  		$sm = new StudentModel();
  		$sm->setId($ht["id"]);
  		$sm->setIdstudente($ht["idstudente"]);
  		$sm->setNome($ht["nome"]);
  		$sm->setCognome($ht["cognome"]);
  		$sm->setLearningStyles($ht["ls"]);
  		/*NOTA1: Implementazione come vettore di ki posseduti 
  		valutare se creare array di tutti i ki segnalando solo i posseduti
  		e fare quindi passare a questo metodo anche i ki non posseduti	*/
  		$cs = array();
  	//	System.out.println("cognitive state da db "+ (String)ht.get("cognitivestate"));
  		if ($ht["cognitivestate"] != null && $ht["cognitivestate"] != ""){
	  		$currentCS = explode(",",$ht["cognitivestate"]); //String[] 
	  		$levels = explode(",",$ht["level"]); //String[]	 		
	  		for($i = 0; $i<count($currentCS); $i++){
	  			$ki = new KnowledgeItem();
	  		//	System.out.println("currentCS[i] -"+currentCS[i]+"-");
	  			$k = $currentCS[$i];
	  			$ki->setId($k);
	  			$l = $levels[$i];
	  			$ki->setLevel($l);
	  			$ki->setPosseduto(true);
	  			$cs[]=$ki;
	  		}
  		}
  		$sm->setCognitiveState($cs);
  		$visited = array();
  		$visitati = $ht["visitednodes"]; //String 
  		if ($visitati != null && $visitati != ""){    
  		//	System.out.println("visitati da db "+ (String)ht.get("visitednodes"));
    		$visitedNodes = explode(",",$visitati);    	
	    	for($i = 0; $i<count($visitedNodes); $i++){
	  			$ln = GestoreDB::createLN(trim($visitedNodes[$i]),$corso);
	  			$sm->addVisitedNodes($ln);
	  		}
  		}
  		
  		$goal = array();
  	//	System.out.println("cognitive state da db "+ (String)ht.get("cognitivestate"));
  		if ($ht["goal"] != null && $ht["goal"] != ""){
  		//	System.out.println("goal state da db "+ (String)ht.get("goal"));
	  		$goalSM = explode(",",$ht["goal"]); //String[] 
	  		$levelsGoal = explode(",",$ht["goalLev"]); 	 		
	  		for($i = 0; $i<count($goalSM); $i++){
	  			$ki = new KnowledgeItem();
	  		//	System.out.println("currentCS[i] -"+currentCS[i]+"-");
	  			$k = $goalSM[$i];
	  			$ki->setId($k);
	  			$l = $levelsGoal[$i];
	  			$ki->setLevel($l);
	  		//	ki.setPosseduto(true);
	  			$goal[]=$ki;
	  		}
  		}
  		$sm->setGoal($goal);
  		$sm->setCorso($ht["corso"]);	
  		return $sm;
  	}
  	
/** 
 * Ritorna la Learning Objects Sequence completa con gli ultimi valori di recommended per i suoi Learning Node 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param long $idstudente l'id dello studente
 * @param int $complete 0 -> los completa, 1 -> los raccomandata
 * @param string $corso il corso
 * 
 * @return LearningObjectsSequence la Learning Objects Sequence richiesta
 * 
 * 
**/
  	
			//long idstudente, int complete, String corso
	public static function getLOS($idstudente, $complete, $corso){ //LearningObjectsSequence
		$los = GestoreDB::getLOS($idstudente, $complete,$corso);
		$rec = GestoreDB::getRec($idstudente, $complete,$corso);
		$losComplete = preg_split("/[,;]/",$los); 
		$recComplete = explode(",",$rec);
		$losrecup = array();
	//	System.out.println("los da db +"+los+"+");
	//	System.out.println("rec da db +"+rec+"+");

    	for($i = 0; $i<count($losComplete); $i++){
  			$ln = GestoreDB::createLN(trim($losComplete[$i]),$corso); //LearningNode
  			$ln->setRecommended($recComplete[$i]);
  		    $losrecup[]=$ln;
  		}	
		$learningObjectsSequence = new LearningObjectsSequence($losrecup,$idstudente,$corso);
		//$learningObjectsSequence->setCorso($corso);
		return $learningObjectsSequence;
	}
	
/** 
 * Ritorna la Learning Objects Sequence completa 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param long $idstudente l'id dello studente
 * @param int $complete 0 -> los completa, 1 -> los raccomandata
 * @param string $corso il corso
 * 
 * @return LearningObjectsSequence la Learning Objects Sequence richiesta
 * 
 * 
**/
	
			//long idstudente, int complete, String corso
	public static function getLOScompleta($idstudente,$complete,$corso){ //String
		return GestoreDB::getLOS($idstudente, $complete,$corso);
	}


/** 
 * funzione di appoggio php che calcola il segno
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param double $num il numero da esaminare
 * 
 * @return integer 1 -> positivo, -1 -> negativo, 0 -> num = 0
 * 
 * 
**/

//funzione di appoggio php che calcola il segno
function signum ($num) {
	if ($num > 0) return 1;
	if ($num < 0) return -1;
	return 0;
}


/** 
 * Elimina un LN da un array 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param array $array l'array da cui eliminare il LN
 * @param LearningNode $item il LN da eliminare
 * 
 * @return array
 * 
 * 
**/

public static function ln_array_delete($array, $item) {
	$nuovoArray = array();
	for($i = 0; $i < count($array); $i++){
		if(!$item->equals($array[$i]))
			$nuovoArray[] = $array[$i];
	}
	return $nuovoArray;
}

/** 
 * Elimina un KI da un array 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param array $array l'array da cui eliminare il KI
 * @param KnowledgeItem $item il KI da eliminare
 * 
 * @return array
 * 
 * 
**/

public static function ki_array_delete($array, $item) {
	$nuovoArray = array();
	for($i = 0; $i < count($array); $i++){
		if(!$item->confronta($array[$i]))
			$nuovoArray[] = $array[$i];
	}
	return $nuovoArray;
}

/** 
 * Elimina un elemento da un array in posizione i-esima
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param array $array l'array da cui eliminare il KI
 * @param integer $pos la posizione dell'elemento da eliminare
 * 
 * @return array
 * 
 * 
**/

public static function my_array_delete($array, $pos) {
	$nuovoArray = array();
	for($i = 0; $i < count($array); $i++){
		if($i != $pos)
			$nuovoArray[] = $array[$i];
	}
	return $nuovoArray;
}

}

?>
