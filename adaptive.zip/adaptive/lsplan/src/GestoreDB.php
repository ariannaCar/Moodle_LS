<?php
require_once("LearningNode.php");
require_once("KnowledgeItem.php");
require_once("../../../../config.php");
/**
 * Gestisce l'accesso al DB
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 * 
 **/

class GestoreDB{
/**
 * @staticvar mixed
 **/
private static $connessione;
/**
 * @staticvar string
 **/
private static $db_database = "moodle";

/**
 * Crea la connessione al database
 * @author Matteo Lombardi <maluit@alice.it>

 * @version 1.0
 * 
 * @static
 * 
 * @return mixed ritorna una connessione MySQL al DB
 * 
**/


public static function connessione(){ //void
	
	Global $DB;
	$a = $DB->get_records("user", array());
	//var_dump($a);
	/**
	 * @var string
	 **/
	$db_host = 'localhost';
	/**
	 * @var string
	 **/
	$db_user = 'root';
	/**
	 * @var string
	 **/
	$db_password = '';
    try{
		$connessione=mysqli_connect($db_host,$db_user,$db_password);
	} catch(Exception $e) {
		
		print_r("non riesco a connettermi ".$e->getMessage()."\n");
	}
	/*if(!$connessione){
		print_r("non riesco a connettermi ");
		die;
	}*///////////////////////////////////////////////
} 
/**
 * Ritorna l'insieme dei LearningNode del corso dato
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param string $corso Il corso di cui si vogliono ottenere i Learning Node
 * 
 * @return array L'insieme dei LearningNode del corso dato
**/

public static function getAllLN($corso){
	require_once("../../../../../config.php");
	Global $DB;
	$a = $DB->get_records("users", array());
	//var_dump($a);
	GestoreDB::connessione();
	$query="select * from learningnodes where corso='$corso'";
	try{
		$selected_db=mysqli_select_db(GestoreDB::$db_database);
		$result=mysql_query($query);
	} catch(Exception $e) {
		print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
	}
	return $result;
}

/**
 * crea nel db un record per il nuovo studente
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param long $matricola l'id dello studente
 * @param string $cs il Cognitive State
 * @param string $lev i livelli del Cognitive State
 * @param double $learningStyles0 attivo-riflessivo
 * @param double $learningStyles1 pratico-intuitivo
 * @param double $learningStyles2 visuale-verbale
 * @param double $learningStyles3 sequenziale-globale
 * @param string $nome il nome dello studente
 * @param string $cognome il cognome dello studente
 * @param string $goal l'obiettivo di apprendimento
 * @param string $goalLev i livelli dell'obiettivo di apprendimento
 * @param string $corso il corso
 * 
 * @return integer l'id assegnato al nuovo studente
 * 
 * 
**/
/* crea nel db un record per il nuovo studente e ritorna l'id assegnatogli */ 
		//long matricola, String cs, String lev,double learningStyles0,double learningStyles1,double learningStyles2,double learningStyles3,String nome,String cognome, String goal,String goalLev
  	public static function createStudentModel($matricola, $cs, $lev,$learningStyles0,$learningStyles1,$learningStyles2,$learningStyles3,$nome,$cognome,$goal,$goalLev,$corso,$percentuale) {
  		GestoreDB::connessione();
     
       	
       	$query = "INSERT INTO studentmodels VALUES(null, ".$matricola.",'".$nome."','".$cognome."','$corso',".$learningStyles0.",".$learningStyles1.",".$learningStyles2.",".$learningStyles3.",'".$cs."','".$lev."','".$percentuale."','','".$goal."','".$goalLev."')";     
     print_object($query);
     
      try{
		$selected_db=mysqli_select_db(GestoreDB::$db_database);
		mysql_query($query);
      } catch(Exception $e) {
		print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
	}
      	$autoIncKeyFromApi = -1; //int
        try{	
        	$rs = mysql_query("SELECT LAST_INSERT_ID()");

			if ($riga = mysql_fetch_array($rs)) {
        		$autoIncKeyFromApi = $riga[0];
    		} else {
    			print_r("autoincrementgenerato non recuperato\n");	
    		}
		} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
		return $autoIncKeyFromApi;
  	}
  	
/**
 * memorizza la los generale e quella raccomandata sul DB
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param long $idstudente l'id dello studente
 * @param string $los la los completa
 * @param string $recommended i nodi raccomandati allo studente
 * @param integer $complete 0->sequenza completa, 1->sequenza consigliata, -1->non e' stata valorizzata
 * @param string $corso il corso
 * 
 * 
**/

  	/*memorizza la los generale e quella raccomandata; 
	 *complete = 0 sequenza completa
	 *complete = 1 sequenza consigliata
	 *complete = -1 se non e' stata valorizzata
	 */


			//long idstudente, String los, String recommended, int complete, String corso
	 public static function createLOS($idstudente,$los,$recommended,$complete,$corso) {
 	
 		GestoreDB::connessione();
		$query = "INSERT INTO learningobjectssequences VALUES(null,".$idstudente.",'".$los."','".$recommended."',".$complete.",'".$corso."')";     
        try{
			$selected_db=mysqli_select_db(GestoreDB::$db_database);
			mysql_query($query);
		} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
	
	}
	

/** 
 * Aggiorna il modello studente dopo aver acquisito un concetto 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $cognitivestate il nuovo cognitive state
 * @param string $level i livelli del nuovo cognitive state
 * @param string $visited stringa degli id dei nodi visitati, separati da ','
 * @param long $idsm l'id del modello studente da aggiornare
 * 
 * 
 * 
**/	
	
	  	//String cognitivestate, String level, String visited, long idstudente
 public static function updateStudentModelKiAcquired($cognitivestate,$level,$visited,$idsm,$percentuale){
 	GestoreDB::connessione();
 	
	$query2="SELECT percentuale FROM studentmodels WHERE id=".$idsm;
    try{
		$selected_db=mysqli_select_db(GestoreDB::connessione(), GestoreDB::$db_database);
		$res =mysql_fetch_assoc(mysql_query($query2));
		print_object($res);
		
		if($res['percentuale']!=null)
		$percent = $res['percentuale'].",".$percentuale;
		
		else
		$percent = $percentuale;
			$query = "UPDATE studentmodels SET cognitivestate = '".$cognitivestate."', level = '".$level."', percentuale ='".$percent."', visitednodes = '".$visited."' WHERE id = ".$idsm;

		mysql_query($query);
    } catch(Exception $e) {
		print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
	}  
 	
 }
 
 /**
 * scrive i metadati di un LN sul DB
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param string $idLN l'id del Learning Node
 * @param string $corso corso
 * 
 * @return LearningNode il LN scritto sul DB
 * 
**/
 
 	// ritorna le informazioni sul LN studiato

			//String idLN

	 public static function createLN($idLN,$corso) {//LearningNode
 		Global $DB;
		//GestoreDB::connessione();

     	$resultSet;
     	$ht = array();        
     	//$query = "SELECT * FROM mdl_learningnodes WHERE id = '".$idLN."' and corso='$corso'";    
     	$query = $DB->get_records("learningnodes", array("id"=>$idLN, "corso"=>$corso));

  		try{
			//$selected_db=mysqli_select_db(GestoreDB::connessione(), GestoreDB::$db_database);
			
			//$resultSet=mysqli_query($query);
				
        	//if (mysql_affected_rows()>0 && $riga = mysql_fetch_assoc($resultSet)) { 
			if(!empty($query)){
				$riga = $query;	
        		  $ht["corso"] = $corso;      		
            	  $ht["rk"] = $riga["rk"];
            	  $ht["levelrk"] = $riga["levelrk"];
            	  $ht["ak"] = $riga["ak"];
            	  $ht["levelak"] = $riga["levelak"];
            	  $ht["activereflective"] = $riga["activereflective"];
            	  $ht["sensingintuitive"] = $riga["sensingintuitive"];
            	  $ht["visualverbal"] = $riga["visualverbal"];
            	  $ht["sequentialglobal"] = $riga["sequentialglobal"];
            	  $ht["minimumPossibleScore"] = $riga["minimumPossibleScore"];
            	  $ht["maximumPossibleScore"] = $riga["maximumPossibleScore"];
            	  $ht["minimumscore"] = $riga["minimumscore"];
            	  $ht["minimumtime"] = $riga["minimumtime"];
            	  $ht["maximumtime"] = $riga["maximumtime"];       
            	  $ht["existsposttest"] = $riga["existsposttest"]; 
            	  $ht["approach"] = $riga["approach"];        
            } else {
                print_r("learning node ".$idLN." non trovato nel db");
            }
        	
      
	    $ln = new LearningNode();
	    $ln->setId($idLN);
	    $rk = array();
	 	$rkdb = $ht["rk"];
	 	$levelrk = $ht["levelrk"]; 
	 	if($rkdb != null && $rkdb != ""){
	 
		 	$rk_split = explode(",",$rkdb);
		 	
		 	$levelrk_split = explode(",",$levelrk);
		 	
		 	for($i = 0; $i< count($rk_split); $i++){
		 		$kirk = new KnowledgeItem();
		  		$kirk->setId($rk_split[$i]);
		  		$kirk->setLevel($levelrk_split[$i]);
		  		$kirk->setPosseduto(false);
		  		$rk[]=$kirk;
		 	}
		  	$ln->setRequiredKnowledge($rk);
	 	}
	 	$ak = array();
	 	$akdb = $ht["ak"];
	 	$levelak = $ht["levelak"]; 
	 	$ak_split = explode(",",$akdb);
	 	$levelak_split = explode(",",$levelak);
	 
	 	for($i = 0; $i< count($ak_split); $i++){
	 		$kiak = new KnowledgeItem();
	  		$kiak->setId($ak_split[$i]);
	  		$kiak->setLevel($levelak_split[$i]);
	  		$kiak->setPosseduto(false);
	  		$ak[]=$kiak;
	 	}
	  	$ln->setAcquiredKnowledge($ak);
	 	
	 	$learningStylesln = array(); //new double[4] 
	  	$learningStylesln[0] = $ht["activereflective"];
	    $learningStylesln[1] = $ht["sensingintuitive"];
	    $learningStylesln[2] = $ht["visualverbal"];
	    $learningStylesln[3] = $ht["sequentialglobal"];
	    $ln->setLearningStyles($learningStylesln);
	    
	    $ln->setMinimumScore($ht["minimumscore"]);  
	    $ln->setMinimumPossibleScore($ht["minimumPossibleScore"]);
	    $ln->setMaximumPossibleScore($ht["maximumPossibleScore"]);
	    $ln->setCorso($ht["corso"]);		
	  	$ln->setMinimumTime($ht["minimumtime"]);
	  	$ln->setMaximumTime($ht["maximumtime"]);
	  	if ($ht["existsposttest"]==0)
	  		$ln->setExistsPosttest(true);
	  	else 
	  		$ln->setExistsPosttest(false);
      } catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
      return $ln;
}

/** 
 * Aggiorna il modello studente dopo aver visitato un Learning Node 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $visited stringa degli id dei nodi visitati, separati da ','
 * @param long $idsm l'id del modello studente da aggiornare
 * 
 * 
 * 
**/

		//String visited, long idstudente
 	public static function updateStudentModelIdRivisitato($visited,$idsm){
		GestoreDB::connessione();
		$query = "UPDATE studentmodels SET visitednodes = '".$visited."' WHERE id = ".$idsm;
		try{
			$selected_db=mysqli_select_db(GestoreDB::$db_database);
			mysql_query($query);  
		} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
 	}
 	
/** 
 * Aggiorna il modello studente dopo che un concetto è stato eliminato dal cognitive state
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $cognitivestate il nuovo cognitive state
 * @param string $level i livelli del nuovo cognitive state
 * @param long $idsm l'id del modello studente da aggiornare
 * 
 * 
 * 
**/ 	
 	
 	//String cognitivestate, String level, long idstudente
 public static function updateStudentModelKiLost($cognitivestate,$level,$idsm){
 	GestoreDB::connessione();
	$query = "UPDATE studentmodels SET cognitivestate = '".$cognitivestate."', level = '".$level."' WHERE id = ".$idsm;
	try{
		$selected_db=mysqli_select_db(GestoreDB::$db_database);
		mysql_query($query);   	
	} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
 }

/** 
 * Aggiorna i learning styles del modello studente 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param double $ls0 attivo-riflessivo
 * @param double $ls1 pratico-intuitivo
 * @param double $ls2 visuale-verbale
 * @param double $ls3 sequenziale-globale
 * @param long $idsm l'id del modello studente da aggiornare
 * 
**/

	//double ls0,double ls1,double ls2,double ls3, long idstudente
 public static function updateStudentModelLS($ls0,$ls1,$ls2,$ls3,$idsm){
 	
 	GestoreDB::connessione();
	$query = "UPDATE studentmodels SET activereflective = ".$ls0.", sensingintuitive = ".$ls1.", visualverbal = ".$ls2.", sequentialglobal = ".$ls3." WHERE id = ".$idsm;
	try{
		$selected_db=mysqli_select_db(GestoreDB::$db_database);
		mysql_query($query); 
	} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}  	 
 }

/**
 * Seleziona una los dal DB
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param long $idstudente l'id dello studente
 * @param integer $complete 0->sequenza completa, 1->sequenza consigliata, -1->non e' stata valorizzata
 * @param string $corso il corso
 * 
 * @return string la los
 * 
 * 
**/

	//long idstudente, int complete, String corso
 public static function getLOS($idstudente,$complete,$corso){//String
 		Global $DB;
        //GestoreDB::connessione();
  
     	//$resultSet = null;
     	$rs = "";     
        //$query = "SELECT los FROM learningobjectssequences WHERE idstudente = ".$idstudente." AND complete = ".$complete." AND corso = '".$corso."'";
		$query = $DB->get_fieldset_select("learningobjectssequences", 'los', 'idstudente'.$idstudente AND 'complete'.$complete AND 'corso'.$corso);
		try{
			//$selected_db=mysqli_select_db(GestoreDB::$db_database);
			//$resultSet=mysql_query($query);   	 
        
			//if ($resultSet != null && $riga = mysql_fetch_assoc($resultSet)){
			if (!empty($query)){
				$riga = $query;
				$rs = $riga["los"];
			}
        } catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
      return $rs;
  }
  
  /**
 * Seleziona la stringa che indica i valori "recommended" di tutti i nodi della los completa
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param long $idstudente l'id dello studente
 * @param integer $complete 0->sequenza completa, 1->sequenza consigliata, -1->non e' stata valorizzata
 * @param string $corso il corso
 * 
 * @return string la stringa che indica i valori "recommended"
 * 
 * 
**/ 
  
	//long idstudente, int complete, String corso
  public static function getRec($idstudente,$complete,$corso){//String
 	
 	//GestoreDB::connessione();
 	Global $DB;
  
     	//$resultSet = null;
     	$rs = "";     
        //$query = "SELECT recommended FROM learningobjectssequences WHERE idstudente = ".$idstudente." AND complete = ".$complete." AND corso = '".$corso."'";
		$query = $DB->get_fieldset_select("learningobjectssequences", 'recommended', 'idstudente'.$idstudente AND 'complete'.$complete AND 'corso'.$corso);

		try{
			//$selected_db=mysqli_select_db(GestoreDB::$db_database);
			//$resultSet=mysql_query($query);   	 
			//if ($resultSet != null && $riga = mysql_fetch_assoc($resultSet)){
			if(!empty($query)){
				$riga = $query;
				$rs = $riga["recommended"];
			}
		} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
      return $rs;
  }

/** 
 * Aggiorna la los nel DB 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param long $idstudente l'id dello studente
 * @param string $los la los completa
 * @param string $recommended i nodi raccomandati allo studente
 * @param integer $complete 0->sequenza completa, 1->sequenza consigliata, -1->non e' stata valorizzata
 * @param string $corso il corso
 * 
 * 
 * 
**/

	//long idstudente, String los,String recommended, int complete, String corso
 public static function updateLOS($idstudente,$los,$recommended,$complete,$corso){
 	GestoreDB::connessione();
	$query = "";
	if ($los != "")
		$query = "UPDATE learningobjectssequences SET los = '".$los."',recommended = '".$recommended."' WHERE idstudente = ".$idstudente." AND complete = ".$complete." AND corso = '".$corso."'";
	else
		$query = "UPDATE learningobjectssequences SET recommended = '".$recommended."' WHERE idstudente = ".$idstudente." AND complete = ".$complete." AND corso = '".$corso."'";
    try{
		$selected_db=mysqli_select_db(GestoreDB::$db_database);
		mysql_query($query);   	 
	} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
} 

/**
 * Seleziona i nodi alternativi a quello passato come parametro
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param LearningNode $currentLN il nodo corrente
 * 
 * @return array l'insieme di tutti i LN alternativi
 * 
 * 
**/

		//LearningNode currentLN
  public static function getAlternativeNodes($currentLN){ //Vector
  	
		$arrayak=$currentLN->getAcquiredKnowledge();
  		$k=$arrayak[0]; //$k KnowledgeItem
  		$idLn = $currentLN->getId();
  		$ak = $k->getId();
  		$levelLn = $k->getLevel();
  		$corso = $currentLN->getCorso();
  		$rkLearningnodes = $currentLN->getRequiredKnowledge();  
  		$rkLn = array();
  			     	    	
  		GestoreDB::connessione();
  
     	$alternativi = array();
     
        $query = "SELECT id, rk, levelrk FROM learningnodes WHERE ak = '".$ak."' AND levelak = '".$levelLn."' AND corso = '".$corso."' AND id != '".$idLn."'";  
		try{
			$selected_db=mysqli_select_db(GestoreDB::$db_database);
			$resultSet=mysql_query($query);   	 

				
				if ($resultSet != null){
					while ($riga = mysql_fetch_assoc($resultSet)) { 
					  if ($rkLearningnodes != null)
						$rkLn = array_merge($rkLn,$rkLearningnodes);
						
					
					  //prende uno dei nodi con ak = a quella del nodo da sostituire
					  // deve verificare che gli rk siano uguali
					  $id = $riga["id"];
					  $rk = $riga["rk"];
					  $level = $riga["levelrk"];
					  //rk del nodo possibile sostituto  		
					  $rks = explode(",",$rk);
					  //level degli rk del nodo possibile sostituto  
					  $levels =explode(",",$level);  
					  $diversi = false; 
					  //scorro il vettore degli rk del possibile sostituto 
					  for($i = 0; $i<count($rks) && (!$diversi); $i++){
						$aux = new KnowledgeItem();
						$aux->costruttore($rks[$i],$levels[$i]);
						$trovato = false;
						//verifico se l'rk del possibile sostituto � presente nel nodo da sostituire e allo stesso livello
						for($j = 0; ($j<count($rkLn)) && (!$trovato); $j++){
							$aux2 = $rkLn[$j];
							
							if ($aux->confronta($aux2)==true){
								$trovato = true;
						
								//unset($rkLn[$j]);
								$rkLn = GestoreDB::my_array_delete($rkLn, $j);
							}            	  			            	  		
						}
						//se l'rk non � presente nel nodo da sostituire (o lo � ma ad un livello diverso) il nodo non 
						// � un possibile sostituto 
						if (!$trovato)
							 $diversi = true;           	  	
					  }
					  //se ho trovato in rkLn tutti gli rk del nodo possibile sostituto
					  //e se rkLn non ha altri rk il nodo � un nodo alternativo
					  if (count($rkLn)==0 && !$diversi) 
						$alternativi[]=$id;
				}
				} else {
					print_r("non ci sono nodi alternativi\n");
				}      	
       } catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		} 	
  	  return $alternativi;
  }
 
  /**
 * Ritorna i prerequisiti di un Learning Node
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param array $requiredk l'insieme dei KI prerequisiti del LN
 * @param string $corso il corso
 * 
 * @return array i prerequisiti
 * 
 * 
**/
  		//Vector requiredk, String corso
public static function getPrerequisites($requiredk, $corso){ //Vector
		
  		
  		$prerequisites = array();
  	 
     	if(!empty($requiredk)){
     
  		//per ogni rk
  		for ($i = 0; $i< count($requiredk); $i++){
  			$rk = $requiredk[$i]; //KnowledgeItem 
  			$rkCercata = $rk->id; //String 
  			//echo $rkCercata;
  		//	System.out.println("rkCercata " + rkCercata);
  			
  			$rkCercataLevel = $rk->level;
  			//echo $rkCercataLevel;
  		//	System.out.println("rkCercataLevel" + rkCercataLevel);
  			
  		// recupera tutti i ln con ak = a un rk del nodo
	       	
	       	GestoreDB::connessione();

	       	$query = "SELECT id FROM learningnodes WHERE corso = '".$corso."' AND ak = '".$rkCercata."' AND levelak = '".$rkCercataLevel."'";  
			$id;
			try{
				$selected_db=mysqli_select_db(GestoreDB::$db_database);
				$resultSet=mysql_query($query);   	 
			
				if ($resultSet != null){
					while ($riga = mysql_fetch_assoc($resultSet)) { 
					  $id = $riga["id"];
						  //System.out.println("id prerequisito trovato " + id);
						 // print_r("id prerequisito trovato ".$id."\n");
						  $prerequisites[]=$id;
						}	
					}
				
			}catch(Exception $e){
				print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
			}
		}
  		return 	$prerequisites;
		}
	}

/**
 * Seleziona il modello studente richiesto
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param long $idstudente l'id dello studente
 * @param string $corso il corso
 * 
 * @return array le informazioni del modello studente selezionato
 * 
 * 
**/

		//long idsm
	public static function getStudentModel($idstudente,$corso) { //Hashtable
  		Global $DB;
  		//GestoreDB::connessione();
     	$ht = array(); //Hashtable         
     		  
        	//$query = "SELECT * FROM studentmodels WHERE idstudente = ".$idstudente." and corso='$corso'";     
     		$query=$DB->get_records("studentmodels", array("idstudente"=>$idstudente, "corso"=>$corso));

			try{
				//$selected_db=mysqli_select_db(GestoreDB::$db_database);
				//$resultSet=mysql_query($query);   	 
				
				//if ($resultSet != null && $riga = mysql_fetch_assoc($resultSet)) {    
				if (!empty($query)) {   
					  $riga = $query;
					  $ht["nome"]=$riga["nome"];
					  $ht["cognome"] = $riga["cognome"];
					  $ls = array();
					  $ls[0] = $riga["activereflective"];
					  $ls[1] = $riga["sensingintuitive"];
					  $ls[2] = $riga["visualverbal"];
					  $ls[3] = $riga["sequentialglobal"];           	  
					  $ht["ls"] = $ls;
					  $ht["cognitivestate"]=$riga["cognitivestate"];
					  $ht["level"]=$riga["level"];
					  $ht["percentuale"]=$riga["percentuale"];
					  $ht["visitednodes"]=$riga["visitednodes"]; 
					  $ht["goal"]=$riga["goal"];
					  $ht["goalLev"]=$riga["goalLev"];
					  $ht["corso"]=$riga["corso"];
					  $ht["idstudente"] = $riga["idstudente"];
					  $ht["id"] = $riga["id"];  
				} else {
					print_r("student model non trovato nel db");
				}
		} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
        	
  		return $ht;
  }

/**
 * Seleziona tutti gli AK del corso
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param string $corso il corso
 * 
 * @return array l'insieme di tutti gli AK
 * 
 * 
**/
  
		//String corso
  public static function getAllAK($corso)  { //Vector
   		GestoreDB::connessione();
  
     	$ak = array();        
     	$query = "SELECT ak, levelak FROM learningnodes where corso='".$corso."'";     
		try{
			$selected_db=mysqli_select_db(GestoreDB::$db_database);
			$resultSet=mysql_query($query);   	 	
			$inserisci = true; //boolean 
				
				if ($resultSet != null){
					while ($riga = mysql_fetch_assoc($resultSet)) {       		
					$ki = new KnowledgeItem();
					  //ki.setId(resultSet.getString("ak"));
					  //ki.setLevel(resultSet.getString("levelak"));            	  
					  $id = $riga["ak"];
					  $level = $riga["levelak"];
					  $ki->costruttore($id,$level);
					  for($i =0; $i< count($ak); $i++){
						$aki = $ak[$i];
						if($ki->confronta($aki))
							$inserisci = false;
					  }
					  if($inserisci){
							$ak[]=$ki;
							//System.out.println("ak inserito = " + ki.getId());
							//System.out.println("ak inserito livello = " + ki.getLevel());
					  }
					  
					  $inserisci = true;	
					}
				} else {
					print_r("ak dei nodi non trovati nel db");
				}
		} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}	
  		return $ak;
  }

/**
 * Traccia nel log la creazione di un modello studente e la los associata
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param long $idstudente l'id dello studente
 * @param string $corso il corso
 * 
 * 
 * 
**/

		//long idstudente, String corso
public static function logCreateSMeLOS($idstudente,$corso){ //void
		
		$ht = GestoreDB::getStudentModel($idstudente,$corso);
		$ls =$ht["ls"];
		$cs = $ht["cognitivestate"];
		$lev = $ht["level"];
		$goal = $ht["goal"];
		$goalLev = $ht["goalLev"];
		
		$loscompl = GestoreDB::getLOS($idstudente,0,$corso);
		$reconcompl = GestoreDB::getRec($idstudente,0,$corso);
		$recomm = GestoreDB::getLOS($idstudente,1,$corso);
		
		GestoreDB::connessione();
  	
       $query = "INSERT INTO log VALUES(null,'".$idstudente."','0','0','0','0','-','-','-','-','-','-','-','-','".$corso."','-','0','0',".$ls[0].",".$ls[1].",".$ls[2].",".$ls[3].",'".$cs."','".$lev."','','".$goal."','".$goalLev."','".$loscompl."','".$reconcompl."','".$recomm."')";     
 
        	//esempio INSERT INTO log VALUES(null,'1234327','0','0','0','0','-','-','-','-','-','-','-','-','"+corso+"','-','0','0','3','2','5','7','ki1','K','','ki9','E','id1,id2,id3,id4','true,false,true,true','id1,id3,id4')
		try{
			$selected_db=mysqli_select_db(GestoreDB::$db_database);
			$resultSet=mysql_query($query);   	 	
		} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
	
	}
  
 /**
 * recupero gli ultimi valori loggati
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param long $idstudente l'id dello studente
 * @param string $corso il corso
 * 
 * @return array le vecchie informazioni dello studente
 * 
 * 
**/  
  
			//long idstudente, String corso
  public static function getOldValues($idstudente,$corso) {//Hashtable 
  	//recupero gli ultimi valori loggati, che saranno i vecchi valori rispetto a quelli aggiornati nelle tabelle studentmodels e los
  		GestoreDB::connessione();
		$id = 0; //long
		$query0 = "SELECT MAX(id) FROM log WHERE idstudente = ".$idstudente." AND corso = '".$corso."'";   
	//	System.out.println("query " + query);
		try{
			$selected_db=mysqli_select_db(GestoreDB::$db_database);
			$resultSet0=mysql_query($query0);   	 	
	 
			if ($resultSet0 != null && $riga = mysql_fetch_assoc($resultSet0)) {
				$id = $riga["MAX(id)"];
			}
			 else {
				print_r("id non trovato nel db");
			}        	
		
			$ht = array();        
			$query = "SELECT * FROM log WHERE id = ".$id;
			$selected_db=mysqli_select_db(GestoreDB::$db_database);
			$resultSet=mysql_query($query);   	 	
			
				if ($resultSet != null && $riga = mysql_fetch_assoc($resultSet)) {    		
					  $ls = array();
					  $ls[0] = $riga["activereflectivenew"];
					  $ls[1] = $riga["sensingintuitivenew"];
					  $ls[2] = $riga["visualverbalnew"];
					  $ls[3] = $riga["sequentialglobalnew"];           	  
					  $ht["ls"] = $ls;
					  $ht["cognitivestate"] = $riga["cognitivestatenew"];
					  $ht["level"]= $riga["levelnew"];
					  $ht["visitednodes"] = $riga["visitednodesnew"]; 
					  $ht["goal"] = $riga["goalnew"];
					  $ht["goalLev"]=$riga["goalLevnew"]; 
					  $ht["loscomplete"]=$riga["loscompletenew"]; 
					  $ht["recommendedoncomplete"]=$riga["recommendedoncompletenew"];
					  $ht["losrecommended"]=$riga["losrecommendednew"]; 
				} else {
					print_r("log non trovato nel db\n");
				}
        } catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}	
  		return $ht;
  }
  
  /**
 * Traccia nel log l'aggiornamento di un modello studente e la los associata
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param long $idstudente l'id dello studente
 * @param string $corso il corso
 * @param string $idnodo l'id del nodo
 * @param double $score il punteggio ottenuto
 * @param long $fruitionTime il tempo di fruizione
 * 
**/
		//long idstudente, String corso, String idnodo, double score, long fruitiontime
  public static function logUpdateSMeLOS($idstudente,$corso,$idnodo,$score,$fruitiontime){
		
		$ht0 = GestoreDB::getOldValues($idstudente,$corso);
		
		$lsold = $ht0["ls"];
		$csold = $ht0["cognitivestate"];
		$levelold =$ht0["level"];
		$visitedold = $ht0["visitednodes"];
		$goalold = $ht0["goal"];
		$goalLevold = $ht0["goalLev"];
		$loscomplold = $ht0["loscomplete"];
		$reconcomplold = $ht0["recommendedoncomplete"];
		$recommold = $ht0["losrecommended"];
		
		//valori aggiornati
		$ht = GestoreDB::getStudentModel($idstudente,$corso);
		$ls = $ht["ls"];
		$cs = $ht["cognitivestate"];
		$lev = $ht["level"];
		$visited = $ht["visitednodes"];
		$goal = $ht["goal"];
		$goalLev = $ht["goalLev"];
		
		$loscompl = GestoreDB::getLOS($idstudente,0,$corso);
		$reconcompl = GestoreDB::getRec($idstudente,0,$corso);
		$recomm = GestoreDB::getLOS($idstudente,1,$corso);
		
		GestoreDB::connessione();
		$query = "INSERT INTO log VALUES(null,".$idstudente.",".$lsold[0].",".$lsold[1].",".$lsold[2].",".$lsold[3].",'".$csold."','".$levelold."','".$visitedold."','".$goalold."','".$goalLevold."','".$loscomplold."','".$reconcomplold."','".$recommold."','".$corso."','".$idnodo."',".$score.",".$fruitiontime.",".$ls[0].",".$ls[1].",".$ls[2].",".$ls[3].",'".$cs."','".$lev."','".$visited."','".$goal."','".$goalLev."','".$loscompl."','".$reconcompl."','".$recomm."')";     
		try{
			$selected_db=mysqli_select_db(GestoreDB::$db_database);
			$resultSet=mysql_query($query);   	 	
     	} catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}
  
}
/**
 * inserisce nel DB i metadati di un LN
 * le informazioni sono contenute nella stringa LN, separati da ';'
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param string $LN la stringa con le informazioni di inserimento del Learning Node
 * 
**/
  public static function inserisciLN($LN) {//$LN è String
	 	
	 	//	System.out.println("idLN dentro gestoredbcreateln " + idLN);	
	 		GestoreDB::connessione();
	     	//ho separato prima tutti i campi (così si può riusare la query in caso venga passato un oggetto e non una stringa
	     	$datiLN = explode(";",$LN);
	     	$idLN = $datiLN[0];//String
			$idCourse = $datiLN[1];//String
			$ak = $datiLN[2];//String
			$akLevel = $datiLN[3];//String
			$rks = $datiLN[4];//String
	     	$rkLevels = $datiLN[5];//String
	     	$ls1 = $datiLN[6];//act-ref di tipo double
	     	$ls2 = $datiLN[7];//sens-int
	     	$ls3 = $datiLN[8];//vis-verb
	     	$ls4 =$datiLN[9];//seq-glob
	     	$minScore = $datiLN[10];//di tipo double
	     	$maxScore = $datiLN[11];//di tipo double
	     	$soglia =$datiLN[12];//di tipo double
	     	$existTest = $datiLN[13]; //di tipo int
	     	$minTime = $datiLN[14];//di tipo int
	     	$maxTime = $datiLN[15];//di tipo int
			$query = "insert into learningnodes values(null,'$idLN','$idCourse','$rks','$rkLevels','$ak','$akLevel',$ls1,$ls2,$ls3,$ls4,$minScore,$maxScore,$soglia,$minTime,$maxTime,$existTest,0)";   
			try{
				$selected_db=mysqli_select_db(GestoreDB::$db_database); 
				$result=mysql_query($query);
			} catch(Exception $e) {
				print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
			}
	}
	
	/**
 * cancella i metadati di un LN
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param string $LN la stringa con le informazioni di eliminazione del Learning Node
 * 
**/
		public static function cancellaLN($LN) {
		//	System.out.println("idLN dentro gestoredbcreateln " + idLN);	
	 		GestoreDB::connessione();
			$datiLN = explode(";",$LN);
	     	$idLN = $datiLN[0];
			$corso = $datiLN[1];
	        	//	statement = connection.createStatement(); 
	        //	System.out.println("id "+idLN);
	        $query = "delete from learningnodes where id='$idLN' and corso='$corso'";    
			try{
				$selected_db=mysqli_select_db(GestoreDB::$db_database); 
				$result=mysql_query($query);
			} catch(Exception $e) {
				print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
			}
	}


/**
 * aggiorna i metadati di un LN con quelli contenuti nella stringa LN, separati da ';'
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param string $LN la stringa con le informazioni di aggiornamento del Learning Node
 * 
**/
//aggiorna i metadati di un LN con quelli contenuti nella strina LN, sempre separati da ';'
		//String LN
	public static function aggiornaLN($LN) { //void
	 	
	 	//	System.out.println("idLN dentro gestoredbcreateln " + idLN);	
	 		GestoreDB::connessione();
	      
	     	//ho separato prima tutti i campi (così si può riusare la query in caso venga passato un oggetto e non una stringa
	     	$datiLN = explode(";",$LN);
	     	$idLN = $datiLN[0]; //String
			$idCourse = $datiLN[1]; //String 
			$ak = $datiLN[2];
			$akLevel = $datiLN[3];
			$rks = $datiLN[4];
	     	$rkLevels = $datiLN[5];
	     	$ls1 = $datiLN[6];//act-ref
	     	$ls2 = $datiLN[7];//sens-int
	     	$ls3 = $datiLN[8];//vis-verb
	     	$ls4 = $datiLN[9];//seq-glob
	     	$minScore = $datiLN[10];
	     	$maxScore = $datiLN[11];
	     	$soglia = $datiLN[12];
	     	$existTest = $datiLN[13];
	     	$minTime = $datiLN[14];
	     	$maxTime = $datiLN[15];
	        
	        	//	statement = connection.createStatement(); 
	        //	System.out.println("id "+idLN);
	        	$query = "update learningnodes set corso='".$idCourse."',rk='".$rks."',levelrk='".$rkLevels."',ak='".$ak."',levelak='".$akLevel."',activereflective=".$ls1.",sensingintuitive=".$ls2.",visualverbal=".$ls3.",sequentialglobal=".$ls4.",minimumPossibleScore= $minScore,maximumPossibleScore= $maxScore,minimumscore= $soglia,minimumtime= $minTime,maximumtime= $maxTime,existsposttest= $existTest where id = '$idLN' and corso= '$idCourse'";    
	        	//System.out.println("query " + query);
				try{
					$selected_db=mysqli_select_db(GestoreDB::$db_database);
					$resultSet=mysql_query($query);
	        	} catch(Exception $e) {
					print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
				}
	}
  
/**
 * restituisce tutti i metadati del LN il cui id e corso è riportato nella stringa dati separati da ';', secondo la seguente struttura: idLN;corso
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param string $dati i dati del LN, separati da ';'
 * 
 * @return string la stringa dei metadati
 * 
 * 
**/ 
  
  //restituisce tutti i metadati del LN il cui id e corso è riportato nella stringa dati separati da ';', secondo la seguente struttura: idLN;corso
			//String dati
	public static function getMetadatiLN($dati){//String 
		
		    GestoreDB::connessione();
		    $datiLN = explode(";",$dati);
			$idLN=$datiLN[0]; //String 
			$course= $datiLN[1]; //String 
			$query = "select * from learningnodes where id='$idLN' and corso='$course'";    
			try{
				$selected_db=mysqli_select_db(GestoreDB::$db_database);
				$resultSet=mysql_query($query);
			
				if($resultSet != null && $result = mysql_fetch_assoc($resultSet)){
					
					$id=$result["id"]; //String 
					$corso= $result["corso"]; //String 
					$rks= $result["rk"];
					$levelRks=$result["levelrk"];
					$ak=$result["ak"];
					$levelak=$result["levelak"];
					$ls1=$result["activereflective"];//act-ref
					$ls2=$result["sensingintuitive"];//sens-int
					$ls3=$result["visualverbal"];
					$ls4=$result["sequentialglobal"];
					$minScore=$result["minimumPossibleScore"];
					$maxScore=$result["maximumPossibleScore"];
					$soglia=$result["minimumscore"];
					$minTime=$result["minimumtime"];
					$maxTime=$result["maximumtime"];
					$postTest=$result["existsposttest"];
					$metadati=$idLN.";".$corso.";".$ak.";".$levelak.";".$rks.";".$levelRks.";".$ls1.";".$ls2.";".$ls3.";".$ls4.";".$minScore.";".$maxScore.";".$soglia.";".$postTest.";".$minTime.";".$maxTime;	
					return $metadati;
				}
			} catch(Exception $e) {
				print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
			}	
			return null;
	}
  
 /** 
 * Elimina una stringa da un array 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param array $array l'array da cui eliminare la stringa
 * @param KnowledgeItem $item la stringa da eliminare
 * 
 * @return array
 * 
 * 
**/ 
  
//funzione di appoggio che elimina un elemento da un array associativo e riscala gli indici (solo per php)
public static function my_array_delete($array, $item) {
	
   if (isset($array[$item]))
       unset($array[$item]);
   return array_merge($array);
} 

//SPERIMENTAZIONE
public static function registraFeedback($userid,$feedback,$courseid){
	GestoreDB::connessione();
    $sm=GestoreDB::getStudentModel($userid,$courseid);
    $learningStyles=$sm["ls"];
    $cs=$sm["cognitivestate"];
	$stringaCS=$cs;
	$goal=$sm["goal"];
    $stringaGoal=$goal;
	$visitedNodes=$sm["visitednodes"];
    $stringaVN=$visitedNodes;
	$query = "INSERT INTO log_modello_studente VALUES(null,$userid,'".$sm["nome"]."','".$sm["cognome"]."',$courseid,".$sm["id"].",".$learningStyles[0].",".$learningStyles[1].",".$learningStyles[2].",".$learningStyles[3].",'".$stringaCS."','".$stringaGoal."','".$stringaVN."','".$feedback."')";     
	  try{
		$selected_db=mysqli_select_db(GestoreDB::$db_database);
		mysql_query($query);
	  } catch(Exception $e) {
		print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
	}
}

 /**
 * scrive i metadati di un LN sul DB
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * 
 * @version 1.0
 * 
 * @static
 * 
 * @param string $idLN l'id del Learning Node
 * @param string $corso corso
 * 
 * @return LearningNode il LN scritto sul DB
 * 
**/
 
 	// ritorna le informazioni sul LN studiato

			//String idLN

	 public static function getSoglia($idLN,$corso) {//LearningNode
 	
		$ln = GestoreDB::createLN($idLN,$corso);
	/*
		GestoreDB::connessione();
      
     	$resultSet;
     	$ht = array();
		$soglia = -1;
     	$query = "SELECT * FROM learningnodes WHERE id = '".$idLN."' and corso='$corso'";    
		try{
			$selected_db=mysqli_select_db(GestoreDB::$db_database);
			$resultSet=mysql_query($query);
				
        	if (mysql_affected_rows()>0 && $riga = mysql_fetch_assoc($resultSet)) { 
        		  $ht["corso"] = $corso;      		
            	  $ht["rk"] = $riga["rk"];
            	  $ht["levelrk"] = $riga["levelrk"];
            	  $ht["ak"] = $riga["ak"];
            	  $ht["levelak"] = $riga["levelak"];
            	  $ht["activereflective"] = $riga["activereflective"];
            	  $ht["sensingintuitive"] = $riga["sensingintuitive"];
            	  $ht["visualverbal"] = $riga["visualverbal"];
            	  $ht["sequentialglobal"] = $riga["sequentialglobal"];
            	  $ht["minimumPossibleScore"] = $riga["minimumPossibleScore"];
            	  $ht["maximumPossibleScore"] = $riga["maximumPossibleScore"];
            	  $ht["minimumscore"] = $riga["minimumscore"];
            	  $ht["minimumtime"] = $riga["minimumtime"];
            	  $ht["maximumtime"] = $riga["maximumtime"];       
            	  $ht["existsposttest"] = $riga["existsposttest"]; 
            	  $ht["approach"] = $riga["approach"];        
            } else {
                //print_r("learning node ".$idLN." non trovato nel db");
				$ht["minimumscore"] = -1;
            }
        	
      
	    $soglia  = $ht["minimumscore"];
      } catch(Exception $e) {
			print_r("non riesco a eseguire la query ".$e->getMessage()."\n");
		}*/
      return $ln->minimumScore;
}

}

?>
