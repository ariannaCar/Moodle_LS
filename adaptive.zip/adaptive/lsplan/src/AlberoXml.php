<?php
	

/**
 * Serve per prelevare i metadati dal Database e preparare il giusto input per il parser
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @package LSPLAN
 * @version 1.0
 * 
 * 
 **/

class AlberoXml{
	/**
	 * @var string
	 **/
	private $corso;
		/**
	 * @var array
	 **/
	private $nodi;//lista di LearningNode
    	/**
	 * @var array
	 **/
    private $AKtoRK;//Map<String,Set<String>>
    	/**
	 * @var array
	 **/
    private $AKtoID;//Map<String,String>
   	/**
	 * @var array
	 **/
    private $AKtoCorso;//Map<String,String>
		/**
	 * @var array
	 **/
	private $RKtoAK; //Map<String,Set<String>>
	/**
	 * @var array
	 **/
	private $listanodi;//String[]
   
/**
 * Crea l'istanza di AlberoXml
 * 
 * NOTA: i learning nodes del corso vengono selezionati da un Database tramite l'oggetto statico GestoreDB
 *  
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $corso il corso selezionato
 * 
 * @var mixed $result il risultato della query sul Database, ossia i learning nodes del corso selezionato
**/
   
	public function __construct($corso){
		$this->corso = $corso;
		$this->nodi = array();
		$this->AKtoRK = array();
		$this->AKtoID = array();
		$this->AKtoCorso = array();
		$result = GestoreDB::getAllLN($corso);
		
		while ($row = mysql_fetch_assoc($result)) {
			$this->search($row);
		}
		   $this->listanodi = $this->listaNodi();
		   $this->mapInversion();// inverte la mappa    
    }


    public function getNodi() {//List<Nodo>
        return $this->nodi;
    }
    
    
    public function getAKtoRK(){ //Map<String, Set<String>>
        return $this->AKtoRK;
    }
    
/**
 * Attraverso le informazioni contenute nel Database, crea il nodo da aggiungere alla lista dei nodi
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @access private
 * 
 * @param mixed $field la tupla risultante dalla query al Database
 * 
 * @var LearningNode $n il nodo creato, da aggiungere alla lista dei nodi
**/

 private function search($field) {
			$rks=explode(",",$field['rk']);
			if(count($rks)==1 && $rks[0]==' '){//potrebbe dare problemi se messo su moodle, dato che al posto di ' ' ci dovrebbe andare ''
					$rks=array();
			}
           $this->AKtoRK[$field['ak']]=$rks;
          
           $n=new LearningNode();
           $n->setAcquiredKnowledge(array($field['ak']));
          
           $n->setId($field['id']);
           $this->AKtoID[$field['ak']]=$field['id'];
           $this->AKtoCorso[$field['ak']]=$this->corso;
            //n.setLn(ln);
            $n->setCorso($this->corso);
            $n->setRequiredKnowledge(explode(",", $field['rk']));
            
            $n->setMinimumScore($field['minimumscore']);
  
			$n->setMinimumPossibleScore($field['minimumPossibleScore']);
		   $n->setMaximumPossibleScore($field['maximumPossibleScore']);
			$n->setMinimumTime($field['minimumtime']);
			$n->setMaximumTime($field['maximumtime']);
		   $n->setExistsPosttest($field['existsposttest']);

            $ls=array($field['activereflective'],$field['sensingintuitive'],$field['visualverbal'],$field['sequentialglobal']);
            $n->setLearningStyles($ls);

            $this->nodi[]=$n;
        
	}

/**
 * Ritorna tutti i nodi sorgente del grafo
 * 
 * NOTA: dovremmo avere una sola sorgente
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * 
 * @return array $sorgenti i nodi sorgente del grafo
 * 
**/
	
	public function getSorgenti(){ //List<Nodo>
        $sorgenti = array();
        foreach($this->nodi as $n){
            if (empty($this->AKtoRK[$n->getAcquiredKnowledge()]))
                $sorgenti[]=$n;
        }
        return $sorgenti;
    }
       

    public function getRKtoAK() { //Map<String,Set<String>>
        return $this->RKtoAK;
    }

    public function getAKtoCorso() { //Map<String,String>
        return $this->AKtoCorso;
    }

    public function getAKtoID() { //Map<String,String>
        return $this->AKtoID;
    }
    public function getListaNodi(){ //String[]
        return $this->listanodi;
    }
    public function getCorso(){ //String
        return $this->getCorso();
    }

/**
 * Imposta la mappa dei successori, a partire dalla mappa dei predecessori
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @access private
 * 
**/

  private function mapInversion () { //void
        $tmp; //Set<String> 
        $this->RKtoAK = array(); //new HashMap<String,Set<String>>
        $keys = array_keys($this->AKtoRK);
        foreach ($keys as $ak){
            foreach($this->AKtoRK[$ak] as $rk) {
               
			   if(isset($this->RKtoAK[$rk])){
					$tmp = $this->RKtoAK[$rk];
					$tmp[]=$ak;
					$this->RKtoAK[$rk]=$tmp;
				}
				else {
					$tmp = array();
					$tmp[]=$ak;
					$this->RKtoAK[$rk]=$tmp;
                }
			}
        }
    }

/**
 * Ritorna un array di stringhe contenente gli Acquired Knowledge dei nodi
 *
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @access private
 * 
 * @return array array_keys($insieme) array di stringhe contenente gli Acquired Knowledge dei nodi
**/

   private function listaNodi() { //String[]
        $insieme = array(); //Set
        $keys = array_keys($this->AKtoRK);
        foreach ($keys as $s) {
            $insieme[$s]=$s;
        }
        return array_keys($insieme);
    }

/**
 * Ritorna il learning node con id pari a $id
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * 
 * @param integer $id l'id del nodo da ricercare
 *
 * @return il learning node con id pari a $id, altrimenti NULL 
**/
         
    public function searchNodeForId($id){ //Nodo 
        foreach($this->nodi as $n)
            if ($n->getId()==$id)
                  return $n;
        return null;
    }

/**
 * Ritorna il learning node con Acquired Knowledge pari a $Ak
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
 * @param string $Ak l'Acquired Knowledge del nodo da ricercare
 *
 * @return il learning node con Acquired Knowledge pari a $Ak, altrimenti NULL 
**/
    
  public function searchNodeForAK($Ak){ //Nodo
     foreach($this->nodi as $n){
			$aks = $n->getAcquiredKnowledge();
            if ($aks[0]==$Ak){
                  return $n;
             }
      }
      return null;
  }
  
  /* potrebbe servire per iwt
  public List<Nodo> searchAllNodeForAK(String ak){
      List<Nodo> nodes=null;
      for(Nodo n:nodi){
          if(n.getAk().equals(ak)){
              if(nodes==null)
                  nodes=new ArrayList<Nodo>();
              nodes.add(n);
          }
      }
      return nodes;

  }
  */
  
  public function refresh(){ //void
      foreach($this->getNodi() as $n)
          $n->setCheck("white");
  }
  
/**
 * Stampa l'albero
 * 
 * @author Matteo Lombardi <maluit@alice.it>
 *
 * @version 1.0
 * 
**/
  
  
  public function stampa(){
	  $aks=array_keys($this->AKtoID);
	  foreach($aks as $ak){
		$app=$this->AKtoRK[$ak];
		echo("<br>Stampa Albero XML:<br>");
        print_r('rk di '.$ak.": ");
        foreach($app as $a)
			print_r("$a,");
		print_r("\n");
	}
  }  
	
}
?>
